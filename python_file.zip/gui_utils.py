"""
Utility functions for the GUI application
"""

import tkinter as tk
from tkinter import ttk

class ToolTip:
    def __init__(self, widget, text):
        self.widget = widget
        self.text = text
        self.tooltip = None
        
        self.widget.bind('<Enter>', self.show_tooltip)
        self.widget.bind('<Leave>', self.hide_tooltip)
    
    def show_tooltip(self, event):
        x, y, _, _ = self.widget.bbox("insert")
        x += self.widget.winfo_rootx() + 25
        y += self.widget.winfo_rooty() + 25
        
        self.tooltip = tk.Toplevel(self.widget)
        self.tooltip.wm_overrideredirect(True)
        self.tooltip.wm_geometry(f"+{x}+{y}")
        
        label = ttk.Label(self.tooltip, text=self.text, 
                         style='Tooltip.TLabel',
                         padding=8)
        label.pack()
        
        def hide():
            if self.tooltip:
                self.tooltip.destroy()
                self.tooltip = None
                
        self.tooltip.after(2500, hide)
    
    def hide_tooltip(self, event=None):
        if self.tooltip:
            self.tooltip.destroy()
            self.tooltip = None

def create_tooltip(widget, text):
    """Create a tooltip for any widget"""
    return ToolTip(widget, text)

def create_stat_card(parent, title, value_var, icon):
    """Create a statistics card with modern styling"""
    card = ttk.Frame(parent)
    card.configure(style='Card.TLabelframe')
    
    ttk.Label(card, text=f"{icon} {title}", 
             style='Section.TLabel',
             font=('Segoe UI', 9)).pack(anchor='w')
             
    ttk.Label(card, textvariable=value_var,
             style='Title.TLabel',
             font=('Segoe UI', 16, 'bold')).pack(pady=(2, 0))
             
    return card

def setup_modern_treeview(tree):
    """Apply modern styling to a treeview widget"""
    style = ttk.Style()
    
    # Configure treeview colors
    style.configure('Treeview',
                   background=colors['bg_secondary'],
                   fieldbackground=colors['bg_secondary'],
                   foreground=colors['text_primary'],
                   rowheight=25)
                   
    style.configure('Treeview.Heading',
                   background=colors['bg_accent'],
                   foreground=colors['primary'],
                   font=('Segoe UI', 10, 'bold'))
                   
    # Configure selection colors
    style.map('Treeview',
             background=[('selected', colors['primary'])],
             foreground=[('selected', colors['text_primary'])])
             
    return tree

def create_modern_button(parent, text, command, is_primary=False, colors=None, width=None):
    """Create a modern styled button"""
    style = 'Primary.TButton' if is_primary else 'Secondary.TButton'
    btn = ttk.Button(parent, text=text, command=command, style=style)
    if width:
        btn.configure(width=width)
    return btn