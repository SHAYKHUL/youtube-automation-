"""
YouTube Email Discovery for Authenticated Channels with Parallel Processing
Reads channels from signin_to_see_email.csv and discovers emails after login
"""

import multiprocessing
from multiprocessing import Pool, Manager
from functools import partial

import csv
import time
import random
import os
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException
from selenium.webdriver.chrome.options import Options
from chrome_utils import apply_extensions, apply_user_profile, cleanup_temp_paths
from extension_manager import ExtensionManager
import multiprocessing
from multiprocessing import Pool, Manager
from functools import partial
import traceback


class AuthenticatedEmailDiscovery:
    """Discovers emails from channels requiring authentication"""
    
    def __init__(self, manual_debug=True):
        """Initialize the email discovery"""
        self.manual_debug = manual_debug
        self.driver = None
        self.wait = None
        self.discovered_emails = []
        self.ext_manager = None
        
    def setup_driver(self):
        """Setup Chrome WebDriver with enhanced extension handling"""
        try:
            print("\n🌐 Setting up Chrome browser...")
            
            # Clean up any existing Chrome processes (to avoid profile locks)
            try:  
                import subprocess
                subprocess.run(['taskkill', '/F', '/IM', 'chrome.exe'], capture_output=True)
                time.sleep(2)
            except:
                pass
            
            # Initialize extension manager
            default_profile = os.path.join(os.getcwd(), 'chrome_profile')
            self.ext_manager = ExtensionManager(profile_dir=default_profile)
            
            print("\n🔧 Checking CAPTCHA solver extension...")
            
            # Ensure extension is ready before starting automation
            if not self.ext_manager.ensure_extension_ready():
                print("\n⚠️ WARNING: CAPTCHA solver extension not ready!")
                print("   Automation may fail on CAPTCHA challenges.")
                response = input("\nContinue anyway? (y/n): ").strip().lower()
                if response != 'y':
                    print("Setup cancelled by user")
                    return False
            
            print("\n✅ Extension ready - configuring Chrome...")
            
            # Create Chrome options with extension manager
            chrome_options = Options()
            chrome_options = self.ext_manager.setup_for_automation(chrome_options)
            
            # Additional automation settings
            chrome_options.add_argument("--disable-blink-features=AutomationControlled")
            chrome_options.add_experimental_option('useAutomationExtension', False)
            chrome_options.add_argument("--disable-dev-shm-usage")
            chrome_options.add_argument("--start-maximized")
            
            # Extension-specific options
            chrome_options.add_argument("--enable-extensions")
            chrome_options.add_argument("--disable-extension-http-throttling")
            
            if self.manual_debug:
                chrome_options.add_experimental_option("detach", True)
            
            # Apply chrome_utils configurations (for compatibility)
            try:
                apply_user_profile(chrome_options)
            except Exception as e:
                print(f"[discover_signin_emails] Note: {e}")

            try:
                apply_extensions(chrome_options)
            except Exception as e:
                print(f"[discover_signin_emails] Note: {e}")
            
            self.driver = webdriver.Chrome(options=chrome_options)
            self.driver.maximize_window()
            self.driver.execute_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
            self.wait = WebDriverWait(self.driver, 20)
            
            print("✅ Chrome browser initialized")
            
            # Quick extension check without verification
            extension_id = os.environ.get('REQUIRED_EXTENSION_ID')
            if extension_id:
                try:
                    self.driver.get('chrome://extensions')
                    time.sleep(1)
                    if self.driver.find_elements(By.CSS_SELECTOR, f'extensions-item[id*="{extension_id}"]'):
                        print("✓ RektCaptcha extension found")
                except:
                    pass
            
            print("\nℹ️ Note: Extension will auto-activate when needed")
            print("    Manual CAPTCHA solving is always available")
            return True
            
        except Exception as e:
            print(f"❌ Error setting up browser: {e}")
            return False
    
    def human_like_delay(self, min_delay=1, max_delay=3):
        """Add random human-like delays"""
        time.sleep(random.uniform(min_delay, max_delay))
    
    def human_like_typing(self, element, text, typing_delay=0.05):
        """Type text with human-like delays"""
        element.clear()
        time.sleep(0.2)  # Brief pause after clearing
        for char in text:
            element.send_keys(char)
            time.sleep(random.uniform(0.02, typing_delay))  # Faster minimum delay
    
    def check_login_status(self):
        """Check if already logged into YouTube"""
        try:
            # Try to find elements that indicate being logged in
            avatar_selectors = [
                "//yt-img-shadow[@id='avatar']",  # Avatar image
                "//button[@aria-label='Create']",  # Create button (only shown when logged in)
                "//ytd-topbar-menu-button-renderer[@avatar-button]",  # Avatar button
                "//img[contains(@alt, 'Avatar')]"  # Avatar image alt text
            ]
            
            for selector in avatar_selectors:
                try:
                    if self.driver.find_elements(By.XPATH, selector):
                        return True
                except:
                    continue
                    
            return False
        except:
            return False

    def login_to_youtube(self, email, password):
        """Login to YouTube with robust error handling"""
        try:
            print(f"\n🔐 Checking YouTube login status for: {email}")
            
            # Navigate to YouTube and ensure page loads
            try:
                self.driver.get("https://www.youtube.com")
                # Wait for the page to be fully loaded
                self.wait.until(lambda driver: driver.execute_script('return document.readyState') == 'complete')
                print("✓ YouTube page loaded")
                self.human_like_delay(2, 4)
            except Exception as e:
                print(f"Warning: Page load issue - {e}")
                self.human_like_delay(5, 7)  # Wait longer if there's an issue
                
            # Check if already logged in
            if self.check_login_status():
                print("✅ Already logged into YouTube!")
                return True
            
            # Click Sign In
            print("Clicking Sign In...")
            sign_in_selectors = [
                "//ytd-button-renderer//a[contains(@href, 'accounts.google.com')]",  # New YouTube UI
                "//yt-button-shape//a[contains(@href, 'accounts.google.com')]",      # Legacy UI
                "//a[contains(@href, 'accounts.google.com/ServiceLogin')]",          # Direct link
                "//a[contains(@aria-label, 'Sign in')]",                            # Aria label
                "//a[contains(text(), 'Sign in')]"                                  # Text content
            ]
            
            sign_in_found = False
            for selector in sign_in_selectors:
                try:
                    sign_in_btn = self.wait.until(EC.element_to_be_clickable((By.XPATH, selector)))
                    sign_in_btn.click()
                    sign_in_found = True
                    print("✓ Found Sign In button")
                    break
                except:
                    continue
            
            if not sign_in_found:
                print("Could not find Sign In button, trying direct navigation...")
                self.driver.get("https://accounts.google.com/ServiceLogin?continue=https://www.youtube.com")
            
            self.human_like_delay(2, 4)
            
            # Enter email - try multiple selectors with longer wait
            print("Entering email...")
            email_field = None
            email_selectors = [
                (By.ID, "identifierId"),                                # Standard Gmail login
                (By.NAME, "identifier"),                               # Alternate Gmail login
                (By.CSS_SELECTOR, "input[type='email']"),             # Generic email input
                (By.XPATH, "//input[@type='email']"),                 # Generic email input
                (By.CSS_SELECTOR, "[aria-label*='Email']"),           # Aria label containing Email
                (By.CSS_SELECTOR, "[placeholder*='Email']")           # Placeholder containing Email
            ]
            
            max_attempts = 3
            for attempt in range(max_attempts):
                for selector_type, selector_value in email_selectors:
                    try:
                        email_field = self.wait.until(EC.presence_of_element_located((selector_type, selector_value)))
                        if email_field.is_displayed() and email_field.is_enabled():
                            print(f"✓ Found email field")
                            break
                    except:
                        continue
                if email_field and email_field.is_displayed():
                    break
                    
                print(f"Retrying email field detection (attempt {attempt + 1}/{max_attempts})...")
                time.sleep(2)
                # Refresh the login page on retry
                if attempt < max_attempts - 1:
                    self.driver.refresh()
                    self.human_like_delay(2, 3)
            
            if not email_field or not email_field.is_displayed():
                print("❌ Could not find email field")
                print("Current URL:", self.driver.current_url)
                if self.manual_debug:
                    input("Please enter email manually and press Enter...")
                    self.human_like_delay(3, 5)
                else:
                    return False
            else:
                self.human_like_typing(email_field, email, 0.1)
                self.human_like_delay(1, 2)
                
                # Click next button
                try:
                    next_button = self.wait.until(EC.element_to_be_clickable((By.ID, "identifierNext")))
                    next_button.click()
                except:
                    email_field.send_keys(Keys.RETURN)
                
                self.human_like_delay(3, 5)
            
            # Enter password - try multiple selectors
            print("Entering password...")
            password_field = None
            password_selectors = [
                (By.NAME, "password"),
                (By.NAME, "Passwd"),
                (By.CSS_SELECTOR, "input[type='password']"),
                (By.XPATH, "//input[@type='password']"),
                (By.ID, "password")
            ]
            
            for selector_type, selector_value in password_selectors:
                try:
                    password_field = self.wait.until(EC.presence_of_element_located((selector_type, selector_value)))
                    print(f"✓ Found password field")
                    break
                except:
                    continue
            
            if not password_field:
                print("❌ Could not find password field")
                print(f"Current URL: {self.driver.current_url}")
                if self.manual_debug:
                    input("Please enter password manually and press Enter...")
                    self.human_like_delay(3, 5)
                else:
                    return False
            else:
                self.human_like_typing(password_field, password, 0.05)  # Faster typing
                self.human_like_delay(0.5, 1)  # Shorter delay
                
                # Click next button
                try:
                    next_button = self.wait.until(EC.element_to_be_clickable((By.ID, "passwordNext")))
                    next_button.click()
                except:
                    password_field.send_keys(Keys.RETURN)
                
                print("Waiting for login to complete...")
                self.human_like_delay(3, 5)  # Shorter wait
            
            # Check for login success
            if "youtube.com" in self.driver.current_url:
                print("✅ Login successful!")
                return True
            
            print("⚠️  Login status unclear")
            if self.manual_debug:
                input("Press Enter after completing login manually...")
            return True
            
        except Exception as e:
            print(f"❌ Error during login: {e}")
            print(f"Current URL: {self.driver.current_url if self.driver else 'N/A'}")
            if self.manual_debug:
                print("Please complete login manually")
                input("Press Enter after completing login...")
                return True
            return False
    
    def extract_email_from_about(self, channel_url):
        """Navigate to channel About page and extract email with CAPTCHA handling"""
        try:
            print(f"\n🔍 Visiting: {channel_url}")
            
            # Go to About page
            about_url = channel_url.rstrip('/') + '/about'
            self.driver.get(about_url)
            self.human_like_delay(3, 5)
            
            found_emails = []
            
            # Method 1: Click "View email address" button and handle CAPTCHA
            try:
                print("Looking for 'View email address' button...")
                
                # Try multiple selectors for the email button
                email_button_selectors = [
                    "//button[contains(@aria-label, 'View email address')]",
                    "//button[contains(., 'View email address')]",
                    "#view-email-button-container button",
                    "yt-button-view-model button"
                ]
                
                email_button = None
                for selector in email_button_selectors:
                    try:
                        if selector.startswith("//"):
                            email_button = self.wait.until(EC.element_to_be_clickable((By.XPATH, selector)))
                        else:
                            email_button = self.wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, selector)))
                        print(f"✓ Found email button")
                        break
                    except:
                        continue
                
                if email_button:
                    print("Clicking 'View email address' button...")
                    email_button.click()
                    self.human_like_delay(2, 3)
                    
                    # Check for reCAPTCHA checkbox
                    captcha_solved = False
                    try:
                        print("Checking for reCAPTCHA...")
                        # Wait for reCAPTCHA iframe
                        time.sleep(2)
                        # Switch to reCAPTCHA iframe
                        captcha_iframe = self.driver.find_element(By.CSS_SELECTOR, "iframe[src*='recaptcha']")
                        self.driver.switch_to.frame(captcha_iframe)
                        # Click the checkbox
                        print("Clicking reCAPTCHA checkbox...")
                        checkbox = self.wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, ".recaptcha-checkbox-border")))
                        checkbox.click()
                        # Wait for the checkmark to appear (CAPTCHA solved)
                        try:
                            self.wait.until(
                                EC.presence_of_element_located((By.CSS_SELECTOR, ".recaptcha-checkbox-checked"))
                            )
                            print("✅ reCAPTCHA checkmark detected! CAPTCHA solved.")
                            captcha_solved = True
                        except TimeoutException:
                            print("⚠️  reCAPTCHA checkmark not detected. Manual solve may be required.")
                            captcha_solved = False
                        # Switch back to main content
                        self.driver.switch_to.default_content()
                        # If not solved, check for challenge iframe (bframe = challenge with images)
                        if not captcha_solved:
                            try:
                                challenge_iframes = self.driver.find_elements(By.CSS_SELECTOR, "iframe[src*='bframe']")
                                if challenge_iframes and len(challenge_iframes) > 0 and challenge_iframes[0].is_displayed():
                                    print("⚠️  reCAPTCHA IMAGE CHALLENGE detected!")
                                    print("You need to solve the image challenge manually")
                                    if self.manual_debug:
                                        input("Please solve the CAPTCHA challenge and press Enter when done...")
                                        captcha_solved = True
                                else:
                                    print("✅ reCAPTCHA auto-solved (no visible challenge)!")
                                    captcha_solved = True
                            except:
                                print("✅ reCAPTCHA auto-solved!")
                                captcha_solved = True
                        
                    except Exception as e:
                        print(f"CAPTCHA handling: {e}")
                        # Assume no CAPTCHA or already handled
                        captcha_solved = True
                    
                    # Click Submit button after CAPTCHA
                    if captcha_solved:
                        try:
                            print("Looking for Submit button...")
                            time.sleep(2)
                            
                            submit_selectors = [
                                "#submit-btn",
                                "//button[contains(., 'Submit')]",
                                "//span[contains(text(), 'Submit')]/ancestor::button",
                                "//button[contains(@class, 'submit')]",
                                "//button[contains(@class, 'done')]"
                            ]
                            
                            submit_clicked = False
                            for selector in submit_selectors:
                                try:
                                    if selector.startswith("//"):
                                        submit_btn = self.wait.until(EC.element_to_be_clickable((By.XPATH, selector)))
                                    else:
                                        submit_btn = self.wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, selector)))
                                    print("✓ Found Submit button, clicking...")
                                    submit_btn.click()
                                    submit_clicked = True
                                    break
                                except:
                                    continue
                            
                            if submit_clicked:
                                print("Waiting for email to appear...")
                                self.human_like_delay(3, 5)  # Longer wait after submit
                                
                                # Try to detect modal or popup
                                try:
                                    modal_selectors = [
                                        "ytd-popup-container",
                                        "tp-yt-paper-dialog",
                                        "//div[contains(@class, 'modal')]",
                                        "//div[contains(@class, 'popup')]"
                                    ]
                                    for selector in modal_selectors:
                                        try:
                                            if selector.startswith("//"):
                                                self.wait.until(EC.presence_of_element_located((By.XPATH, selector)))
                                            else:
                                                self.wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, selector)))
                                            print("✓ Email modal detected")
                                            break
                                        except:
                                            continue
                                except:
                                    print("No visible modal detected")
                            
                        except Exception as e:
                            print(f"Submit button not found: {e}")
                    
                    # First check for access limit message
                    try:
                        limit_selectors = [
                            "//td[contains(text(), 'reached today')]",
                            "//td[contains(text(), 'access limit')]",
                            "td.style-scope.ytd-about-channel-renderer"
                        ]
                        
                        for selector in limit_selectors:
                            try:
                                elements = self.driver.find_elements(By.XPATH if selector.startswith("//") else By.CSS_SELECTOR, selector)
                                for element in elements:
                                    text = element.text.strip().lower()
                                    if "access limit" in text or "reached today" in text:
                                        print("\n⚠️ Access limit reached for current account!")
                                        print("Channel will be requeued for processing with different account")
                                        return ["ACCESS_LIMIT_REACHED"]
                            except:
                                continue
                                
                    except Exception as e:
                        print(f"Error checking access limit: {str(e)}")
                    
                    # If no access limit, proceed with email extraction
                    try:
                        print("Extracting email from modal...")
                        time.sleep(2)  # Wait for modal to update
                        
                        # Try multiple selectors for the email
                        email_selectors = [
                            "ytd-button-renderer #email",             # New YouTube UI
                            "a#email",                               # Traditional email link
                            "div#email",                             # Email div
                            "[href^='mailto:']",                     # Mailto links
                            "yt-formatted-string#email",             # YouTube formatted string
                            "span#email",                            # Email span
                            "//a[contains(@href, 'mailto:')]",       # XPath mailto
                            "//div[contains(text(), '@')]",          # Any div with @
                            "//span[contains(text(), '@')]"          # Any span with @
                        ]
                        
                        # Try each selector
                        for selector in email_selectors:
                            try:
                                print(f"Trying selector: {selector}")
                                if selector.startswith("//"):
                                    elements = self.driver.find_elements(By.XPATH, selector)
                                else:
                                    elements = self.driver.find_elements(By.CSS_SELECTOR, selector)
                                
                                for element in elements:
                                    # Try multiple ways to get the email
                                    email = None
                                    try:
                                        email = element.text.strip()
                                        if not email:
                                            email = element.get_attribute('href')
                                            if email and email.startswith('mailto:'):
                                                email = email.replace('mailto:', '')
                                        if not email:
                                            email = element.get_attribute('textContent').strip()
                                    except:
                                        continue
                                        
                                    if email and '@' in email and email not in found_emails:
                                        # Clean up the email
                                        email = email.strip()
                                        # Remove any "Email: " prefix
                                        if ":" in email:
                                            email = email.split(":")[-1].strip()
                                        # Basic email validation
                                        if '@' in email and '.' in email.split('@')[1]:
                                            found_emails.append(email)
                                            print(f"✅ Found email: {email}")
                                            return found_emails  # Return immediately after finding valid email
                            except Exception as e:
                                print(f"Selector failed: {str(e)}")
                                continue
                        
                        if not found_emails:
                            print("No email found in modal with standard selectors")
                            # Get page source for debugging
                            page_source = self.driver.page_source
                            if '@' in page_source:
                                print("Note: Found @ symbol in page, but couldn't extract email with selectors")
                            
                    except Exception as e:
                        print(f"Error extracting email: {str(e)}")
                    
                    # Also check page text for emails
                    try:
                        page_text = self.driver.find_element(By.TAG_NAME, 'body').text
                        import re
                        email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
                        emails = re.findall(email_pattern, page_text)
                        
                        for email in emails:
                            if (email not in found_emails and 
                                '@gmail.com' not in email.lower() and 
                                '@youtube.com' not in email.lower() and
                                '@google.com' not in email.lower()):
                                found_emails.append(email)
                                print(f"✅ Found email in text: {email}")
                    except:
                        pass
            
            except Exception as e:
                print(f"Method 1 failed: {e}")
            
            # Method 2: Check if email is already visible on page (no button needed)
            if not found_emails:
                try:
                    print("Checking for visible emails on page...")
                    page_text = self.driver.find_element(By.TAG_NAME, 'body').text
                    import re
                    email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
                    emails = re.findall(email_pattern, page_text)
                    
                    for email in emails:
                        if (email not in found_emails and 
                            '@gmail.com' not in email.lower() and 
                            '@youtube.com' not in email.lower() and
                            '@google.com' not in email.lower()):
                            found_emails.append(email)
                            print(f"✅ Found visible email: {email}")
                
                except Exception as e:
                    print(f"Method 2 failed: {e}")
            
            if not found_emails:
                print("❌ No email found")
            
            return found_emails
            
        except Exception as e:
            print(f"❌ Error extracting email: {e}")
            return []
    
    def check_for_captcha(self):
        """Check if CAPTCHA is present"""
        try:
            captcha_indicators = [
                "recaptcha",
                "captcha",
                "I'm not a robot"
            ]
            
            page_source = self.driver.page_source.lower()
            for indicator in captcha_indicators:
                if indicator in page_source:
                    return True
            return False
            
        except:
            return False
    
    def close(self):
        """Close browser"""
        try:
            if self.driver:
                try:
                    self.driver.quit()
                    print("Browser closed")
                except Exception as e:
                    print(f"Error quitting browser: {e}")
                finally:
                    self.driver = None
            # Attempt to cleanup any temp profiles/extensions we created
            try:
                cleanup_temp_paths()
            except Exception:
                pass
        except Exception as e:
            print(f"Error closing browser: {e}")


from multiprocessing import Pool, Manager, Value
import threading
from functools import partial

def process_channel_batch(batch_channels, gmail_accounts, batch_id, total_batches):
    """Process a batch of channels with a dedicated account"""
    try:
        if not batch_channels or not gmail_accounts:
            return []
        
        # Use modulo to rotate through accounts for each batch
        account_idx = batch_id % len(gmail_accounts)
        email, password = gmail_accounts[account_idx]
        
        print(f"\n{'='*70}")
        print(f"Batch {batch_id + 1}/{total_batches} using account: {email}")
        print(f"Processing {len(batch_channels)} channels")
        print(f"{'='*70}")
        
        # Create a unique profile directory for this batch
        profile_suffix = f"_batch_{batch_id}"
        os.environ['CHROME_PROFILE_SUFFIX'] = profile_suffix
        
        discoverer = AuthenticatedEmailDiscovery(manual_debug=False)  # Set to False for parallel processing
        if not discoverer.setup_driver():
            print(f"Failed to setup browser for batch {batch_id + 1}")
            return []
            
        if not discoverer.login_to_youtube(email, password):
            print(f"Failed to login in batch {batch_id + 1}")
            discoverer.close()
            return []
            
        batch_results = []
        for idx, channel_url in enumerate(batch_channels, 1):
            try:
                print(f"\nBatch {batch_id + 1}: Processing channel {idx}/{len(batch_channels)}: {channel_url}")
                
                emails = discoverer.extract_email_from_about(channel_url)
                
                # Check for access limit
                if emails and emails[0] == "ACCESS_LIMIT_REACHED":
                    print(f"\n⚠️ Access limit reached in batch {batch_id + 1}")
                    # Return remaining channels so they can be reprocessed
                    remaining = batch_channels[idx-1:]
                    return [{"channel_url": url, "status": "RETRY"} for url in remaining]
                
                batch_results.append({
                    'channel_url': channel_url,
                    'emails': emails,
                    'status': 'Found' if emails else 'Not Found',
                    'processed_by': email
                })
                
                # Add small delay between channels
                time.sleep(random.uniform(2, 4))
                
            except Exception as e:
                print(f"Error processing channel in batch {batch_id + 1}: {e}")
                batch_results.append({
                    'channel_url': channel_url,
                    'emails': [],
                    'status': f'Error: {str(e)}',
                    'processed_by': email
                })
        
        discoverer.close()
        return batch_results
        
    except Exception as e:
        print(f"Batch {batch_id + 1} failed: {e}")
        return []

def process_single_channel(channel_url, email, password, batch_id):
    """Process a single channel with given credentials"""
    try:
        print(f"\nBatch {batch_id}: Processing {channel_url}")
        
        # Validate inputs
        if not channel_url or not email or not password:
            return {
                'channel_url': channel_url,
                'emails': [],
                'status': 'Invalid Input Parameters',
                'processed_by': email if email else 'Unknown'
            }
        
        # Create a unique profile directory for this process
        profile_suffix = f"_batch_{batch_id}_{os.getpid()}"
        os.environ['CHROME_PROFILE_SUFFIX'] = profile_suffix
        
        discoverer = AuthenticatedEmailDiscovery(manual_debug=False)
        if not discoverer.setup_driver():
            return {
                'channel_url': channel_url,
                'emails': [],
                'status': 'Browser Setup Failed',
                'processed_by': email
            }
            
        if not discoverer.login_to_youtube(email, password):
            discoverer.close()
            return {
                'channel_url': channel_url,
                'emails': [],
                'status': 'Login Failed',
                'processed_by': email
            }
            
        try:
            emails = discoverer.extract_email_from_about(channel_url)
            
            # Check for access limit
            if emails and emails[0] == "ACCESS_LIMIT_REACHED":
                discoverer.close()
                return {
                    'channel_url': channel_url,
                    'emails': [],
                    'status': 'ACCESS_LIMIT_REACHED',
                    'processed_by': email
                }
                
            result = {
                'channel_url': channel_url,
                'emails': emails,
                'status': 'Found' if emails else 'Not Found',
                'processed_by': email
            }
            
        except Exception as e:
            result = {
                'channel_url': channel_url,
                'emails': [],
                'status': f'Error: {str(e)}',
                'processed_by': email
            }
            
        discoverer.close()
        return result
        
    except Exception as e:
        print(f"Process failed for {channel_url}: {str(e)}")
        print(traceback.format_exc())
        return {
            'channel_url': channel_url,
            'emails': [],
            'status': f'Process Error: {str(e)}',
            'processed_by': email
        }

def process_channel_batch(channels, accounts, batch_id, total_batches):
    """Process a batch of channels with a dedicated account"""
    if not channels or not accounts:
        return []

    # Select an account from the accounts list for this batch
    account_idx = batch_id % len(accounts)
    account = accounts[account_idx]
    
    # Make sure account is properly formatted as [email, password]
    if not isinstance(account, (list, tuple)) or len(account) != 2:
        print(f"Invalid account format in batch {batch_id + 1}")
        return []
        
    email, password = account
    print(f"\nBatch {batch_id + 1}/{total_batches} starting with account {email}")
    
    results = []
    for channel in channels:
        try:
            result = process_single_channel(channel, email, password, batch_id + 1)
            results.append(result)
            time.sleep(random.uniform(2, 4))  # Small delay between channels
        except Exception as e:
            print(f"Error processing channel {channel}: {str(e)}")
            results.append({
                'channel_url': channel,
                'emails': [],
                'status': f'Batch Error: {str(e)}',
                'processed_by': email
            })
    return results

def parallel_process_channels(channels, gmail_accounts, num_processes):
    """Process channels in parallel using multiple accounts"""
    # Split channels into batches
    batch_size = max(1, len(channels) // len(gmail_accounts))
    batches = [channels[i:i + batch_size] for i in range(0, len(channels), batch_size)]
    
    # Prepare arguments for parallel processing
    process_args = []
    for idx, batch in enumerate(batches):
        account = gmail_accounts[idx % len(gmail_accounts)]
        process_args.append((batch, account, idx, len(batches)))
    
    # Process batches in parallel
    with Pool(processes=num_processes) as pool:
        batch_results = pool.starmap(process_channel_batch, process_args)
    
    # Flatten results and handle retries
    all_results = []
    retry_channels = []
    
    for batch in batch_results:
        for result in batch:
            if result.get('status') == 'ACCESS_LIMIT_REACHED':
                retry_channels.append(result['channel_url'])
            else:
                all_results.append(result)
    
    # Process retries with remaining accounts if needed
    if retry_channels and len(gmail_accounts) > 1:
        print(f"\n🔄 Processing {len(retry_channels)} channels that hit access limits...")
        remaining_accounts = gmail_accounts[len(gmail_accounts)//2:]  # Use second half of accounts
        retry_batches = [retry_channels[i:i + batch_size] 
                        for i in range(0, len(retry_channels), batch_size)]
        
        retry_args = []
        for idx, batch in enumerate(retry_batches):
            account = remaining_accounts[idx % len(remaining_accounts)]
            retry_args.append((batch, account, idx, len(retry_batches)))
        
        with Pool(processes=min(num_processes, len(retry_batches))) as pool:
            retry_results = pool.starmap(process_channel_batch, retry_args)
            
        for batch in retry_results:
            all_results.extend([r for r in batch if r.get('status') != 'ACCESS_LIMIT_REACHED'])
    
    return all_results

def main():
    """Main function to discover emails with parallel processing"""
    print("="*70)
    print("YOUTUBE EMAIL DISCOVERY - Parallel Processing")
    print("="*70)
    print()
    
    # File paths
    gmail_csv = "gmail_accounts.csv"
    signin_csv = "signin_to_see_email.csv"
    output_csv = "discovered_emails_authenticated.csv"

    if not os.path.exists(signin_csv):
        print(f"❌ File not found: {signin_csv}")
        return
    
    if not os.path.exists(gmail_csv):
        print(f"❌ Gmail accounts file not found: {gmail_csv}")
        print("Please create gmail_accounts.csv with columns: email,password")
        return

    # Read Gmail credentials from CSV (support multiple accounts for rotation)
    print(f"📧 Reading Gmail credentials from: {gmail_csv}")
    gmail_accounts = []
    try:
        with open(gmail_csv, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                if row.get('email') and row.get('password'):
                    gmail_accounts.append((row['email'].strip(), row['password'].strip()))
    except Exception as e:
        print(f"❌ Error reading Gmail CSV: {e}")
        return

    if not gmail_accounts:
        print("❌ No valid Gmail credentials found in gmail_accounts.csv")
        print("CSV format should be: email,password")
        return

    print(f"✅ Loaded {len(gmail_accounts)} Gmail account(s). Will rotate after limit per account.")

    # max emails to retrieve per Gmail account before rotating (default 10)
    try:
        max_emails_per_account = int(os.environ.get('MAX_EMAILS_PER_ACCOUNT', '10'))
    except Exception:
        max_emails_per_account = 10
    print(f"ℹ️  Max emails per account (rotation threshold): {max_emails_per_account}")
    
    # Read channel links from signin_to_see_email.csv
    print(f"\n📋 Reading channels from: {signin_csv}")
    channels = []

    try:
        # First attempt: use DictReader and look for a 'Channel Link' column (common header)
        with open(signin_csv, 'r', encoding='utf-8-sig') as f:
            reader = csv.DictReader(f)
            # Normalize fieldnames in case of BOM or trailing spaces
            if reader.fieldnames:
                normalized = [h.strip() if h else h for h in reader.fieldnames]
                # Map original to normalized
                field_map = {orig: norm for orig, norm in zip(reader.fieldnames, normalized)}
            else:
                field_map = {}

            for row in reader:
                # Try common header first
                # Use case-insensitive match for 'Channel Link'
                link = None
                for key in row.keys():
                    if key and key.strip().lower() == 'channel link':
                        link = row.get(key)
                        break
                if link and link.strip():
                    channels.append(link.strip())

        # Fallback: if nothing found, try plain reader and take first column values that look like URLs
        if not channels:
            with open(signin_csv, 'r', encoding='utf-8-sig') as f:
                plain = csv.reader(f)
                for r in plain:
                    if not r:
                        continue
                    first = r[0].strip()
                    if first.lower().startswith('http'):
                        channels.append(first)
    except Exception as e:
        print(f"❌ Error reading signin CSV: {e}")
        return
    
    if not channels:
        print("❌ No channel links found in signin_to_see_email.csv")
        return
    
    print(f"✅ Found {len(channels)} channel(s) to process")

    # Get number of parallel processes from user
    default_processes = min(len(gmail_accounts), 4)  # Default to 4 or number of accounts, whichever is smaller
    num_processes = default_processes
    
    valid_input = False
    while not valid_input:
        try:
            user_input = input(f"\nNumber of parallel processes (1-{len(gmail_accounts)}) [default={default_processes}]: ").strip()
            if not user_input:  # User pressed Enter for default
                valid_input = True
            else:
                num_processes = int(user_input)
                if 1 <= num_processes <= len(gmail_accounts):
                    valid_input = True
                else:
                    print(f"Please enter a number between 1 and {len(gmail_accounts)}")
        except ValueError:
            print("Please enter a valid number")
    
    # Calculate batch size based on channel count and processes
    batch_size = max(1, len(channels) // (num_processes * 2))  # Split into smaller batches
    batches = [channels[i:i + batch_size] for i in range(0, len(channels), batch_size)]
    
    print(f"\nParallel Processing Configuration:")
    print(f"- Parallel Processes: {num_processes}")
    print(f"- Total Channels: {len(channels)}")
    print(f"- Batch Size: {batch_size}")
    print(f"- Number of Batches: {len(batches)}")
    print(f"- Gmail Accounts: {len(gmail_accounts)}")
    
    choice = input("\nContinue with parallel processing? (y/n): ").strip().lower()
    if choice != 'y':
        print("Cancelled")
        return

    # Initialize multiprocessing pool
    results = []
    retries = []
    
    print("\nStarting parallel processing...")
    
    # Process batches in parallel
    with Pool(processes=num_processes) as pool:
        # Process initial batches
        batch_results = pool.starmap(
            process_channel_batch,
            [(batch, gmail_accounts, idx, len(batches)) for idx, batch in enumerate(batches)]
        )
        
        # Collect results and identify retries
        for batch_result in batch_results:
            for result in batch_result:
                if result.get('status') == 'RETRY':
                    retries.append(result['channel_url'])
                else:
                    results.append(result)
        
        # Process retries if any
        if retries:
            print(f"\n🔄 Processing {len(retries)} channels that hit access limits...")
            retry_batches = [retries[i:i + batch_size] for i in range(0, len(retries), batch_size)]
            
            # Process retry batches
            retry_results = pool.starmap(
                process_channel_batch,
                [(batch, gmail_accounts[len(gmail_accounts)//2:], idx, len(retry_batches)) 
                 for idx, batch in enumerate(retry_batches)]  # Use second half of accounts for retries
            )
            
            # Add retry results
            for batch_result in retry_results:
                results.extend([r for r in batch_result if r.get('status') != 'RETRY'])
    # Read Gmail credentials from CSV
    print(f"📧 Reading Gmail credentials from: {gmail_csv}")
    gmail_accounts = []
    
    try:
        with open(gmail_csv, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                if 'email' in row and 'password' in row:  # Check if columns exist
                    email = row['email'].strip()
                    password = row['password'].strip()
                    if email and password:  # Make sure neither is empty
                        gmail_accounts.append([email, password])  # Use list for consistency
    except Exception as e:
        print(f"❌ Error reading Gmail CSV: {e}")
        return

    if not gmail_accounts:
        print("❌ No valid Gmail credentials found in gmail_accounts.csv")
        print("CSV format should be: email,password")
        return

    print(f"✅ Loaded {len(gmail_accounts)} Gmail account(s)")
    
    # Read channels from CSV
    print(f"\n📋 Reading channels from: {signin_csv}")
    channels = []
    
    try:
        with open(signin_csv, 'r', encoding='utf-8-sig') as f:
            reader = csv.DictReader(f)
            for row in reader:
                if 'Channel Link' in row:
                    channel = row['Channel Link'].strip()
                    if channel:
                        channels.append(channel)
    except Exception as e:
        print(f"❌ Error reading channels CSV: {e}")
        return
        
    if not channels:
        print("❌ No channel links found in signin_to_see_email.csv")
        return
    
    print(f"✅ Found {len(channels)} channel(s) to process")

    # Get number of parallel processes
    default_processes = min(len(gmail_accounts), 4)
    num_processes = default_processes
    
    valid_input = False
    while not valid_input:
        try:
            user_input = input(f"\nNumber of parallel processes (1-{len(gmail_accounts)}) [default={default_processes}]: ").strip()
            if not user_input:  # Default
                valid_input = True
            else:
                num_processes = int(user_input)
                if 1 <= num_processes <= len(gmail_accounts):
                    valid_input = True
                else:
                    print(f"Please enter a number between 1 and {len(gmail_accounts)}")
        except ValueError:
            print("Please enter a valid number")
            
    # Confirm with user
    print(f"\nParallel Processing Configuration:")
    print(f"- Parallel Processes: {num_processes}")
    print(f"- Total Channels: {len(channels)}")
    print(f"- Gmail Accounts: {len(gmail_accounts)}")
    print(f"- Batch Size: {max(1, len(channels) // num_processes)}")
    
    choice = input("\nContinue with parallel processing? (y/n): ").strip().lower()
    if choice != 'y':
        print("Cancelled")
        return
        
    # Process channels in parallel
    print("\nStarting parallel processing...")
    try:
        results = parallel_process_channels(channels, gmail_accounts, num_processes)
    except Exception as e:
        print(f"❌ Error during parallel processing: {str(e)}")
        print("Detailed error:")
        print(traceback.format_exc())
        return
    
    # Save results
    print(f"\n{'='*70}")
    print("SAVING RESULTS")
    print(f"{'='*70}")
    
    try:
        with open(output_csv, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(['Channel URL', 'Discovered Emails', 'Status', 'Processed By'])
            
            for result in results:
                writer.writerow([
                    result['channel_url'],
                    '; '.join(result['emails']) if result.get('emails') else '',
                    result['status'],
                    result.get('processed_by', 'Unknown')
                ])
        
        print(f"✅ Results saved to: {output_csv}")
        
        # Print summary
        found_count = sum(1 for r in results if r.get('emails'))
        error_count = sum(1 for r in results if 'Error' in r.get('status', ''))
        print(f"\n📊 Summary:")
        print(f"   Total channels processed: {len(results)}")
        print(f"   Emails found: {found_count}")
        print(f"   No email found: {len(results) - found_count - error_count}")
        print(f"   Errors: {error_count}")
        
        if error_count > 0:
            print("\nChannels with errors:")
            for result in results:
                if 'Error' in result.get('status', ''):
                    print(f"- {result['channel_url']}: {result['status']}")
        
    except Exception as e:
        print(f"❌ Error saving results: {e}")
    
    # Clean up Chrome processes
    try:
        import subprocess
        subprocess.run(['taskkill', '/F', '/IM', 'chrome.exe'], capture_output=True)
        time.sleep(2)
    except:
        pass
        
    print("\n✅ Email discovery completed!")
    
    # Save results
    print(f"\n{'='*70}")
    print("SAVING RESULTS")
    print(f"{'='*70}")
    
    try:
        with open(output_csv, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(['Channel URL', 'Discovered Emails', 'Status', 'Processed By'])
            
            for result in results:
                writer.writerow([
                    result['channel_url'],
                    '; '.join(result['emails']) if result.get('emails') else '',
                    result['status'],
                    result.get('processed_by', 'Unknown')
                ])
        
        print(f"✅ Results saved to: {output_csv}")
        
        # Summary
        found_count = sum(1 for r in results if r.get('emails'))
        error_count = sum(1 for r in results if 'Error' in r.get('status', ''))
        print(f"\n📊 Summary:")
        print(f"   Total channels processed: {len(results)}")
        print(f"   Emails found: {found_count}")
        print(f"   No email found: {len(results) - found_count - error_count}")
        print(f"   Errors: {error_count}")
        
        if error_count > 0:
            print("\nChannels with errors:")
            for result in results:
                if 'Error' in result.get('status', ''):
                    print(f"- {result['channel_url']}: {result['status']}")
        
    except Exception as e:
        print(f"❌ Error saving results: {e}")
    
    # Clean up any remaining Chrome processes
    try:
        import subprocess
        subprocess.run(['taskkill', '/F', '/IM', 'chrome.exe'], capture_output=True)
        time.sleep(2)
    except:
        pass
        
    print("\n✅ Email discovery completed!")


if __name__ == "__main__":
    main()