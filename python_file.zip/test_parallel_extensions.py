"""
Test multiple browsers with extensions running in parallel
"""

import threading
import time
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from chrome_utils import apply_extensions

def test_browser(browser_id):
    """Test a single browser instance with extension"""
    print(f"\n[Browser {browser_id}] Starting...")
    
    try:
        chrome_options = Options()
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--disable-dev-shm-usage")
        
        # Apply extensions - each browser gets its own copy
        print(f"[Browser {browser_id}] Loading extension...")
        apply_extensions(chrome_options, silent=False)
        
        print(f"[Browser {browser_id}] Starting Chrome...")
        driver = webdriver.Chrome(options=chrome_options)
        
        print(f"[Browser {browser_id}] ✅ Chrome started successfully!")
        
        # Navigate to test page
        driver.get('https://www.youtube.com')
        print(f"[Browser {browser_id}] ✅ Loaded YouTube")
        
        # Keep browser open for a moment
        time.sleep(5)
        
        print(f"[Browser {browser_id}] Closing...")
        driver.quit()
        print(f"[Browser {browser_id}] ✅ Closed successfully")
        
        return True
        
    except Exception as e:
        print(f"[Browser {browser_id}] ❌ Error: {e}")
        return False

def test_parallel_browsers():
    """Test multiple browsers running in parallel"""
    print("\n" + "="*70)
    print("TESTING PARALLEL BROWSERS WITH EXTENSIONS")
    print("="*70)
    
    num_browsers = 3
    print(f"\nStarting {num_browsers} browsers in parallel...")
    
    threads = []
    results = []
    
    def run_test(browser_id):
        result = test_browser(browser_id)
        results.append((browser_id, result))
    
    # Start all browsers
    for i in range(1, num_browsers + 1):
        thread = threading.Thread(target=run_test, args=(i,))
        thread.start()
        threads.append(thread)
        time.sleep(1)  # Slight delay between starts
    
    # Wait for all to complete
    for thread in threads:
        thread.join()
    
    # Check results
    print("\n" + "="*70)
    print("TEST RESULTS")
    print("="*70)
    
    all_success = all(result[1] for result in results)
    
    for browser_id, success in results:
        status = "✅ SUCCESS" if success else "❌ FAILED"
        print(f"Browser {browser_id}: {status}")
    
    print("\n" + "="*70)
    if all_success:
        print("✅ ALL BROWSERS WORKED WITH EXTENSIONS!")
        print("="*70)
        print("\n✅ Extensions work correctly in parallel mode")
        print("✅ Each browser got its own extension copy")
        print("✅ No conflicts between browsers")
        print("\n✅ Your multi-browser automation will work!")
    else:
        print("❌ SOME BROWSERS FAILED")
        print("="*70)
        print("\nCheck the errors above to see what went wrong.")
    
    return all_success

if __name__ == "__main__":
    success = test_parallel_browsers()
    
    if not success:
        print("\n⚠️ Some browsers failed. This may affect parallel processing.")
    
    input("\nPress Enter to exit...")
