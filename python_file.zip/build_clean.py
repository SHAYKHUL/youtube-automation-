"""
Clean Build Script for YTReach - YouTube Automation Suite
Optimized build with torch/ML library exclusions and warning suppression
"""

import os
import sys
import subprocess
import shutil
from pathlib import Path

def print_header(text):
    """Print formatted header"""
    print("\n" + "="*60)
    print(f"  {text}")
    print("="*60)

def clean_build_folders():
    """Remove old build artifacts"""
    print_header("🧹 Cleaning Build Artifacts")
    
    folders_to_clean = ['build', 'dist', '__pycache__']
    for folder in folders_to_clean:
        if os.path.exists(folder):
            print(f"  Removing: {folder}/")
            shutil.rmtree(folder, ignore_errors=True)
    
    # Remove .pyc files
    for root, dirs, files in os.walk('.'):
        for file in files:
            if file.endswith('.pyc'):
                try:
                    os.remove(os.path.join(root, file))
                except:
                    pass
    
    print("  ✅ Clean complete")

def check_dependencies():
    """Verify required packages are installed"""
    print_header("📦 Checking Dependencies")
    
    required = {
        'PyInstaller': 'pyinstaller',
        'PySide6': 'PySide6',
        'selenium': 'selenium',
        'pandas': 'pandas',
        'openpyxl': 'openpyxl',
    }
    
    missing = []
    for name, package in required.items():
        try:
            __import__(package.replace('-', '_'))
            print(f"  ✅ {name}")
        except ImportError:
            print(f"  ❌ {name} - MISSING")
            missing.append(package)
    
    if missing:
        print(f"\n⚠️  Missing packages: {', '.join(missing)}")
        response = input("\nInstall missing packages? (y/n): ")
        if response.lower() == 'y':
            for package in missing:
                print(f"\n  Installing {package}...")
                subprocess.check_call([sys.executable, '-m', 'pip', 'install', package])
        else:
            print("❌ Cannot build without required packages")
            return False
    
    return True

def run_build():
    """Execute PyInstaller build with optimized settings"""
    print_header("🔨 Building YTReach Pro")
    
    # Build command
    cmd = [
        'pyinstaller',
        '--clean',           # Clean cache
        '--noconfirm',       # Overwrite without asking
        '--log-level=WARN',  # Show only warnings and errors (suppress INFO messages)
        'YTReach.spec'       # Use our optimized spec file
    ]
    
    print(f"  Command: {' '.join(cmd)}")
    print("\n  Building YTReach Pro (PySide6)... (this may take 2-5 minutes)\n")
    print("  " + "-"*56)
    
    try:
        # Run with filtered output to hide torch warnings
        process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
            universal_newlines=True
        )
        
        # Filter output to hide torch-related warnings
        torch_warnings = [
            'torch.utils.tensorboard',
            'torch.distributed',
            '_sharding_spec',
            '_sharded_tensor',
            'tensorboard',
            'DeprecationWarning',
            'NOTE: Redirects are currently not supported'
        ]
        
        for line in process.stdout:
            # Skip torch-related warnings
            if any(warning in line for warning in torch_warnings):
                continue
            # Show important messages
            if any(keyword in line for keyword in ['ERROR', 'CRITICAL', 'Building', 'completed']):
                print(f"  {line.strip()}")
        
        process.wait()
        
        if process.returncode == 0:
            print("  " + "-"*56)
            print("\n  ✅ Build completed successfully!")
            return True
        else:
            print(f"\n  ❌ Build failed with code {process.returncode}")
            return False
            
    except Exception as e:
        print(f"\n  ❌ Build error: {e}")
        return False

def verify_build():
    """Check if build output exists"""
    print_header("✓ Verifying Build Output")
    
    exe_path = Path('dist/YTReach_Pro.exe')
    
    if exe_path.exists():
        size_mb = exe_path.stat().st_size / (1024 * 1024)
        print(f"  ✅ YTReach_Pro.exe created")
        print(f"  📦 Size: {size_mb:.1f} MB")
        print(f"  📁 Location: {exe_path.absolute()}")
        
        # Check for bundled_extensions
        bundled_path = Path('dist/bundled_extensions')
        if bundled_path.exists():
            print(f"  ✅ Extensions bundled")
        else:
            print(f"  ⚠️  Extensions folder not found")
        
        return True
    else:
        print(f"  ❌ YTReach_Pro.exe not found in dist/")
        return False

def main():
    """Main build process"""
    print("\n" + "█"*60)
    print("  YTReach Pro - Clean Build System")
    print("  Professional PySide6 Edition")
    print("█"*60)
    
    # Step 1: Clean
    clean_build_folders()
    
    # Step 2: Check dependencies
    if not check_dependencies():
        return 1
    
    # Step 3: Build
    if not run_build():
        print("\n❌ Build failed!")
        return 1
    
    # Step 4: Verify
    if not verify_build():
        print("\n⚠️  Build verification failed!")
        return 1
    
    # Success!
    print_header("🎉 Build Complete!")
    print("\n  Your executable is ready:")
    print("  → dist/YTReach_Pro.exe")
    print("\n  You can now distribute this file along with:")
    print("  → dist/bundled_extensions/ (if exists)")
    print("\n  Features included:")
    print("  ✅ Professional PySide6 interface")
    print("  ✅ Multi-threaded scraping & email finding")
    print("  ✅ Live progress updates & statistics")
    print("  ✅ Discover signin emails")
    print("  ✅ Smart workflow automation")
    print("\n  The warnings you saw were suppressed - they were")
    print("  related to torch/ML libraries that are not used.")
    print("\n" + "█"*60 + "\n")
    
    return 0

if __name__ == '__main__':
    try:
        exit_code = main()
        sys.exit(exit_code)
    except KeyboardInterrupt:
        print("\n\n⚠️  Build cancelled by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n\n❌ Unexpected error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
