"""
YouTube Email Discovery for Authenticated Channels
Reads channels from signin_to_see_email.csv and discovers emails after login
"""

import csv
import time
import random
import os
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException
from selenium.webdriver.chrome.options import Options
from chrome_utils import apply_extensions, apply_user_profile, cleanup_temp_paths
from extension_installer import install_extension


class AuthenticatedEmailDiscovery:
    """Discovers emails from channels requiring authentication"""
    
    def __init__(self, manual_debug=True):
        """Initialize the email discovery"""
        self.manual_debug = manual_debug
        self.driver = None
        self.wait = None
        self.discovered_emails = []
        
    def setup_driver(self):
        """Setup Chrome WebDriver"""
        print("\n🌐 Setting up Chrome browser...")
        
        try:
            # Clean up any existing Chrome processes (to avoid profile locks)
            try:
                import subprocess
                subprocess.run(['taskkill', '/F', '/IM', 'chrome.exe'], capture_output=True)
                time.sleep(2)
            except:
                pass

            # Configure the Chrome profile and extensions
            try:
                # Ensure there's a persistent profile to install/use extensions once
                import os
                # If no user-specified profile, create a default project-local one
                if not os.environ.get('CHROME_USER_DATA_DIR'):
                    default_profile = os.path.join(os.getcwd(), 'chrome_profile')
                    # Create both the profile root and Default subdirectory
                    os.makedirs(os.path.join(default_profile, 'Default'), exist_ok=True)
                    os.environ['CHROME_USER_DATA_DIR'] = default_profile
                    print(f"[discover_signin_emails] Created/using default Chrome profile: {default_profile}")
                    
                    # For fresh profiles, we should set the extension ID if not already set
                    if not os.environ.get('REQUIRED_EXTENSION_ID'):
                        # RektCaptcha - commonly used for this purpose
                        ext_id = 'bbdhfoclddncoaomddgkaaphcnddbpdh'
                        ext_url = 'https://chrome.google.com/webstore/detail/rektcaptcha/' + ext_id
                        os.environ['REQUIRED_EXTENSION_ID'] = ext_id
                        os.environ['REQUIRED_EXTENSION_URL'] = ext_url
                        print(f"[discover_signin_emails] Set default extension: RektCaptcha ({ext_id})")
            except Exception as e:
                print(f"[discover_signin_emails] Profile setup error: {e}")
                pass

            # Check for persisted extension marker
            try:
                marker_path = os.path.join(os.environ['CHROME_USER_DATA_DIR'], 'required_extension.json')
                if os.path.exists(marker_path):
                    try:
                        import json
                        with open(marker_path, 'r', encoding='utf-8') as mf:
                            data = json.load(mf)
                            if data.get('extension_id'):
                                os.environ['REQUIRED_EXTENSION_ID'] = data.get('extension_id')
                                if data.get('extension_url'):
                                    os.environ['REQUIRED_EXTENSION_URL'] = data.get('extension_url')
                                print(f"[discover_signin_emails] Found persisted REQUIRED_EXTENSION_ID in profile: {os.environ['REQUIRED_EXTENSION_ID']}")
                    except Exception:
                        pass
            except Exception as e:
                print(f"[discover_signin_emails] Marker file error: {e}")
                pass

            # Prompt for extension if needed
            if not os.environ.get('REQUIRED_EXTENSION_ID'):
                try:
                    print("No REQUIRED_EXTENSION_ID set. If you want the script to install an extension once and reuse it,"
                          " paste the extension Web Store URL or extension ID now. Leave blank to skip.")
                    val = input("Extension URL or ID (or Enter to skip): ").strip()
                    if val:
                        ext_id = val
                        if val.startswith('http'):
                            import re
                            m = re.search(r'/([a-z0-9]{32})', val)
                            if m:
                                ext_id = m.group(1)
                                os.environ['REQUIRED_EXTENSION_ID'] = ext_id
                                os.environ['REQUIRED_EXTENSION_URL'] = val
                            else:
                                # Not a typical webstore URL — store raw
                                os.environ['REQUIRED_EXTENSION_ID'] = val
                        else:
                            os.environ['REQUIRED_EXTENSION_ID'] = ext_id
                        print(f"[discover_signin_emails] Set REQUIRED_EXTENSION_ID={os.environ.get('REQUIRED_EXTENSION_ID')}")
                except Exception as e:
                    print(f"[discover_signin_emails] Extension prompt error: {e}")
                    pass

            # Configure Chrome options
            chrome_options = Options()
            chrome_options.add_argument("--disable-blink-features=AutomationControlled")
            chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
            chrome_options.add_experimental_option('useAutomationExtension', False)
            chrome_options.add_argument("--disable-dev-shm-usage")
            chrome_options.add_argument("--no-sandbox")
            chrome_options.add_argument("--start-maximized")
            chrome_options.add_argument("--enable-extensions")
            chrome_options.add_experimental_option("excludeSwitches", ["enable-automation", "load-extension"])
            
            if self.manual_debug:
                chrome_options.add_experimental_option("detach", True)

            # Apply user profile and extensions
            try:
                apply_user_profile(chrome_options)
            except Exception as e:
                print(f"[discover_signin_emails] Failed to apply user profile: {e}")

            try:
                apply_extensions(chrome_options)
            except Exception as e:
                print(f"[discover_signin_emails] Failed to apply extensions: {e}")

            # Initialize WebDriver
            self.driver = webdriver.Chrome(options=chrome_options)
            self.driver.maximize_window()
            self.driver.execute_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
            self.wait = WebDriverWait(self.driver, 20)
            
            print("✅ Chrome browser initialized")
            
            # Verify and install extension if needed
            extension_id = os.environ.get('REQUIRED_EXTENSION_ID')
            extension_url = os.environ.get('REQUIRED_EXTENSION_URL')
            
            if extension_id:
                print("\n🔍 Checking RektCaptcha extension...")
                if not install_extension(self.driver, extension_id, extension_url):
                    print("\n❌ Extension installation failed or was cancelled.")
                    self.close()
                    return False

            print("✅ Extension verification complete")
            return True
            
        except Exception as e:
            print(f"❌ Error setting up browser: {e}")
            if self.driver:
                self.close()
            return False

[rest of the original file content follows...]