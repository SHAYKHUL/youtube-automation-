"""
Quick test script to verify auto.py module loads correctly
Run this after building to verify the module import works
"""

import sys
import os

print("=" * 70)
print("TESTING AUTO.PY MODULE IMPORT")
print("=" * 70)
print()

# Show Python path
print("Python executable:", sys.executable)
print("Python version:", sys.version)
print()

# Check if running from PyInstaller bundle
if hasattr(sys, '_MEIPASS'):
    print(f"✅ Running from PyInstaller bundle")
    print(f"   Bundle directory: {sys._MEIPASS}")
    print()
else:
    print("ℹ️  Running from source (not bundled)")
    print()

# Show sys.path
print("Python search paths:")
for i, path in enumerate(sys.path, 1):
    print(f"   {i}. {path}")
print()

# Try to import auto module
print("Attempting to import 'auto' module...")
try:
    import auto
    print("✅ SUCCESS: auto module imported!")
    print(f"   Module location: {auto.__file__}")
    print()
    
    # Check if functions exist
    print("Checking auto module functions:")
    functions = ['setup_driver', 'go_to_youtube', 'search_topic', 
                'apply_advanced_filters', 'get_video_details']
    
    for func_name in functions:
        if hasattr(auto, func_name):
            print(f"   ✅ {func_name}() - found")
        else:
            print(f"   ❌ {func_name}() - NOT FOUND")
    
    print()
    print("=" * 70)
    print("✅ AUTO.PY MODULE TEST PASSED!")
    print("=" * 70)
    
except ImportError as e:
    print(f"❌ FAILED: Cannot import auto module")
    print(f"   Error: {e}")
    print()
    
    # Try to find auto.py file
    print("Searching for auto.py in bundle...")
    if hasattr(sys, '_MEIPASS'):
        bundle_dir = sys._MEIPASS
        auto_path = os.path.join(bundle_dir, 'auto.py')
        auto_pyc = os.path.join(bundle_dir, 'auto.pyc')
        
        if os.path.exists(auto_path):
            print(f"   ✅ Found: {auto_path}")
        elif os.path.exists(auto_pyc):
            print(f"   ✅ Found compiled: {auto_pyc}")
        else:
            print(f"   ❌ auto.py not found in bundle")
            
        print("\n   Files in bundle root:")
        try:
            files = os.listdir(bundle_dir)
            py_files = [f for f in files if f.endswith(('.py', '.pyc', '.pyd'))]
            for f in py_files[:20]:  # Show first 20
                print(f"      - {f}")
        except:
            pass
    
    print()
    print("=" * 70)
    print("❌ AUTO.PY MODULE TEST FAILED!")
    print("=" * 70)
    print()
    print("Please rebuild with: python build_exe.py")
    
except Exception as e:
    print(f"❌ UNEXPECTED ERROR: {e}")
    import traceback
    traceback.print_exc()

print()
input("Press Enter to exit...")
