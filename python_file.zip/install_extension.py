from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import os
import time
import shutil

def setup_chrome_with_extension():
    # Set up Chrome options
    chrome_options = Options()
    
    # Use our persistent profile
    profile_dir = os.path.join(os.getcwd(), 'chrome_profile')
    chrome_options.add_argument(f'--user-data-dir={profile_dir}')
    
    # Disable automation flags
    chrome_options.add_argument('--no-sandbox')
    chrome_options.add_argument('--start-maximized')
    chrome_options.add_experimental_option('excludeSwitches', ['enable-automation'])
    chrome_options.add_experimental_option('useAutomationExtension', False)
    
    # Initialize Chrome
    driver = webdriver.Chrome(options=chrome_options)
    
    # Open extension page
    extension_url = "https://chromewebstore.google.com/detail/rektcaptcha-recaptcha-sol/bbdhfoclddncoaomddgkaaphcnddbpdh"
    driver.get(extension_url)
    
    print("\n" + "="*70)
    print("CHROME EXTENSION SETUP")
    print("="*70)
    print("\nPlease follow these steps:")
    print("1. In the Chrome Web Store page that just opened:")
    print("   - Click 'Add to Chrome'")
    print("   - Click 'Add extension' in the popup")
    print("2. Wait for the extension to finish installing")
    print("3. IMPORTANT: DO NOT CLOSE CHROME!")
    print("4. After the extension is installed, return here and press Enter")
    
    input("\nPress Enter AFTER the extension is installed (but keep Chrome open)...")
    
    # Give time for extension to be installed
    time.sleep(5)
    
    # Verify installation by checking profile directory
    extension_id = "bbdhfoclddncoaomddgkaaphcnddbpdh"
    ext_path = os.path.join(profile_dir, 'Default', 'Extensions', extension_id)
    
    if not os.path.exists(ext_path):
        print("\nExtension directory not found. Checking alternative location...")
        alt_ext_path = os.path.join(profile_dir, 'Extensions', extension_id)
        if os.path.exists(alt_ext_path):
            # Move extension to correct location
            os.makedirs(os.path.dirname(ext_path), exist_ok=True)
            shutil.move(alt_ext_path, ext_path)
            print("✅ Extension installed and moved to correct location!")
        else:
            print("❌ Extension installation not detected. Please try again.")
            return False
    else:
        print("✅ Extension installed successfully!")
    
    print("\nClosing Chrome...")
    driver.quit()
    time.sleep(2)
    
    print("\n✅ Setup complete! You can now run discover_signin_emails.py")
    return True

if __name__ == "__main__":
    setup_chrome_with_extension()