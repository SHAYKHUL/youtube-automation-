"""
Enhanced Chrome Extension Manager for CAPTCHA Solving
Handles automatic extension installation, verification, and management
"""

import os
import sys
import time
import json
import shutil
import tempfile
from pathlib import Path
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


class ExtensionManager:
    """Manages Chrome extensions for automation"""
    
    REKTCAPTCHA_ID = 'bbdhfoclddncoaomddgkaaphcnddbpdh'
    REKTCAPTCHA_URL = f'https://chromewebstore.google.com/detail/rektcaptcha-recaptcha-sol/{REKTCAPTCHA_ID}'
    
    def __init__(self, profile_dir=None):
        """Initialize extension manager
        
        Args:
            profile_dir: Chrome profile directory path. If None, creates default.
        """
        if profile_dir is None:
            profile_dir = os.path.join(os.getcwd(), 'chrome_profile')
        
        self.profile_dir = Path(profile_dir)
        self.profile_dir.mkdir(parents=True, exist_ok=True)
        self.marker_file = self.profile_dir / 'extension_state.json'
        
    def get_extension_state(self):
        """Get current extension state from profile"""
        try:
            if self.marker_file.exists():
                with open(self.marker_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
        except Exception as e:
            print(f"[ExtensionManager] Error reading state: {e}")
        return {}
    
    def save_extension_state(self, extension_id, data):
        """Save extension state to profile"""
        try:
            state = self.get_extension_state()
            state[extension_id] = {
                **data,
                'last_verified': time.time(),
                'profile_dir': str(self.profile_dir)
            }
            with open(self.marker_file, 'w', encoding='utf-8') as f:
                json.dump(state, f, indent=2)
            return True
        except Exception as e:
            print(f"[ExtensionManager] Error saving state: {e}")
            return False
    
    def is_extension_installed(self, extension_id):
        """Check if extension is installed in Chrome profile
        
        Args:
            extension_id: Chrome extension ID
            
        Returns:
            bool: True if extension is installed
        """
        # Check multiple possible locations
        locations = [
            self.profile_dir / 'Extensions' / extension_id,
            self.profile_dir / 'Default' / 'Extensions' / extension_id,
        ]
        
        for loc in locations:
            if loc.exists() and loc.is_dir():
                # Check if there's a version folder with files
                try:
                    version_dirs = [d for d in loc.iterdir() if d.is_dir()]
                    if version_dirs and any(list(d.iterdir()) for d in version_dirs):
                        print(f"[ExtensionManager] ✅ Extension found: {loc}")
                        return True
                except Exception as e:
                    print(f"[ExtensionManager] Error checking {loc}: {e}")
        
        return False
    
    def verify_extension_works(self, driver, extension_id, timeout=10):
        """Verify extension is actually loaded in Chrome
        
        Args:
            driver: Selenium WebDriver instance
            extension_id: Chrome extension ID
            timeout: Maximum seconds to wait
            
        Returns:
            bool: True if extension is loaded and working
        """
        try:
            print(f"[ExtensionManager] Verifying extension {extension_id}...")
            
            # Navigate to extensions page
            driver.get('chrome://extensions')
            time.sleep(2)
            
            # Enable developer mode to see extension IDs
            try:
                driver.execute_script("""
                    const manager = document.querySelector('extensions-manager');
                    if (manager) {
                        const toolbar = manager.shadowRoot.querySelector('extensions-toolbar');
                        if (toolbar) {
                            const devMode = toolbar.shadowRoot.querySelector('#devMode');
                            if (devMode && !devMode.checked) {
                                devMode.click();
                            }
                        }
                    }
                """)
                time.sleep(1)
            except Exception as e:
                print(f"[ExtensionManager] Could not toggle dev mode: {e}")
            
            # Check if extension is visible
            try:
                script = f"""
                    const manager = document.querySelector('extensions-manager');
                    if (!manager) return false;
                    
                    const items = manager.shadowRoot.querySelectorAll('extensions-item');
                    for (let item of items) {{
                        const id = item.getAttribute('id');
                        if (id && id.includes('{extension_id}')) {{
                            // Check if enabled
                            const toggle = item.shadowRoot.querySelector('#enableToggle');
                            return toggle && toggle.checked;
                        }}
                    }}
                    return false;
                """
                is_enabled = driver.execute_script(script)
                
                if is_enabled:
                    print(f"[ExtensionManager] ✅ Extension {extension_id} is enabled")
                    return True
                else:
                    print(f"[ExtensionManager] ⚠️ Extension {extension_id} found but not enabled")
                    return False
                    
            except Exception as e:
                print(f"[ExtensionManager] Error checking extension status: {e}")
                return False
                
        except Exception as e:
            print(f"[ExtensionManager] Error verifying extension: {e}")
            return False
    
    def install_extension_interactive(self, extension_id=None, extension_url=None):
        """Install extension with user interaction
        
        Args:
            extension_id: Extension ID to install (default: RektCaptcha)
            extension_url: Web Store URL (default: RektCaptcha)
            
        Returns:
            bool: True if installation successful
        """
        if extension_id is None:
            extension_id = self.REKTCAPTCHA_ID
        if extension_url is None:
            extension_url = self.REKTCAPTCHA_URL
        
        print("\n" + "="*70)
        print("CHROME EXTENSION INSTALLATION")
        print("="*70)
        print(f"\nExtension ID: {extension_id}")
        print(f"Store URL: {extension_url}")
        
        # Check if already installed
        if self.is_extension_installed(extension_id):
            print("\n✅ Extension is already installed in profile!")
            
            # Verify it works
            try:
                chrome_options = self._create_chrome_options()
                driver = webdriver.Chrome(options=chrome_options)
                
                if self.verify_extension_works(driver, extension_id):
                    print("✅ Extension verified and working!")
                    driver.quit()
                    
                    # Save state
                    self.save_extension_state(extension_id, {
                        'url': extension_url,
                        'status': 'verified',
                        'name': 'RektCaptcha' if extension_id == self.REKTCAPTCHA_ID else 'Extension'
                    })
                    return True
                else:
                    print("⚠️ Extension found but may need configuration")
                    driver.quit()
            except Exception as e:
                print(f"⚠️ Could not verify extension: {e}")
        
        # Extension not installed - guide user through installation
        print("\n📥 Starting installation process...")
        
        try:
            chrome_options = self._create_chrome_options()
            driver = webdriver.Chrome(options=chrome_options)
            
            # Open Web Store
            print(f"\n🌐 Opening Chrome Web Store...")
            driver.get(extension_url)
            time.sleep(3)
            
            print("\n" + "="*70)
            print("INSTALLATION STEPS")
            print("="*70)
            print("\n1. Look for the 'Add to Chrome' button in the page")
            print("2. Click 'Add to Chrome'")
            print("3. Click 'Add extension' in the popup")
            print("4. Wait for 'Added to Chrome' confirmation")
            print("\n⚠️  IMPORTANT: Keep this window open!")
            print("="*70)
            
            input("\nPress Enter AFTER clicking 'Add extension' (keep Chrome open)...")
            
            # Wait for installation
            print("\n⏳ Waiting for extension to install...")
            time.sleep(5)
            
            # Verify installation
            max_attempts = 3
            for attempt in range(1, max_attempts + 1):
                print(f"\nVerification attempt {attempt}/{max_attempts}...")
                
                if self.verify_extension_works(driver, extension_id):
                    print("\n" + "="*70)
                    print("✅ INSTALLATION SUCCESSFUL!")
                    print("="*70)
                    
                    # Save state
                    self.save_extension_state(extension_id, {
                        'url': extension_url,
                        'status': 'installed',
                        'name': 'RektCaptcha' if extension_id == self.REKTCAPTCHA_ID else 'Extension'
                    })
                    
                    # Test on real page
                    print("\n🧪 Testing extension on YouTube...")
                    driver.get('https://www.youtube.com')
                    time.sleep(5)
                    
                    print("\n✅ Extension is ready for use!")
                    driver.quit()
                    return True
                
                if attempt < max_attempts:
                    print("⏳ Extension not detected yet, waiting...")
                    time.sleep(5)
            
            print("\n" + "="*70)
            print("⚠️  INSTALLATION VERIFICATION FAILED")
            print("="*70)
            print("\nPossible issues:")
            print("1. Extension didn't install - try again")
            print("2. Extension needs permissions - check Chrome")
            print("3. Extension ID mismatch - verify URL")
            
            driver.quit()
            return False
            
        except Exception as e:
            print(f"\n❌ Installation error: {e}")
            try:
                driver.quit()
            except:
                pass
            return False
    
    def setup_for_automation(self, chrome_options):
        """Configure Chrome options for automation with extensions
        
        Args:
            chrome_options: Selenium Chrome Options instance
            
        Returns:
            Chrome Options with proper extension configuration
        """
        # Use persistent profile
        chrome_options.add_argument(f'--user-data-dir={self.profile_dir}')
        
        # Extension-friendly settings
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--disable-dev-shm-usage')
        chrome_options.add_argument('--disable-blink-features=AutomationControlled')
        
        # Don't show automation flags
        chrome_options.add_experimental_option('excludeSwitches', ['enable-automation'])
        chrome_options.add_experimental_option('useAutomationExtension', False)
        
        # Set environment variables for chrome_utils integration
        os.environ['CHROME_USER_DATA_DIR'] = str(self.profile_dir)
        os.environ['REQUIRED_EXTENSION_ID'] = self.REKTCAPTCHA_ID
        os.environ['REQUIRED_EXTENSION_URL'] = self.REKTCAPTCHA_URL
        
        print(f"[ExtensionManager] Configured Chrome with profile: {self.profile_dir}")
        return chrome_options
    
    def ensure_extension_ready(self, extension_id=None):
        """Ensure extension is installed and ready
        
        Args:
            extension_id: Extension ID to check (default: RektCaptcha)
            
        Returns:
            bool: True if extension is ready
        """
        if extension_id is None:
            extension_id = self.REKTCAPTCHA_ID
        
        # Check state
        state = self.get_extension_state()
        ext_state = state.get(extension_id, {})
        
        # If recently verified, assume OK
        last_verified = ext_state.get('last_verified', 0)
        if time.time() - last_verified < 3600:  # 1 hour
            if self.is_extension_installed(extension_id):
                print(f"[ExtensionManager] ✅ Extension {extension_id} ready (verified recently)")
                return True
        
        # Check installation
        if self.is_extension_installed(extension_id):
            print(f"[ExtensionManager] ✅ Extension {extension_id} is installed")
            return True
        
        # Not installed - offer to install
        print(f"[ExtensionManager] ⚠️ Extension {extension_id} not found")
        print("\nThe CAPTCHA solving extension is required for this automation.")
        response = input("Install now? (y/n): ").strip().lower()
        
        if response == 'y':
            return self.install_extension_interactive(extension_id)
        else:
            print("⚠️ Extension not installed - CAPTCHA solving may not work")
            return False
    
    def get_extension_info(self):
        """Get information about all installed extensions"""
        state = self.get_extension_state()
        
        if not state:
            return "No extensions configured"
        
        info = ["Installed Extensions:"]
        for ext_id, data in state.items():
            name = data.get('name', ext_id)
            status = data.get('status', 'unknown')
            last = data.get('last_verified', 0)
            
            age = time.time() - last if last > 0 else None
            age_str = f"{int(age/60)} min ago" if age and age < 3600 else f"{int(age/3600)} hrs ago" if age else "never"
            
            info.append(f"  • {name} ({ext_id})")
            info.append(f"    Status: {status}")
            info.append(f"    Last verified: {age_str}")
        
        return "\n".join(info)
    
    def _create_chrome_options(self):
        """Create Chrome options for extension management"""
        options = Options()
        options.add_argument(f'--user-data-dir={self.profile_dir}')
        options.add_argument('--no-sandbox')
        options.add_argument('--disable-dev-shm-usage')
        options.add_argument('--start-maximized')
        options.add_experimental_option('excludeSwitches', ['enable-automation'])
        options.add_experimental_option('useAutomationExtension', False)
        return options


def quick_setup_rektcaptcha():
    """Quick setup for RektCaptcha extension - convenience function"""
    manager = ExtensionManager()
    return manager.install_extension_interactive()


def verify_captcha_solver():
    """Verify CAPTCHA solver extension is working"""
    manager = ExtensionManager()
    return manager.ensure_extension_ready()


if __name__ == "__main__":
    # CLI interface
    import argparse
    
    parser = argparse.ArgumentParser(description='Chrome Extension Manager')
    parser.add_argument('--install', action='store_true', help='Install RektCaptcha extension')
    parser.add_argument('--verify', action='store_true', help='Verify extension installation')
    parser.add_argument('--info', action='store_true', help='Show extension info')
    parser.add_argument('--profile', type=str, help='Chrome profile directory', default=None)
    
    args = parser.parse_args()
    
    manager = ExtensionManager(profile_dir=args.profile)
    
    if args.install:
        success = manager.install_extension_interactive()
        sys.exit(0 if success else 1)
    
    elif args.verify:
        success = manager.ensure_extension_ready()
        sys.exit(0 if success else 1)
    
    elif args.info:
        print(manager.get_extension_info())
        sys.exit(0)
    
    else:
        # Default: ensure ready
        print("Chrome Extension Manager")
        print("="*70)
        print()
        success = manager.ensure_extension_ready()
        print()
        if success:
            print("✅ Extension is ready for automation")
            sys.exit(0)
        else:
            print("❌ Extension setup incomplete")
            sys.exit(1)
