# PyInstaller hook to completely exclude torch and suppress warnings
# This prevents PyInstaller from trying to collect torch modules

from PyInstaller.utils.hooks import collect_submodules, collect_data_files

# Don't collect anything from torch
hiddenimports = []
datas = []
binaries = []

# Explicitly exclude all torch submodules
excludedimports = [
    'torch',
    'torch.utils',
    'torch.utils.tensorboard',
    'torch.distributed',
    'torch.distributed.elastic',
    'torch.distributed._sharding_spec',
    'torch.distributed._sharded_tensor',
    'torch.distributed._shard',
    'tensorboard',
]
