"""Helper module for Chrome extension installation and verification."""

import os
import time
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

def install_extension(driver, extension_id, extension_url=None, timeout=300):
    """Install and verify a Chrome extension.
    
    Args:
        driver: Selenium WebDriver instance
        extension_id: Extension ID to verify
        extension_url: Optional Web Store URL to open
        timeout: How long to wait for installation (seconds)
    
    Returns:
        bool: True if extension is installed and verified
    """
    if not extension_id or not driver:
        return False
        
    print("\n" + "="*70)
    print("CHROME EXTENSION INSTALLATION")
    print("="*70)
    
    # First check if already installed
    driver.get('chrome://extensions')
    time.sleep(3)
    
    try:
        # Enable developer mode for extension ID visibility
        driver.execute_script("""
            const devMode = document.querySelector('extensions-manager').shadowRoot
                .querySelector('extensions-toolbar').shadowRoot
                .querySelector('#devMode');
            if (devMode && !devMode.checked) {
                devMode.click();
            }
        """)
        time.sleep(1)
    except:
        pass
        
    # Look for extension card
    try:
        ext_root = driver.find_element(By.TAG_NAME, 'extensions-manager')
        if ext_root and ext_root.find_elements(By.CSS_SELECTOR, f'extensions-item[id*="{extension_id}"]'):
            print("✅ Extension already installed!")
            return True
    except:
        pass
    
    # Need to install - open Web Store
    if not extension_url:
        extension_url = f"https://chrome.google.com/webstore/detail/{extension_id}"
    
    print("\n⚠️ Extension needs to be installed. Please follow these steps:")
    print("1. In the Chrome Web Store page that opens:")
    print("   - Click 'Add to Chrome'")
    print("   - Click 'Add extension' in the popup")
    print("2. Wait for the extension to finish installing")
    print("3. Return here and press Enter ONLY after installation is complete")
    print("\nNOTE: The script will wait here until installation is complete.")
    
    start_time = time.time()
    while True:
        if time.time() - start_time > timeout:
            print("\n❌ Installation timeout exceeded.")
            return False
            
        driver.get(extension_url)
        response = input("\n>>> Press Enter after installing (or 'q' to quit): ")
        if response.lower().strip() == 'q':
            return False
            
        print("\nVerifying installation...")
        time.sleep(3)
        
        driver.get('chrome://extensions')
        time.sleep(2)
        
        try:
            ext_root = driver.find_element(By.TAG_NAME, 'extensions-manager')
            if ext_root and ext_root.find_elements(By.CSS_SELECTOR, f'extensions-item[id*="{extension_id}"]'):
                print("✅ Extension installed successfully!")
                
                # Verify it's working
                print("\nVerifying extension is active...")
                driver.get('https://www.youtube.com')
                time.sleep(5)
                
                try:
                    has_scripts = bool(driver.find_elements(By.CSS_SELECTOR, f'script[src*="{extension_id}"]'))
                    has_elements = bool(driver.find_elements(By.CSS_SELECTOR, '[class*="recaptcha"],[class*="captcha"]'))
                    if has_scripts or has_elements:
                        print("✅ Extension appears to be working")
                        return True
                except:
                    pass
                    
                print("\n⚠️ Extension found but may need configuration:")
                print("1. Click the extension icon in Chrome toolbar")
                print("2. Configure any required settings")
                configure = input("\nPress Enter after configuring (or 'c' to continue anyway): ")
                if configure.lower().strip() != 'c':
                    continue
                return True
                
            else:
                print("\n❌ Extension not found in Chrome. Please try again:")
                print("1. Click 'Add to Chrome' in the Web Store")
                print("2. Click 'Add extension' in the popup")
                print("3. Wait for installation to complete")
                continue
                
        except Exception as e:
            print(f"\n❌ Error checking extension: {e}")
            retry = input("\nRetry? (y/n): ").lower().strip()
            if retry != 'y':
                return False
                
    return False