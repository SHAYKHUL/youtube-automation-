"""
Quick test script to verify module imports after build
Run this to test if auto.py and other modules are accessible
"""

import sys
import os

print("=" * 70)
print("MODULE IMPORT TEST")
print("=" * 70)
print()

# Check if running from PyInstaller bundle
if getattr(sys, 'frozen', False):
    print("✅ Running from PyInstaller bundle")
    print(f"   Bundle directory: {sys._MEIPASS}")
    print(f"   Executable: {sys.executable}")
else:
    print("ℹ️  Running as Python script")
    print(f"   Script directory: {os.path.dirname(os.path.abspath(__file__))}")

print()
print("Python Path:")
for i, path in enumerate(sys.path, 1):
    print(f"   {i}. {path}")

print()
print("=" * 70)
print("Testing Module Imports...")
print("=" * 70)
print()

modules_to_test = [
    ('auto', 'Core automation module'),
    ('chrome_utils', 'Chrome utilities'),
    ('email_finder', 'Email finder module'),
    ('youtube_login', 'YouTube login module'),
    ('discover_signin_emails', 'Sign-in email discovery'),
    ('subcunt', 'Subscriber count analyzer'),
    ('multi_thread', 'Multi-threading support'),
    ('database_manager', 'Database manager'),
    ('analytics_dashboard', 'Analytics dashboard'),
    ('task_scheduler', 'Task scheduler'),
]

success_count = 0
failed_modules = []

for module_name, description in modules_to_test:
    try:
        __import__(module_name)
        print(f"✅ {module_name:25s} - {description}")
        success_count += 1
    except ImportError as e:
        print(f"❌ {module_name:25s} - FAILED: {e}")
        failed_modules.append(module_name)
    except Exception as e:
        print(f"⚠️  {module_name:25s} - ERROR: {e}")
        failed_modules.append(module_name)

print()
print("=" * 70)
print(f"RESULTS: {success_count}/{len(modules_to_test)} modules loaded successfully")
print("=" * 70)

if failed_modules:
    print()
    print("❌ Failed modules:", ", ".join(failed_modules))
    print()
    print("Troubleshooting:")
    print("1. Check if modules are in the bundle directory")
    print("2. Rebuild with: python build_exe.py")
    print("3. Verify hiddenimports in build script")
else:
    print()
    print("🎉 All modules loaded successfully!")
    print("Your standalone EXE is working correctly!")

print()
input("Press Enter to close...")
