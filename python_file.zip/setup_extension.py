from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import os
import time

def setup_chrome_with_extension():
    # Set up Chrome options
    chrome_options = Options()
    
    # Use our persistent profile
    profile_dir = os.path.join(os.getcwd(), 'chrome_profile')
    chrome_options.add_argument(f'--user-data-dir={profile_dir}')
    
    # Disable automation flags
    chrome_options.add_argument('--no-sandbox')
    chrome_options.add_argument('--start-maximized')
    chrome_options.add_experimental_option('excludeSwitches', ['enable-automation'])
    chrome_options.add_experimental_option('useAutomationExtension', False)
    
    # Initialize Chrome
    driver = webdriver.Chrome(options=chrome_options)
    
    # Open extension page
    extension_url = "https://chromewebstore.google.com/detail/rektcaptcha-recaptcha-sol/bbdhfoclddncoaomddgkaaphcnddbpdh"
    driver.get(extension_url)
    
    print("\n" + "="*70)
    print("CHROME EXTENSION SETUP")
    print("="*70)
    print("\nPlease follow these steps:")
    print("1. In the Chrome Web Store page that just opened:")
    print("   - Click 'Add to Chrome'")
    print("   - Click 'Add extension' in the popup")
    print("2. Wait for the extension to finish installing")
    print("3. Close the Chrome browser completely")
    print("\nAfter closing Chrome, the script will continue...")
    
    try:
        input("\nPress Enter AFTER closing Chrome completely...")
    finally:
        try:
            driver.quit()
        except:
            pass

if __name__ == "__main__":
    setup_chrome_with_extension()