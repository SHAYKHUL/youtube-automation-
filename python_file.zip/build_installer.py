"""
Build script to create YTReach installer
This script:
1. Builds the exe using PyInstaller
2. Creates a professional installer using Inno Setup
"""

import os
import sys
import subprocess
import shutil
from pathlib import Path

def check_inno_setup():
    """Check if Inno Setup is installed"""
    inno_path = r"C:\Program Files (x86)\Inno Setup 6\ISCC.exe"
    if os.path.exists(inno_path):
        print("✅ Inno Setup found")
        return inno_path
    
    print("❌ Inno Setup not found")
    print("\nPlease install Inno Setup:")
    print("1. Download from: https://jrsoftware.org/isdl.php")
    print("2. Run the installer")
    print("3. Run this script again")
    return None

def build_installer():
    """Build the installer using Inno Setup"""
    print("\n" + "=" * 70)
    print("BUILDING YTREACH INSTALLER")
    print("=" * 70)
    
    # First build the exe
    if not os.path.exists("build_exe.py"):
        print("❌ build_exe.py not found!")
        return False
    
    print("\n1. Building executable...")
    result = subprocess.run([sys.executable, "build_exe.py"], check=True)
    if result.returncode != 0:
        print("❌ Failed to build executable")
        return False
    
    # Check if exe was built
    if not os.path.exists(os.path.join("dist", "YTReach.exe")):
        print("❌ YTReach.exe not found in dist folder!")
        return False
    
    # Check for Inno Setup
    inno_path = check_inno_setup()
    if not inno_path:
        return False
    
    print("\n2. Creating installer...")
    
    # Create installer output directory
    os.makedirs("installer_output", exist_ok=True)
    
    # Create README.txt if it doesn't exist
    if not os.path.exists("README.txt"):
        readme_content = """YTReach - Professional YouTube Contact Discovery

Thank you for installing YTReach!

QUICK START GUIDE
================

1. System Requirements
   - Windows 10 or 11
   - Google Chrome browser
   - ChromeDriver matching your Chrome version

2. First-Time Setup
   a) Install Google Chrome if not already installed
   b) Download ChromeDriver from https://chromedriver.chromium.org/
      - Must match your Chrome version!
   c) Place chromedriver.exe in C:\\Windows\\System32 or add to PATH

3. Configuration
   - Rename gmail_accounts.csv.example to gmail_accounts.csv
   - Add your Gmail accounts for authenticated discovery

4. Running YTReach
   - Launch from Start Menu or Desktop shortcut
   - First launch may take a few seconds
   - See in-app help for detailed instructions

TROUBLESHOOTING
==============
1. "ChromeDriver not found"
   - Verify ChromeDriver is in C:\\Windows\\System32 or PATH
   - Check Chrome and ChromeDriver versions match

2. "Browser automation detected"
   - Normal for some YouTube pages
   - Try using different Gmail accounts
   - Adjust delay settings in the app

3. Application won't start
   - Run as Administrator
   - Check antivirus isn't blocking
   - Verify Chrome is installed

For more help, see CHROME_WINDOWS_FIX.md

SUPPORT
=======
- Check documentation in the installation folder
- Review common fixes in CHROME_WINDOWS_FIX.md
- Monitor the app's log window for detailed error messages

Thank you for choosing YTReach!
"""
        with open("README.txt", "w", encoding="utf-8") as f:
            f.write(readme_content)
    
    # Run Inno Setup
    try:
        subprocess.run([inno_path, "installer_setup.iss"], check=True)
        
        # Check if installer was created
        if os.path.exists(os.path.join("installer_output", "YTReach_Setup.exe")):
            print("\n✅ Installer created successfully!")
            print("\nInstaller location:")
            print(f"📁 {os.path.abspath(os.path.join('installer_output', 'YTReach_Setup.exe'))}")
            
            print("\nNext steps:")
            print("1. Test the installer on a clean system")
            print("2. Verify all features work after installation")
            print("3. Share the installer with users")
            return True
        else:
            print("❌ Installer not found in output directory")
            return False
            
    except subprocess.CalledProcessError as e:
        print(f"❌ Failed to create installer: {e}")
        return False

if __name__ == "__main__":
    try:
        build_installer()
    except Exception as e:
        print(f"❌ Error: {e}")
        sys.exit(1)