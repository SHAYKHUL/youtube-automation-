"""
YTReach Pro - Professional YouTube Automation Suite
Enterprise-Grade PySide6 Interface with Premium UI/UX
"""

import sys
import os
import time
import datetime
import threading
import csv
import random
from pathlib import Path
from typing import Dict, List

from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *

# Module imports
try:
    import auto
    from auto import (
        setup_driver, go_to_youtube, search_topic, apply_advanced_filters, 
        get_video_details, scroll_down_to_end, filter_and_collect
    )
    AUTO_AVAILABLE = True
except:
    AUTO_AVAILABLE = False

try:
    from email_finder import run_email_finder
    EMAIL_FINDER_AVAILABLE = True
except:
    EMAIL_FINDER_AVAILABLE = False


class Theme:
    """Professional enterprise color system"""
    # Backgrounds
    BG_PRIMARY = "#0a0e1a"
    BG_SECONDARY = "#141824"
    BG_TERTIARY = "#1a1f2e"
    BG_ELEVATED = "#1e2333"
    BG_CARD = "#161b2d"
    BG_HOVER = "#1f2538"
    BG_ACTIVE = "#252b3d"
    
    # Accents
    ACCENT_PRIMARY = "#00d4ff"
    ACCENT_SECONDARY = "#7c3aed"
    ACCENT_TERTIARY = "#ec4899"
    
    # Status colors
    SUCCESS = "#10b981"
    WARNING = "#f59e0b"
    ERROR = "#ef4444"
    INFO = "#3b82f6"
    
    # Text
    TEXT_PRIMARY = "#ffffff"
    TEXT_SECONDARY = "#cbd5e1"
    TEXT_TERTIARY = "#94a3b8"
    TEXT_MUTED = "#64748b"
    TEXT_DISABLED = "#475569"
    
    # Borders
    BORDER_PRIMARY = "#2d3748"
    BORDER_SECONDARY = "#1e293b"
    BORDER_ACCENT = "#00d4ff"
    BORDER_FOCUS = "#00d4ff"
    
    # Shadows
    SHADOW_SM = "0 1px 3px rgba(0, 0, 0, 0.3)"
    SHADOW_MD = "0 4px 6px rgba(0, 0, 0, 0.4)"
    SHADOW_LG = "0 10px 25px rgba(0, 0, 0, 0.5)"
    SHADOW_XL = "0 20px 40px rgba(0, 0, 0, 0.6)"
    SHADOW_GLOW = "0 0 20px rgba(0, 212, 255, 0.3)"
    
    # Typography
    FONT_FAMILY = "'Segoe UI', -apple-system, BlinkMacSystemFont, sans-serif"
    FONT_SIZE_XS = "11px"
    FONT_SIZE_SM = "13px"
    FONT_SIZE_MD = "14px"
    FONT_SIZE_LG = "16px"
    FONT_SIZE_XL = "20px"
    FONT_SIZE_2XL = "24px"
    FONT_SIZE_3XL = "32px"
    
    # Spacing
    SPACING_XS = "4px"
    SPACING_SM = "8px"
    SPACING_MD = "12px"
    SPACING_LG = "16px"
    SPACING_XL = "24px"
    SPACING_2XL = "32px"
    
    # Border radius
    RADIUS_SM = "6px"
    RADIUS_MD = "8px"
    RADIUS_LG = "12px"
    RADIUS_XL = "16px"
    RADIUS_FULL = "9999px"


class ProfessionalButton(QPushButton):
    """Professional button with smooth animations and states"""
    
    def __init__(self, text, variant="primary", icon=None, parent=None):
        super().__init__(text, parent)
        self.variant = variant
        self.icon_name = icon
        self.is_hovered = False
        self.is_pressed = False
        
        self.setMinimumHeight(44)
        self.setCursor(Qt.PointingHandCursor)
        
        # Add icon if provided
        if icon:
            self.setIcon(self.style().standardIcon(getattr(QStyle, icon, QStyle.SP_DialogOkButton)))
            self.setIconSize(QSize(18, 18))
        
        # Animation for smooth transitions
        self.animation = QPropertyAnimation(self, b"geometry")
        self.animation.setDuration(150)
        self.animation.setEasingCurve(QEasingCurve.OutCubic)
        
        self.update_style()
    
    def update_style(self):
        styles = {
            "primary": {
                "bg": Theme.ACCENT_PRIMARY,
                "bg_hover": "#00bdee",
                "bg_active": "#00a6d5",
                "text": "#ffffff",
                "shadow": Theme.SHADOW_GLOW
            },
            "secondary": {
                "bg": Theme.BG_ELEVATED,
                "bg_hover": Theme.BG_HOVER,
                "bg_active": Theme.BG_ACTIVE,
                "text": Theme.TEXT_PRIMARY,
                "shadow": Theme.SHADOW_MD
            },
            "success": {
                "bg": Theme.SUCCESS,
                "bg_hover": "#0ea972",
                "bg_active": "#0d9668",
                "text": "#ffffff",
                "shadow": f"0 0 20px {Theme.SUCCESS}60"
            },
            "danger": {
                "bg": Theme.ERROR,
                "bg_hover": "#dc2626",
                "bg_active": "#b91c1c",
                "text": "#ffffff",
                "shadow": f"0 0 20px {Theme.ERROR}60"
            },
            "ghost": {
                "bg": "transparent",
                "bg_hover": Theme.BG_HOVER,
                "bg_active": Theme.BG_ACTIVE,
                "text": Theme.TEXT_SECONDARY,
                "shadow": "none"
            }
        }
        
        style = styles.get(self.variant, styles["primary"])
        
        self.setStyleSheet(f"""
            QPushButton {{
                background: {style['bg']};
                color: {style['text']};
                border: 1px solid {Theme.BORDER_SECONDARY if self.variant == 'ghost' else 'transparent'};
                border-radius: {Theme.RADIUS_MD};
                font-size: {Theme.FONT_SIZE_MD};
                font-weight: 600;
                font-family: {Theme.FONT_FAMILY};
                padding: {Theme.SPACING_MD} {Theme.SPACING_XL};
                text-align: center;
            }}
            QPushButton:hover {{
                background: {style['bg_hover']};
            }}
            QPushButton:pressed {{
                background: {style['bg_active']};
            }}
            QPushButton:disabled {{
                background: {Theme.BG_SECONDARY};
                color: {Theme.TEXT_DISABLED};
            }}
        """)


class ProfessionalCard(QFrame):
    """Professional card with gradient background and shadow"""
    
    def __init__(self, title=None, parent=None):
        super().__init__(parent)
        self.setObjectName("professionalCard")
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(16)
        
        if title:
            title_label = QLabel(title)
            title_label.setWordWrap(True)
            title_label.setStyleSheet(f"""
                font-size: {Theme.FONT_SIZE_LG};
                font-weight: 700;
                color: {Theme.TEXT_PRIMARY};
                font-family: {Theme.FONT_FAMILY};
            """)
            layout.addWidget(title_label)
        
        self.content_layout = QVBoxLayout()
        self.content_layout.setSpacing(12)
        layout.addLayout(self.content_layout)
        
        self.setStyleSheet(f"""
            QFrame#professionalCard {{
                background: qlineargradient(
                    x1:0, y1:0, x2:0, y2:1,
                    stop:0 {Theme.BG_CARD},
                    stop:1 {Theme.BG_SECONDARY}
                );
                border: 1px solid {Theme.BORDER_PRIMARY};
                border-radius: {Theme.RADIUS_LG};
            }}
        """)


class MetricCardPro(QFrame):
    """Professional metric display with animations"""
    
    def __init__(self, title, value, icon, color, parent=None):
        super().__init__(parent)
        self.value_text = str(value)
        self.color = color
        
        self.setFixedHeight(100)  # Reduced from 130
        self.setMinimumWidth(200)  # Reduced from 220
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 14, 16, 14)  # Reduced padding
        layout.setSpacing(8)  # Reduced spacing
        
        # Header with icon and title
        header = QHBoxLayout()
        header.setSpacing(10)
        
        # Icon circle - Smaller
        icon_label = QLabel(icon)
        icon_label.setFixedSize(34, 34)  # Reduced from 40
        icon_label.setAlignment(Qt.AlignCenter)
        icon_label.setStyleSheet(f"""
            background: qlineargradient(
                x1:0, y1:0, x2:1, y2:1,
                stop:0 {color},
                stop:1 {Theme.ACCENT_SECONDARY}
            );
            border-radius: 17px;
            color: white;
            font-size: 18px;
            font-weight: bold;
        """)
        header.addWidget(icon_label)
        
        # Title
        title_label = QLabel(title)
        title_label.setWordWrap(True)
        title_label.setStyleSheet(f"""
            color: {Theme.TEXT_TERTIARY};
            font-size: {Theme.FONT_SIZE_XS};
            font-weight: 600;
            font-family: {Theme.FONT_FAMILY};
            text-transform: uppercase;
            letter-spacing: 0.5px;
        """)
        header.addWidget(title_label)
        header.addStretch()
        
        layout.addLayout(header)
        
        # Value
        self.value_label = QLabel(self.value_text)
        self.value_label.setWordWrap(False)
        self.value_label.setStyleSheet(f"""
            color: {Theme.TEXT_PRIMARY};
            font-size: 24px;
            font-weight: 700;
            font-family: {Theme.FONT_FAMILY};
        """)
        layout.addWidget(self.value_label)
        
        # Progress indicator
        self.progress_bar = QProgressBar()
        self.progress_bar.setMaximum(100)
        self.progress_bar.setValue(75)
        self.progress_bar.setTextVisible(False)
        self.progress_bar.setFixedHeight(4)
        self.progress_bar.setStyleSheet(f"""
            QProgressBar {{
                background: {Theme.BG_SECONDARY};
                border: none;
                border-radius: 2px;
            }}
            QProgressBar::chunk {{
                background: qlineargradient(
                    x1:0, y1:0, x2:1, y2:0,
                    stop:0 {color},
                    stop:1 {Theme.ACCENT_SECONDARY}
                );
                border-radius: 2px;
            }}
        """)
        layout.addWidget(self.progress_bar)
        
        self.setStyleSheet(f"""
            QFrame {{
                background: qlineargradient(
                    x1:0, y1:0, x2:0, y2:1,
                    stop:0 {Theme.BG_ELEVATED},
                    stop:1 {Theme.BG_CARD}
                );
                border: 1px solid {Theme.BORDER_SECONDARY};
                border-radius: {Theme.RADIUS_LG};
            }}
            QFrame:hover {{
                border: 1px solid {color}40;
            }}
        """)
    
    def update_value(self, value):
        self.value_text = str(value)
        self.value_label.setText(self.value_text)
        
        # Animate progress bar
        self.progress_bar.setValue(min(100, int(value) * 2))


class ProfessionalInput(QLineEdit):
    """Professional input field with focus states"""
    
    def __init__(self, placeholder="", parent=None):
        super().__init__(parent)
        self.setPlaceholderText(placeholder)
        self.setMinimumHeight(44)
        
        self.setStyleSheet(f"""
            QLineEdit {{
                background: {Theme.BG_SECONDARY};
                color: {Theme.TEXT_PRIMARY};
                border: 2px solid {Theme.BORDER_PRIMARY};
                border-radius: {Theme.RADIUS_MD};
                padding: {Theme.SPACING_MD} {Theme.SPACING_LG};
                font-size: {Theme.FONT_SIZE_MD};
                font-family: {Theme.FONT_FAMILY};
            }}
            QLineEdit:hover {{
                border-color: {Theme.BORDER_ACCENT}40;
            }}
            QLineEdit:focus {{
                border-color: {Theme.BORDER_FOCUS};
                background: {Theme.BG_TERTIARY};
            }}
            QLineEdit::placeholder {{
                color: {Theme.TEXT_MUTED};
            }}
        """)


class ProfessionalTable(QTableWidget):
    """Professional table with enhanced styling"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        # Table properties
        self.setAlternatingRowColors(True)
        self.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.setSelectionMode(QAbstractItemView.SingleSelection)
        self.setShowGrid(False)
        self.verticalHeader().setVisible(False)
        self.horizontalHeader().setStretchLastSection(True)
        self.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
        self.horizontalHeader().setMinimumSectionSize(100)
        self.setWordWrap(False)
        
        # Enable text eliding for long content
        self.setTextElideMode(Qt.ElideRight)
        
        self.setStyleSheet(f"""
            QTableWidget {{
                background: {Theme.BG_SECONDARY};
                color: {Theme.TEXT_PRIMARY};
                border: 1px solid {Theme.BORDER_PRIMARY};
                border-radius: {Theme.RADIUS_MD};
                font-size: {Theme.FONT_SIZE_SM};
                font-family: {Theme.FONT_FAMILY};
                gridline-color: {Theme.BORDER_SECONDARY};
            }}
            QTableWidget::item {{
                padding: {Theme.SPACING_MD};
                border: none;
            }}
            QTableWidget::item:selected {{
                background: {Theme.ACCENT_PRIMARY}20;
                color: {Theme.ACCENT_PRIMARY};
            }}
            QTableWidget::item:hover {{
                background: {Theme.BG_HOVER};
            }}
            QHeaderView::section {{
                background: {Theme.BG_ELEVATED};
                color: {Theme.TEXT_SECONDARY};
                padding: {Theme.SPACING_MD} {Theme.SPACING_LG};
                border: none;
                border-bottom: 2px solid {Theme.ACCENT_PRIMARY};
                font-weight: 600;
                font-size: {Theme.FONT_SIZE_SM};
                text-transform: uppercase;
                letter-spacing: 0.5px;
            }}
            QTableWidget::item:alternate {{
                background: {Theme.BG_TERTIARY};
            }}
            QScrollBar:vertical {{
                background: {Theme.BG_SECONDARY};
                width: 12px;
                border-radius: 6px;
            }}
            QScrollBar::handle:vertical {{
                background: {Theme.BORDER_PRIMARY};
                border-radius: 6px;
                min-height: 30px;
            }}
            QScrollBar::handle:vertical:hover {{
                background: {Theme.ACCENT_PRIMARY}60;
            }}
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
                height: 0px;
            }}
        """)


class StatusBadge(QLabel):
    """Professional status badge"""
    
    def __init__(self, text, status="default", parent=None):
        super().__init__(text, parent)
        self.status = status
        self.update_style()
    
    def update_style(self):
        colors = {
            "success": (Theme.SUCCESS, "#ffffff"),
            "warning": (Theme.WARNING, "#ffffff"),
            "error": (Theme.ERROR, "#ffffff"),
            "info": (Theme.INFO, "#ffffff"),
            "default": (Theme.BG_ELEVATED, Theme.TEXT_SECONDARY)
        }
        
        bg, text = colors.get(self.status, colors["default"])
        
        self.setStyleSheet(f"""
            QLabel {{
                background: {bg};
                color: {text};
                padding: {Theme.SPACING_XS} {Theme.SPACING_MD};
                border-radius: {Theme.RADIUS_FULL};
                font-size: {Theme.FONT_SIZE_XS};
                font-weight: 600;
                font-family: {Theme.FONT_FAMILY};
                text-transform: uppercase;
                letter-spacing: 0.5px;
            }}
        """)


class WorkerThread(QThread):
    """Background worker with enhanced signals"""
    progress = Signal(int, str)
    result = Signal(dict)
    error = Signal(str)
    status_update = Signal(str, str)  # (message, status_type)
    live_result = Signal(dict)  # For live channel updates
    
    def __init__(self, task_type, params, file_lock=None):
        super().__init__()
        self.task_type = task_type
        self.params = params
        self.driver = None
        self._is_running = True
        self.file_lock = file_lock  # For thread-safe CSV writes
    
    def run(self):
        try:
            self.status_update.emit("Starting task...", "info")
            
            if self.task_type == "scrape":
                self.status_update.emit("Initializing browser...", "info")
                self.progress.emit(5, "Setting up Chrome driver...")
                self.driver = setup_driver()
                
                self.status_update.emit("Navigating to YouTube...", "info")
                self.progress.emit(10, "Opening YouTube...")
                go_to_youtube(self.driver)
                
                self.status_update.emit("Searching for content...", "info")
                self.progress.emit(15, f"Searching: {self.params['topic']}...")
                search_topic(self.driver, self.params['topic'])
                
                # Get filter combinations from params or use defaults
                filter_combinations = self.params.get('filter_combinations', [
                    ["Today", "Video"],
                    ["Today", "Video", "Upload date"],
                    ["This week", "Video"],
                    ["This week", "Video", "Upload date"],
                    ["This month", "Video"],
                    ["Video", "Upload date"],
                ])
                
                total_filters = len(filter_combinations)
                all_channels = []
                seen_links = set()
                
                for idx, filters in enumerate(filter_combinations):
                    if not self._is_running:
                        break
                    
                    progress = 20 + int((idx / total_filters) * 70)
                    self.status_update.emit(f"Applying filter {idx+1}/{total_filters}: {', '.join(filters)}", "info")
                    self.progress.emit(progress, f"Filter {idx+1}/{total_filters}: {', '.join(filters)}")
                    
                    try:
                        # Refresh and apply new filters with error handling
                        self.driver.refresh()
                        time.sleep(3)
                        
                        # Try to apply filters, skip if it fails
                        try:
                            apply_advanced_filters(self.driver, filters)
                            time.sleep(3)
                        except Exception as filter_error:
                            self.status_update.emit(
                                f"⚠️ Skipping filter {', '.join(filters)}: {str(filter_error)[:50]}", 
                                "warning"
                            )
                            continue  # Skip this filter combination
                        
                        # Scroll and collect results
                        self.status_update.emit(f"Scrolling and collecting results...", "info")
                        
                        # Use the views range from params
                        min_views = self.params.get('min_views', 0)
                        max_views = self.params.get('max_views', 10000)
                        
                        # Live scrolling and collecting
                        try:
                            last_height = self.driver.execute_script("return document.documentElement.scrollHeight")
                        except:
                            last_height = 0
                            
                        wait_count = 0
                        scroll_count = 0
                        max_scrolls = self.params.get('max_scrolls', 10)
                        
                        while scroll_count < max_scrolls and self._is_running:
                            scroll_count += 1
                            
                            try:
                                self.driver.execute_script("window.scrollTo(0, document.documentElement.scrollHeight);")
                                time.sleep(2)
                            except Exception as scroll_error:
                                self.status_update.emit(f"⚠️ Scroll error: {str(scroll_error)[:30]}", "warning")
                                break
                            
                            self.status_update.emit(
                                f"Scroll {scroll_count}/{max_scrolls} - Filter {idx+1}/{total_filters}", 
                                "info"
                            )
                            
                            # Get video details with error handling
                            try:
                                video_details = get_video_details(self.driver)
                            except Exception as details_error:
                                self.status_update.emit(f"⚠️ Could not get video details: {str(details_error)[:30]}", "warning")
                                video_details = []
                            
                            links_found_this_scroll = 0
                            
                            # Filter and collect with live updates
                            for item in video_details:
                                link = item.get("Channel Link", "N/A")
                                views = item.get("Views", 0)
                                
                                if (
                                    min_views <= views < max_views
                                    and link != "N/A"
                                    and ("/channel/" in link or "/@" in link)
                                    and link not in seen_links
                                ):
                                    all_channels.append(item)
                                    seen_links.add(link)
                                    links_found_this_scroll += 1
                                    
                                    # LIVE SAVE to CSV immediately (like multi_thread.py)
                                    if self.file_lock:
                                        try:
                                            with self.file_lock:
                                                with open("save.csv", "a", encoding="utf-8") as f:
                                                    f.write(link + "\n")
                                                    f.flush()  # Force immediate write
                                        except Exception as csv_error:
                                            self.status_update.emit(f"⚠️ CSV write error: {str(csv_error)[:30]}", "warning")
                                    
                                    # Emit live result for immediate display
                                    self.live_result.emit({
                                        'channel': item,
                                        'total_count': len(all_channels),
                                        'filter': ', '.join(filters),
                                        'scroll': scroll_count
                                    })
                                    
                                    # Update status with emoji like multi_thread.py
                                    self.status_update.emit(
                                        f"✅ Found: {item.get('Channel Name', 'Unknown')} ({views} views) - Total: {len(all_channels)}", 
                                        "success"
                                    )
                            
                            # Show scroll summary
                            if links_found_this_scroll > 0:
                                self.status_update.emit(
                                    f"📊 Scroll {scroll_count}: Found {links_found_this_scroll} new channels", 
                                    "info"
                                )
                            
                            # Check if we've reached the end
                            try:
                                new_height = self.driver.execute_script("return document.documentElement.scrollHeight")
                                if new_height == last_height:
                                    wait_count += 1
                                    if wait_count >= 3:
                                        break
                                else:
                                    wait_count = 0
                                last_height = new_height
                            except:
                                break  # Exit scroll loop if error
                    
                    except Exception as filter_combo_error:
                        # Log error but continue with next filter combination
                        self.status_update.emit(
                            f"⚠️ Error with filter combination {idx+1}: {str(filter_combo_error)[:50]}", 
                            "warning"
                        )
                        continue
                
                self.progress.emit(100, "Scraping completed!")
                self.status_update.emit(f"Successfully found {len(all_channels)} channels", "success")
                self.result.emit({'videos': all_channels, 'count': len(all_channels)})
                
                # Note: CSV is saved live as channels are found, no need to save at end
                thread_id = self.params.get('thread_id', 0)
                self.status_update.emit(
                    f"✅ Thread {thread_id}: Completed! Found {len(all_channels)} channels", 
                    "success"
                )
                
                # Properly close driver
                self.cleanup_driver()
                
            elif self.task_type == "email":
                self.status_update.emit("Starting email finder...", "info")
                self.progress.emit(20, "Initializing email search...")
                
                # Track emails found
                emails_count = [0]  # Use list to allow modification in callbacks
                
                def progress_callback(message):
                    """Handle progress updates from email finder"""
                    self.status_update.emit(message, "info")
                
                def result_callback(event_type, channel, payload):
                    """Handle result events from email finder"""
                    if event_type == 'email':
                        emails_count[0] += len(payload.get('emails', []))
                        self.status_update.emit(
                            f"✅ Email found: {', '.join(payload.get('emails', []))} - Total: {emails_count[0]}", 
                            "success"
                        )
                    elif event_type == 'social':
                        self.status_update.emit(
                            f"📱 Social media found for {channel[:50]}...", 
                            "info"
                        )
                    elif event_type == 'signin':
                        self.status_update.emit(
                            f"🔐 Sign-in required for {channel[:50]}...", 
                            "warning"
                        )
                
                def error_callback(exception, context):
                    """Handle errors from email finder"""
                    self.status_update.emit(f"⚠️ Error: {str(exception)[:50]}", "warning")
                
                try:
                    # Call email finder with proper parameters
                    run_email_finder(
                        input_csv=self.params['csv_file'],
                        num_windows=self.params.get('num_windows', 3),
                        progress_callback=progress_callback,
                        result_callback=result_callback,
                        error_callback=error_callback
                    )
                    
                    emails_found = emails_count[0]
                    
                except Exception as e:
                    # Handle case where no valid links found or other errors
                    error_msg = str(e)
                    if "No valid YouTube links" in error_msg:
                        emails_found = 0
                        self.status_update.emit("No valid YouTube links found in CSV", "error")
                    else:
                        emails_found = 0
                        self.status_update.emit(f"Error: {error_msg[:50]}", "error")
                
                self.progress.emit(100, "Email search completed!")
                self.status_update.emit(f"Found {emails_found} emails", "success")
                self.result.emit({'emails_found': emails_found})
                
        except Exception as e:
            self.status_update.emit(f"Error: {str(e)}", "error")
            self.error.emit(str(e))
            # Cleanup on error
            self.cleanup_driver()
    
    def cleanup_driver(self):
        """Safely cleanup Chrome driver"""
        if self.driver:
            try:
                self.driver.quit()
            except Exception as e:
                # Silently handle cleanup errors
                try:
                    self.driver.close()
                except:
                    pass
            finally:
                self.driver = None
    
    def stop(self):
        """Stop the thread gracefully"""
        self._is_running = False
        self.cleanup_driver()
        self.quit()


class YouTubeAutomationPro(QMainWindow):
    """Professional YouTube Automation Suite"""
    
    def __init__(self):
        super().__init__()
        self.setWindowTitle("YTReach Pro - Professional YouTube Automation")
        self.setMinimumSize(1400, 900)
        
        # Session tracking
        self.start_time = time.time()
        self.stats = {
            'channels_scraped': 0,
            'emails_found': 0,
            'success_rate': 0
        }
        
        # Driver and thread tracking
        self.active_drivers = []
        self.active_threads = []
        
        # File lock for concurrent CSV writes (multi-threading)
        self.file_lock = threading.Lock()
        
        self.init_ui()
        self.setup_timer()
        
    def init_ui(self):
        """Initialize professional interface"""
        central = QWidget()
        self.setCentralWidget(central)
        main_layout = QHBoxLayout(central)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)
        
        # Create sidebar
        self.create_sidebar(main_layout)
        
        # Create main content area
        self.create_main_content(main_layout)
        
        # Apply global styling
        self.apply_global_styles()
    
    def create_sidebar(self, parent_layout):
        """Create professional sidebar navigation"""
        sidebar = QFrame()
        sidebar.setFixedWidth(260)  # Reduced from 280
        sidebar.setObjectName("sidebar")
        
        sidebar_layout = QVBoxLayout(sidebar)
        sidebar_layout.setContentsMargins(0, 0, 0, 0)
        sidebar_layout.setSpacing(0)
        
        # Logo/Brand section - More compact
        brand = QFrame()
        brand.setFixedHeight(80)  # Reduced from 100
        brand_layout = QVBoxLayout(brand)
        brand_layout.setContentsMargins(20, 20, 20, 20)
        
        brand_title = QLabel("YTReach")
        brand_title.setWordWrap(False)
        brand_title.setStyleSheet(f"""
            font-size: 28px;
            font-weight: 800;
            color: {Theme.ACCENT_PRIMARY};
            font-family: {Theme.FONT_FAMILY};
        """)
        brand_layout.addWidget(brand_title)
        
        brand_subtitle = QLabel("Professional Edition")
        brand_subtitle.setWordWrap(True)
        brand_subtitle.setStyleSheet(f"""
            font-size: {Theme.FONT_SIZE_XS};
            color: {Theme.TEXT_TERTIARY};
            font-family: {Theme.FONT_FAMILY};
        """)
        brand_layout.addWidget(brand_subtitle)
        
        sidebar_layout.addWidget(brand)
        
        # Navigation buttons
        nav_container = QWidget()
        nav_layout = QVBoxLayout(nav_container)
        nav_layout.setContentsMargins(16, 16, 16, 16)
        nav_layout.setSpacing(8)
        
        self.nav_buttons = []
        nav_items = [
            ("🎥", "Video Scraping", 0),
            ("📧", "Email Finder", 1),
            ("📊", "Analytics", 2),
            ("⚙️", "Settings", 3)
        ]
        
        for icon, text, index in nav_items:
            btn = QPushButton(f"{icon}  {text}")
            btn.setCheckable(True)
            btn.setFixedHeight(52)
            btn.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
            btn.clicked.connect(lambda checked, idx=index: self.switch_panel(idx))
            btn.setStyleSheet(f"""
                QPushButton {{
                    background: transparent;
                    color: {Theme.TEXT_SECONDARY};
                    border: none;
                    border-radius: {Theme.RADIUS_MD};
                    padding: {Theme.SPACING_MD} {Theme.SPACING_LG};
                    text-align: left;
                    font-size: {Theme.FONT_SIZE_MD};
                    font-weight: 600;
                    font-family: {Theme.FONT_FAMILY};
                    min-height: 52px;
                }}
                QPushButton:hover {{
                    background: {Theme.BG_HOVER};
                    color: {Theme.TEXT_PRIMARY};
                }}
                QPushButton:checked {{
                    background: qlineargradient(
                        x1:0, y1:0, x2:1, y2:0,
                        stop:0 {Theme.ACCENT_PRIMARY},
                        stop:1 {Theme.ACCENT_SECONDARY}
                    );
                    color: white;
                }}
            """)
            nav_layout.addWidget(btn)
            self.nav_buttons.append(btn)
        
        self.nav_buttons[0].setChecked(True)
        
        sidebar_layout.addWidget(nav_container)
        sidebar_layout.addStretch()
        
        # Session info
        session_info = QFrame()
        session_info.setObjectName("sessionInfo")
        session_layout = QVBoxLayout(session_info)
        session_layout.setContentsMargins(24, 16, 24, 16)
        
        self.session_label = QLabel("Session: 00:00:00")
        self.session_label.setWordWrap(False)
        self.session_label.setStyleSheet(f"""
            color: {Theme.TEXT_TERTIARY};
            font-size: {Theme.FONT_SIZE_SM};
            font-weight: 500;
            font-family: {Theme.FONT_FAMILY};
        """)
        session_layout.addWidget(self.session_label)
        
        sidebar_layout.addWidget(session_info)
        
        sidebar.setStyleSheet(f"""
            QFrame#sidebar {{
                background: qlineargradient(
                    x1:0, y1:0, x2:0, y2:1,
                    stop:0 {Theme.BG_SECONDARY},
                    stop:1 {Theme.BG_PRIMARY}
                );
                border-right: 1px solid {Theme.BORDER_PRIMARY};
            }}
            QFrame#sessionInfo {{
                background: {Theme.BG_TERTIARY};
                border-top: 1px solid {Theme.BORDER_PRIMARY};
            }}
        """)
        
        parent_layout.addWidget(sidebar)
    
    def create_main_content(self, parent_layout):
        """Create main content area"""
        main_container = QWidget()
        main_layout = QVBoxLayout(main_container)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)
        
        # Header with metrics
        self.create_header(main_layout)
        
        # Content panels
        self.stack = QStackedWidget()
        self.stack.addWidget(self.create_scraping_panel())
        self.stack.addWidget(self.create_email_panel())
        self.stack.addWidget(self.create_analytics_panel())
        self.stack.addWidget(self.create_settings_panel())
        
        main_layout.addWidget(self.stack)
        
        # Status bar
        self.create_status_bar(main_layout)
        
        parent_layout.addWidget(main_container)
    
    def create_header(self, parent_layout):
        """Create professional header with metrics"""
        header = QFrame()
        header.setFixedHeight(140)  # Reduced from 170
        header.setObjectName("header")
        
        header_layout = QVBoxLayout(header)
        header_layout.setContentsMargins(24, 16, 24, 16)  # Reduced padding
        header_layout.setSpacing(16)  # Reduced spacing
        
        # Title row
        title_row = QHBoxLayout()
        
        title = QLabel("Dashboard")
        title.setWordWrap(False)
        title.setStyleSheet(f"""
            font-size: {Theme.FONT_SIZE_XL};
            font-weight: 700;
            color: {Theme.TEXT_PRIMARY};
            font-family: {Theme.FONT_FAMILY};
        """)
        title_row.addWidget(title)
        title_row.addStretch()
        
        # Quick action button - Smaller
        quick_btn = ProfessionalButton("⚡ Quick Start", "primary")
        quick_btn.setFixedHeight(36)  # Smaller button
        quick_btn.clicked.connect(self.quick_start)
        title_row.addWidget(quick_btn)
        
        header_layout.addLayout(title_row)
        
        # Metrics row - More compact
        metrics_row = QHBoxLayout()
        metrics_row.setSpacing(16)  # Reduced spacing
        
        self.metric_channels = MetricCardPro(
            "Channels", "0", "📺", Theme.ACCENT_PRIMARY
        )
        metrics_row.addWidget(self.metric_channels)
        
        self.metric_emails = MetricCardPro(
            "Emails", "0", "📧", Theme.SUCCESS
        )
        metrics_row.addWidget(self.metric_emails)
        
        self.metric_success = MetricCardPro(
            "Success Rate", "0%", "✓", Theme.INFO
        )
        metrics_row.addWidget(self.metric_success)
        
        metrics_row.addStretch()
        
        header_layout.addLayout(metrics_row)
        
        header.setStyleSheet(f"""
            QFrame#header {{
                background: qlineargradient(
                    x1:0, y1:0, x2:1, y2:1,
                    stop:0 {Theme.BG_SECONDARY},
                    stop:1 {Theme.BG_TERTIARY}
                );
                border-bottom: 1px solid {Theme.BORDER_PRIMARY};
            }}
        """)
        
        parent_layout.addWidget(header)
    
    def create_scraping_panel(self):
        """Create professional video scraping panel with optimized layout"""
        panel = QWidget()
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(20)
        
        # Main content in horizontal split
        content_splitter = QHBoxLayout()
        content_splitter.setSpacing(20)
        
        # LEFT COLUMN - Configuration (40% width)
        left_column = QVBoxLayout()
        left_column.setSpacing(16)
        
        # Search Topics Card - Compact
        topics_card = ProfessionalCard("🎯 Search Topics")
        topics_card.setMaximumHeight(220)
        
        self.topics_input = QTextEdit()
        self.topics_input.setPlaceholderText("Enter topics (one per line):\n\nTech Reviews\nGaming Tutorials\nCooking Shows")
        self.topics_input.setMaximumHeight(100)
        self.topics_input.setStyleSheet(f"""
            QTextEdit {{
                background: {Theme.BG_ELEVATED};
                border: 2px solid {Theme.BORDER_PRIMARY};
                border-radius: {Theme.RADIUS_MD};
                padding: 10px;
                color: {Theme.TEXT_PRIMARY};
                font-family: {Theme.FONT_FAMILY};
                font-size: {Theme.FONT_SIZE_MD};
            }}
            QTextEdit:focus {{
                border-color: {Theme.ACCENT_PRIMARY};
                background: {Theme.BG_CARD};
            }}
        """)
        topics_card.content_layout.addWidget(self.topics_input)
        
        # Chrome windows in same card
        windows_row = QHBoxLayout()
        windows_row.setSpacing(12)
        windows_label = QLabel("⚡ Parallel Windows:")
        windows_label.setStyleSheet(f"color: {Theme.TEXT_SECONDARY}; font-weight: 600;")
        windows_row.addWidget(windows_label)
        
        self.chrome_windows_spin = QSpinBox()
        self.chrome_windows_spin.setRange(1, 20)
        self.chrome_windows_spin.setValue(3)
        self.chrome_windows_spin.setFixedWidth(80)
        self.chrome_windows_spin.setStyleSheet(f"""
            QSpinBox {{
                background: {Theme.BG_ELEVATED};
                border: 2px solid {Theme.BORDER_PRIMARY};
                border-radius: {Theme.RADIUS_SM};
                padding: 6px 10px;
                color: {Theme.TEXT_PRIMARY};
                font-weight: 600;
                font-size: {Theme.FONT_SIZE_MD};
            }}
            QSpinBox:focus {{
                border-color: {Theme.ACCENT_PRIMARY};
            }}
        """)
        windows_row.addWidget(self.chrome_windows_spin)
        
        windows_info = QLabel("(3-5 recommended)")
        windows_info.setStyleSheet(f"color: {Theme.TEXT_TERTIARY}; font-size: {Theme.FONT_SIZE_SM};")
        windows_row.addWidget(windows_info)
        windows_row.addStretch()
        
        topics_card.content_layout.addLayout(windows_row)
        left_column.addWidget(topics_card)
        
        # Filters Card - Compact Grid
        filters_card = ProfessionalCard("🔍 Filters")
        filters_grid = QGridLayout()
        filters_grid.setSpacing(12)
        filters_grid.setContentsMargins(0, 0, 0, 0)
        
        # Compact filter inputs with better visual hierarchy
        def create_filter_row(label_text, min_input, max_input, row):
            label = QLabel(label_text)
            label.setStyleSheet(f"color: {Theme.TEXT_SECONDARY}; font-weight: 600; font-size: {Theme.FONT_SIZE_SM};")
            label.setFixedWidth(90)
            filters_grid.addWidget(label, row, 0)
            filters_grid.addWidget(min_input, row, 1)
            filters_grid.addWidget(QLabel("to"), row, 2, Qt.AlignCenter)
            filters_grid.addWidget(max_input, row, 3)
        
        self.views_min_input = ProfessionalInput("Min")
        self.views_max_input = ProfessionalInput("Max")
        create_filter_row("📊 Views:", self.views_min_input, self.views_max_input, 0)
        
        self.sub_min_input = ProfessionalInput("Min")
        self.sub_max_input = ProfessionalInput("Max")
        create_filter_row("👥 Subscribers:", self.sub_min_input, self.sub_max_input, 1)
        
        self.videos_min_input = ProfessionalInput("e.g., 100")
        videos_label = QLabel("🎬 Min Videos:")
        videos_label.setStyleSheet(f"color: {Theme.TEXT_SECONDARY}; font-weight: 600; font-size: {Theme.FONT_SIZE_SM};")
        videos_label.setFixedWidth(90)
        filters_grid.addWidget(videos_label, 2, 0)
        filters_grid.addWidget(self.videos_min_input, 2, 1, 1, 3)
        
        filters_card.content_layout.addLayout(filters_grid)
        left_column.addWidget(filters_card)
        
        # Action buttons - Prominent
        btn_row = QHBoxLayout()
        btn_row.setSpacing(12)
        
        self.scrape_btn = ProfessionalButton("🚀 Start Multi-Thread Scraping", "primary")
        self.scrape_btn.setFixedHeight(48)
        self.scrape_btn.clicked.connect(self.start_scraping)
        btn_row.addWidget(self.scrape_btn)
        
        clear_btn = ProfessionalButton("Clear", "ghost")
        clear_btn.setFixedHeight(48)
        clear_btn.clicked.connect(self.clear_scraping_inputs)
        btn_row.addWidget(clear_btn)
        
        left_column.addLayout(btn_row)
        left_column.addStretch()
        
        # Legacy compatibility
        self.topic_input = ProfessionalInput("e.g., Tech Reviews")
        self.topic_input.setVisible(False)
        
        # RIGHT COLUMN - Results & Progress (60% width)
        right_column = QVBoxLayout()
        right_column.setSpacing(16)
        
        # Progress Card - Compact
        progress_card = ProfessionalCard("⚡ Progress")
        progress_card.setMaximumHeight(120)
        
        self.scrape_progress = QProgressBar()
        self.scrape_progress.setTextVisible(True)
        self.scrape_progress.setFixedHeight(28)
        self.scrape_progress.setStyleSheet(f"""
            QProgressBar {{
                background: {Theme.BG_SECONDARY};
                border: 1px solid {Theme.BORDER_PRIMARY};
                border-radius: {Theme.RADIUS_MD};
                text-align: center;
                color: {Theme.TEXT_PRIMARY};
                font-weight: 600;
                font-family: {Theme.FONT_FAMILY};
                font-size: {Theme.FONT_SIZE_SM};
            }}
            QProgressBar::chunk {{
                background: qlineargradient(
                    x1:0, y1:0, x2:1, y2:0,
                    stop:0 {Theme.ACCENT_PRIMARY},
                    stop:1 {Theme.ACCENT_SECONDARY}
                );
                border-radius: {Theme.RADIUS_MD};
            }}
        """)
        progress_card.content_layout.addWidget(self.scrape_progress)
        
        self.scrape_status = QLabel("Ready to start scraping")
        self.scrape_status.setWordWrap(True)
        self.scrape_status.setStyleSheet(f"""
            color: {Theme.TEXT_SECONDARY};
            font-size: {Theme.FONT_SIZE_SM};
            font-family: {Theme.FONT_FAMILY};
            padding: {Theme.SPACING_SM};
        """)
        progress_card.content_layout.addWidget(self.scrape_status)
        right_column.addWidget(progress_card)
        
        # Results table - Takes most space
        results_card = ProfessionalCard("📊 Live Results")
        
        self.scrape_table = ProfessionalTable()
        self.scrape_table.setColumnCount(5)
        self.scrape_table.setHorizontalHeaderLabels([
            "CHANNEL NAME", "VIEWS", "SUBS", "VIDEO TITLE", "LINK"
        ])
        # Optimized column widths
        header = self.scrape_table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.Interactive)  # Channel Name
        header.setSectionResizeMode(1, QHeaderView.Fixed)        # Views
        header.setSectionResizeMode(2, QHeaderView.Fixed)        # Subscribers
        header.setSectionResizeMode(3, QHeaderView.Stretch)      # Video Title
        header.setSectionResizeMode(4, QHeaderView.Fixed)        # Link
        
        self.scrape_table.setColumnWidth(0, 180)  # Channel
        self.scrape_table.setColumnWidth(1, 100)  # Views
        self.scrape_table.setColumnWidth(2, 100)  # Subs (reduced from 110)
        # Video Title stretches
        self.scrape_table.setColumnWidth(4, 120)  # Link (increased from 100)
        
        results_card.content_layout.addWidget(self.scrape_table)
        right_column.addWidget(results_card)
        
        # Assemble columns with width ratio 40:60
        left_widget = QWidget()
        left_widget.setLayout(left_column)
        left_widget.setMaximumWidth(450)
        
        right_widget = QWidget()
        right_widget.setLayout(right_column)
        
        content_splitter.addWidget(left_widget)
        content_splitter.addWidget(right_widget, 1)  # Stretch factor
        
        layout.addLayout(content_splitter)
        
        return panel
    
    def create_email_panel(self):
        """Create professional email finder panel with enhanced layout"""
        panel = QWidget()
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(20)
        
        # Main content in horizontal split
        content_splitter = QHBoxLayout()
        content_splitter.setSpacing(20)
        
        # LEFT COLUMN - Configuration (35% width)
        left_column = QVBoxLayout()
        left_column.setSpacing(16)
        
        # File Selection Card - Compact
        file_card = ProfessionalCard("📁 Input File")
        file_card.setMaximumHeight(180)
        
        # CSV file input
        file_label = QLabel("Select CSV file with channel links:")
        file_label.setStyleSheet(f"color: {Theme.TEXT_SECONDARY}; font-size: {Theme.FONT_SIZE_SM}; margin-bottom: 8px;")
        file_card.content_layout.addWidget(file_label)
        
        file_row = QHBoxLayout()
        file_row.setSpacing(12)
        
        self.csv_input = ProfessionalInput("No file selected...")
        self.csv_input.setReadOnly(True)
        file_row.addWidget(self.csv_input)
        
        browse_btn = ProfessionalButton("Browse", "secondary")
        browse_btn.setFixedWidth(100)
        browse_btn.clicked.connect(self.browse_csv)
        file_row.addWidget(browse_btn)
        
        file_card.content_layout.addLayout(file_row)
        
        # File info
        self.file_info_label = QLabel("No file loaded")
        self.file_info_label.setStyleSheet(f"color: {Theme.TEXT_TERTIARY}; font-size: {Theme.FONT_SIZE_XS}; margin-top: 8px;")
        file_card.content_layout.addWidget(self.file_info_label)
        
        left_column.addWidget(file_card)
        
        # Settings Card - Compact
        settings_card = ProfessionalCard("⚙️ Settings")
        settings_card.setMaximumHeight(150)
        
        # Parallel windows setting
        windows_row = QHBoxLayout()
        windows_row.setSpacing(12)
        windows_label = QLabel("⚡ Parallel Windows:")
        windows_label.setStyleSheet(f"color: {Theme.TEXT_SECONDARY}; font-weight: 600; font-size: {Theme.FONT_SIZE_SM};")
        windows_label.setFixedWidth(130)
        windows_row.addWidget(windows_label)
        
        self.email_windows_spin = QSpinBox()
        self.email_windows_spin.setRange(1, 10)
        self.email_windows_spin.setValue(3)
        self.email_windows_spin.setFixedWidth(70)
        self.email_windows_spin.setStyleSheet(f"""
            QSpinBox {{
                background: {Theme.BG_ELEVATED};
                border: 2px solid {Theme.BORDER_PRIMARY};
                border-radius: {Theme.RADIUS_SM};
                padding: 6px 10px;
                color: {Theme.TEXT_PRIMARY};
                font-weight: 600;
                font-size: {Theme.FONT_SIZE_MD};
            }}
            QSpinBox:focus {{
                border-color: {Theme.ACCENT_PRIMARY};
            }}
        """)
        windows_row.addWidget(self.email_windows_spin)
        
        windows_info = QLabel("(recommended: 3-5)")
        windows_info.setStyleSheet(f"color: {Theme.TEXT_TERTIARY}; font-size: {Theme.FONT_SIZE_XS};")
        windows_row.addWidget(windows_info)
        windows_row.addStretch()
        
        settings_card.content_layout.addLayout(windows_row)
        left_column.addWidget(settings_card)
        
        # Action buttons - Prominent
        btn_row = QHBoxLayout()
        btn_row.setSpacing(12)
        
        self.email_btn = ProfessionalButton("🔍 Start Email Finder", "success")
        self.email_btn.setFixedHeight(48)
        self.email_btn.clicked.connect(self.start_email_finder)
        btn_row.addWidget(self.email_btn)
        
        clear_btn = ProfessionalButton("Clear", "ghost")
        clear_btn.setFixedHeight(48)
        clear_btn.clicked.connect(self.clear_email_inputs)
        btn_row.addWidget(clear_btn)
        
        left_column.addLayout(btn_row)
        
        # Statistics Card
        stats_card = ProfessionalCard("📊 Statistics")
        stats_layout = QVBoxLayout()
        stats_layout.setSpacing(12)
        
        self.email_stats_total = QLabel("Total Scanned: 0")
        self.email_stats_total.setStyleSheet(f"color: {Theme.TEXT_SECONDARY}; font-size: {Theme.FONT_SIZE_SM};")
        stats_layout.addWidget(self.email_stats_total)
        
        self.email_stats_found = QLabel("✅ Emails Found: 0")
        self.email_stats_found.setStyleSheet(f"color: {Theme.SUCCESS}; font-size: {Theme.FONT_SIZE_SM}; font-weight: 600;")
        stats_layout.addWidget(self.email_stats_found)
        
        self.email_stats_social = QLabel("📱 Social Only: 0")
        self.email_stats_social.setStyleSheet(f"color: {Theme.INFO}; font-size: {Theme.FONT_SIZE_SM};")
        stats_layout.addWidget(self.email_stats_social)
        
        self.email_stats_signin = QLabel("🔐 Sign-in Required: 0")
        self.email_stats_signin.setStyleSheet(f"color: {Theme.WARNING}; font-size: {Theme.FONT_SIZE_SM};")
        stats_layout.addWidget(self.email_stats_signin)
        
        self.email_stats_none = QLabel("❌ Not Found: 0")
        self.email_stats_none.setStyleSheet(f"color: {Theme.TEXT_TERTIARY}; font-size: {Theme.FONT_SIZE_SM};")
        stats_layout.addWidget(self.email_stats_none)
        
        stats_card.content_layout.addLayout(stats_layout)
        left_column.addWidget(stats_card)
        
        left_column.addStretch()
        
        # RIGHT COLUMN - Results & Progress (65% width)
        right_column = QVBoxLayout()
        right_column.setSpacing(16)
        
        # Progress Card - Compact
        progress_card = ProfessionalCard("⚡ Progress")
        progress_card.setMaximumHeight(120)
        
        self.email_progress = QProgressBar()
        self.email_progress.setTextVisible(True)
        self.email_progress.setFixedHeight(28)
        self.email_progress.setStyleSheet(f"""
            QProgressBar {{
                background: {Theme.BG_SECONDARY};
                border: 1px solid {Theme.BORDER_PRIMARY};
                border-radius: {Theme.RADIUS_MD};
                text-align: center;
                color: {Theme.TEXT_PRIMARY};
                font-weight: 600;
                font-family: {Theme.FONT_FAMILY};
                font-size: {Theme.FONT_SIZE_SM};
            }}
            QProgressBar::chunk {{
                background: qlineargradient(
                    x1:0, y1:0, x2:1, y2:0,
                    stop:0 {Theme.SUCCESS},
                    stop:1 {Theme.INFO}
                );
                border-radius: {Theme.RADIUS_MD};
            }}
        """)
        progress_card.content_layout.addWidget(self.email_progress)
        
        self.email_status = QLabel("Ready to find emails")
        self.email_status.setWordWrap(True)
        self.email_status.setStyleSheet(f"""
            color: {Theme.TEXT_SECONDARY};
            font-size: {Theme.FONT_SIZE_SM};
            font-family: {Theme.FONT_FAMILY};
            padding: {Theme.SPACING_SM};
        """)
        progress_card.content_layout.addWidget(self.email_status)
        right_column.addWidget(progress_card)
        
        # Results table - Takes most space
        results_card = ProfessionalCard("📧 Found Emails")
        
        self.email_table = ProfessionalTable()
        self.email_table.setColumnCount(4)
        self.email_table.setHorizontalHeaderLabels([
            "Channel Link", "Email(s)", "Social Media", "Status"
        ])
        # Optimized column widths
        header = self.email_table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.Interactive)  # Channel
        header.setSectionResizeMode(1, QHeaderView.Interactive)  # Emails
        header.setSectionResizeMode(2, QHeaderView.Stretch)      # Social
        header.setSectionResizeMode(3, QHeaderView.Fixed)        # Status
        
        self.email_table.setColumnWidth(0, 200)  # Channel Link
        self.email_table.setColumnWidth(1, 250)  # Email(s)
        # Social Media stretches
        self.email_table.setColumnWidth(3, 100)  # Status
        
        results_card.content_layout.addWidget(self.email_table)
        right_column.addWidget(results_card)
        
        # Assemble columns with width ratio 35:65
        left_widget = QWidget()
        left_widget.setLayout(left_column)
        left_widget.setMaximumWidth(400)
        
        right_widget = QWidget()
        right_widget.setLayout(right_column)
        
        content_splitter.addWidget(left_widget)
        content_splitter.addWidget(right_widget, 1)  # Stretch factor
        
        layout.addLayout(content_splitter)
        
        return panel
    
    def create_analytics_panel(self):
        """Create analytics panel"""
        panel = QWidget()
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(32, 32, 32, 32)
        layout.setSpacing(24)
        
        card = ProfessionalCard("Analytics Dashboard")
        
        info = QLabel("📊 Advanced analytics coming soon...")
        info.setWordWrap(True)
        info.setAlignment(Qt.AlignCenter)
        info.setStyleSheet(f"""
            color: {Theme.TEXT_TERTIARY};
            font-size: {Theme.FONT_SIZE_LG};
            font-family: {Theme.FONT_FAMILY};
            padding: {Theme.SPACING_2XL};
        """)
        card.content_layout.addWidget(info)
        
        layout.addWidget(card)
        layout.addStretch()
        
        return panel
    
    def create_settings_panel(self):
        """Create settings panel"""
        panel = QWidget()
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(32, 32, 32, 32)
        layout.setSpacing(24)
        
        card = ProfessionalCard("Application Settings")
        
        info = QLabel("⚙️ Settings panel coming soon...")
        info.setWordWrap(True)
        info.setAlignment(Qt.AlignCenter)
        info.setStyleSheet(f"""
            color: {Theme.TEXT_TERTIARY};
            font-size: {Theme.FONT_SIZE_LG};
            font-family: {Theme.FONT_FAMILY};
            padding: {Theme.SPACING_2XL};
        """)
        card.content_layout.addWidget(info)
        
        layout.addWidget(card)
        layout.addStretch()
        
        return panel
    
    def create_status_bar(self, parent_layout):
        """Create professional status bar"""
        status_bar = QFrame()
        status_bar.setFixedHeight(48)
        status_bar.setObjectName("statusBar")
        
        status_layout = QHBoxLayout(status_bar)
        status_layout.setContentsMargins(32, 12, 32, 12)
        
        self.status_message = QLabel("Ready")
        self.status_message.setWordWrap(False)
        self.status_message.setStyleSheet(f"""
            color: {Theme.TEXT_SECONDARY};
            font-size: {Theme.FONT_SIZE_SM};
            font-family: {Theme.FONT_FAMILY};
        """)
        status_layout.addWidget(self.status_message)
        
        status_layout.addStretch()
        
        self.status_badge = StatusBadge("IDLE", "default")
        status_layout.addWidget(self.status_badge)
        
        status_bar.setStyleSheet(f"""
            QFrame#statusBar {{
                background: {Theme.BG_SECONDARY};
                border-top: 1px solid {Theme.BORDER_PRIMARY};
            }}
        """)
        
        parent_layout.addWidget(status_bar)
    
    def create_label(self, text):
        """Create styled label"""
        label = QLabel(text)
        label.setWordWrap(False)
        label.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Fixed)
        label.setStyleSheet(f"""
            color: {Theme.TEXT_SECONDARY};
            font-size: {Theme.FONT_SIZE_SM};
            font-weight: 600;
            font-family: {Theme.FONT_FAMILY};
        """)
        return label
    
    def apply_global_styles(self):
        """Apply global application styles"""
        self.setStyleSheet(f"""
            QMainWindow {{
                background: {Theme.BG_PRIMARY};
            }}
            QWidget {{
                font-family: {Theme.FONT_FAMILY};
            }}
            QToolTip {{
                background: {Theme.BG_ELEVATED};
                color: {Theme.TEXT_PRIMARY};
                border: 1px solid {Theme.BORDER_PRIMARY};
                border-radius: {Theme.RADIUS_SM};
                padding: {Theme.SPACING_SM};
                font-family: {Theme.FONT_FAMILY};
            }}
        """)
    
    def switch_panel(self, index):
        """Switch between panels"""
        self.stack.setCurrentIndex(index)
        
        # Update nav buttons
        for i, btn in enumerate(self.nav_buttons):
            btn.setChecked(i == index)
        
        # Update header title
        titles = ["Dashboard - Video Scraping", "Dashboard - Email Finder", 
                  "Dashboard - Analytics", "Dashboard - Settings"]
        # Note: You'd need to store header title label to update it
    
    def setup_timer(self):
        """Setup session timer"""
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_session_time)
        self.timer.start(1000)
    
    def update_session_time(self):
        """Update session time display"""
        elapsed = int(time.time() - self.start_time)
        hours = elapsed // 3600
        minutes = (elapsed % 3600) // 60
        seconds = elapsed % 60
        self.session_label.setText(f"Session: {hours:02d}:{minutes:02d}:{seconds:02d}")
    
    def quick_start(self):
        """Quick start wizard"""
        QMessageBox.information(
            self,
            "Quick Start",
            "Quick Start wizard coming soon!\n\nThis will guide you through setting up your first automation task.",
            QMessageBox.Ok
        )
    
    def start_scraping(self):
        """Start multi-threaded video scraping (like multi_thread.py)"""
        if not AUTO_AVAILABLE:
            QMessageBox.warning(self, "Module Missing", "Auto module not available!")
            return
        
        # Get topics from multi-line input
        topics_text = self.topics_input.toPlainText().strip()
        if not topics_text:
            QMessageBox.warning(self, "Input Required", "Please enter at least one search topic!")
            return
        
        # Parse topics (one per line)
        topics = [t.strip() for t in topics_text.split('\n') if t.strip()]
        
        if not topics:
            QMessageBox.warning(self, "Input Required", "Please enter valid search topics!")
            return
        
        # Get number of windows to use
        num_windows = self.chrome_windows_spin.value()
        
        # Validate: we can only open as many windows as we have topics
        if len(topics) < num_windows:
            num_windows = len(topics)
            QMessageBox.information(
                self, 
                "Info", 
                f"You entered {len(topics)} topics, so only {num_windows} Chrome windows will be opened."
            )
        
        # Use only the first num_windows topics
        topics_to_process = topics[:num_windows]
        
        self.scrape_btn.setEnabled(False)
        self.status_badge.setText("RUNNING")
        self.status_badge.status = "info"
        self.status_badge.update_style()
        
        # Convert views to integers
        min_views = 0
        max_views = 10000
        try:
            if self.views_min_input.text():
                min_views = int(self.views_min_input.text())
            if self.views_max_input.text():
                max_views = int(self.views_max_input.text())
        except ValueError:
            pass  # Use defaults
        
        # Define comprehensive filter combinations like in auto.py
        filter_combinations = [
            # Today - most recent
            ["Today", "Video"],
            ["Today", "Video", "Upload date"],
            ["Today", "Video", "Under 4 minutes"],
            
            # This week
            ["This week", "Video"],
            ["This week", "Video", "Upload date"],
            ["This week", "Video", "Under 4 minutes"],
            
            # This month
            ["This month", "Video"],
            ["This month", "Video", "Upload date"],
            
            # No time filter
            ["Video", "Upload date"],
        ]
        
        # Initialize CSV file (like multi_thread.py - simple format)
        try:
            with open("save.csv", "w", encoding="utf-8") as f:
                f.write("Channel Link\n")
                f.flush()  # Force write to disk
            self.update_status(f"📝 Initialized save.csv with header", "info")
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Could not initialize CSV: {e}")
            self.scrape_btn.setEnabled(True)
            return
        
        # Clear existing table
        self.scrape_table.setRowCount(0)
        
        # Log start
        self.update_status(
            f"🚀 Starting {num_windows} Chrome windows for {len(topics_to_process)} topics", 
            "info"
        )
        self.update_status(
            f"📊 Views range: {min_views} - {max_views}", 
            "info"
        )
        self.update_status(
            f"🎯 Topics: {', '.join(topics_to_process[:3])}{'...' if len(topics_to_process) > 3 else ''}", 
            "info"
        )
        
        # Create and start a worker thread for EACH topic (multi-threading like multi_thread.py)
        for idx, topic in enumerate(topics_to_process):
            params = {
                'topic': topic,
                'min_views': min_views,
                'max_views': max_views,
                'filter_combinations': filter_combinations,
                'max_scrolls': 10,
                'max_results': 100,
                'thread_id': idx + 1,
                'total_threads': num_windows
            }
            
            worker = WorkerThread("scrape", params, self.file_lock)
            worker.progress.connect(self.update_scrape_progress)
            worker.result.connect(self.handle_scrape_result)
            worker.error.connect(self.handle_error)
            worker.status_update.connect(self.update_status)
            worker.live_result.connect(self.handle_live_result)
            worker.finished.connect(lambda w=worker: self.cleanup_thread(w))
            
            self.active_threads.append(worker)
            worker.start()
            
            self.update_status(f"✅ Started thread {idx+1}/{num_windows} for topic: {topic}", "success")
        
        self.update_status(f"⚡ All {num_windows} threads started! Scraping in parallel...", "success")
        
        self.scrape_btn.setEnabled(False)
        self.status_badge.setText("RUNNING")
        self.status_badge.status = "info"
        self.status_badge.update_style()
        
        # Convert views to integers
        min_views = 0
        max_views = 10000
        try:
            if self.views_min_input.text():
                min_views = int(self.views_min_input.text())
            if self.views_max_input.text():
                max_views = int(self.views_max_input.text())
        except ValueError:
            pass  # Use defaults
        
        # Define comprehensive filter combinations like in auto.py
        filter_combinations = [
            # Today - most recent
            ["Today", "Video"],
            ["Today", "Video", "Upload date"],
            ["Today", "Video", "Under 4 minutes"],
            ["Today", "Video", "4-20 minutes"],
            
            # This week
            ["This week", "Video"],
            ["This week", "Video", "Upload date"],
            ["This week", "Video", "Under 4 minutes"],
            ["This week", "Video", "4-20 minutes"],
            
            # This month
            ["This month", "Video"],
            ["This month", "Video", "Upload date"],
            ["This month", "Video", "Under 4 minutes"],
            
            # No time filter - gets all videos
            ["Video", "Upload date"],
            ["Video", "Under 4 minutes"],
        ]
        
        params = {
            'topic': topic,
            'min_views': min_views,
            'max_views': max_views,
            'filter_combinations': filter_combinations,
            'max_scrolls': 10,
            'max_results': 100
        }
        
        self.worker = WorkerThread("scrape", params)
        self.worker.progress.connect(self.update_scrape_progress)
        self.worker.result.connect(self.handle_scrape_result)
        self.worker.error.connect(self.handle_error)
        self.worker.status_update.connect(self.update_status)
        self.worker.live_result.connect(self.handle_live_result)  # Connect live result signal
        self.worker.finished.connect(lambda: self.cleanup_thread(self.worker))
        self.active_threads.append(self.worker)
        self.worker.start()
    
    def start_email_finder(self):
        """Start email finder"""
        if not EMAIL_FINDER_AVAILABLE:
            QMessageBox.warning(self, "Module Missing", "Email finder module not available!")
            return
        
        csv_file = self.csv_input.text()
        if not csv_file or not os.path.exists(csv_file):
            QMessageBox.warning(self, "File Required", "Please select a valid CSV file!")
            return
        
        self.email_btn.setEnabled(False)
        self.status_badge.setText("RUNNING")
        self.status_badge.status = "info"
        self.status_badge.update_style()
        
        # Get number of parallel windows from spinner
        num_windows = self.email_windows_spin.value() if hasattr(self, 'email_windows_spin') else 3
        
        params = {
            'csv_file': csv_file,
            'num_windows': num_windows
        }
        
        self.worker = WorkerThread("email", params)
        self.worker.progress.connect(self.update_email_progress)
        self.worker.result.connect(self.handle_email_result)
        self.worker.error.connect(self.handle_error)
        self.worker.status_update.connect(self.update_status)
        self.worker.finished.connect(lambda: self.cleanup_thread(self.worker))
        self.active_threads.append(self.worker)
        self.worker.start()
    
    def update_scrape_progress(self, value, message):
        """Update scraping progress"""
        self.scrape_progress.setValue(value)
        self.scrape_status.setText(message)
    
    def update_email_progress(self, value, message):
        """Update email progress"""
        self.email_progress.setValue(value)
        self.email_status.setText(message)
    
    def update_status(self, message, status_type):
        """Update status bar"""
        self.status_message.setText(message)
        
        status_map = {
            "info": "RUNNING",
            "success": "SUCCESS",
            "error": "ERROR"
        }
        
        if status_type in status_map:
            self.status_badge.setText(status_map[status_type])
            self.status_badge.status = status_type
            self.status_badge.update_style()
    
    def handle_live_result(self, data):
        """Handle live channel result - add to table immediately"""
        channel = data.get('channel', {})
        total_count = data.get('total_count', 0)
        filter_name = data.get('filter', 'N/A')
        
        # Add new row at the top for most recent results
        self.scrape_table.insertRow(0)
        
        # Populate row with channel data (matching column headers)
        # Headers: "Channel Name", "Views", "Subscribers", "Video Title", "Link"
        self.scrape_table.setItem(0, 0, QTableWidgetItem(channel.get('Channel Name', 'N/A')))
        self.scrape_table.setItem(0, 1, QTableWidgetItem(str(channel.get('Views', 0))))
        self.scrape_table.setItem(0, 2, QTableWidgetItem(str(channel.get('Subscriber Count', 'N/A'))))
        self.scrape_table.setItem(0, 3, QTableWidgetItem(channel.get('Video Title', 'N/A')))
        
        # Channel Link with clickable format
        link = channel.get('Channel Link', 'N/A')
        link_item = QTableWidgetItem(link if link != 'N/A' else 'No Link')
        link_item.setToolTip(link)  # Show full link on hover
        self.scrape_table.setItem(0, 4, link_item)
        
        # Update metrics
        self.stats['channels_scraped'] = total_count
        self.metric_channels.update_value(total_count)
        
        # Auto-scroll to top to show new result
        self.scrape_table.scrollToTop()
    
    def handle_scrape_result(self, result):
        """Handle scraping completion"""
        self.scrape_btn.setEnabled(True)
        self.status_badge.setText("IDLE")
        self.status_badge.status = "default"
        self.status_badge.update_style()
        
        # Note: Table is already populated via live_result signals
        # This just handles final cleanup
        videos = result.get('videos', [])
        self.stats['channels_scraped'] = len(videos)
        self.metric_channels.update_value(self.stats['channels_scraped'])
    
    def handle_email_result(self, result):
        """Handle email finder results"""
        self.email_btn.setEnabled(True)
        self.status_badge.setText("IDLE")
        self.status_badge.status = "default"
        self.status_badge.update_style()
        
        # Safely get emails_found with default value
        emails_found = result.get('emails_found', 0)
        if emails_found is None:
            emails_found = 0
        
        self.stats['emails_found'] += emails_found
        self.metric_emails.update_value(self.stats['emails_found'])
        
        # Update success rate
        if self.stats['channels_scraped'] > 0:
            rate = (self.stats['emails_found'] / self.stats['channels_scraped']) * 100
            self.stats['success_rate'] = int(rate)
            self.metric_success.update_value(f"{self.stats['success_rate']}%")
    
    def handle_error(self, error_msg):
        """Handle errors"""
        self.scrape_btn.setEnabled(True)
        self.email_btn.setEnabled(True)
        self.status_badge.setText("ERROR")
        self.status_badge.status = "error"
        self.status_badge.update_style()
        
        QMessageBox.critical(self, "Error", f"An error occurred:\n{error_msg}")
    
    def clear_scraping_inputs(self):
        """Clear scraping inputs"""
        self.topic_input.clear()
        self.sub_min_input.clear()
        self.sub_max_input.clear()
        self.views_min_input.clear()
        self.views_max_input.clear()
        self.videos_min_input.clear()
    
    def browse_csv(self):
        """Browse for CSV file and show file info"""
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Select CSV File",
            "",
            "CSV Files (*.csv)"
        )
        if file_path:
            self.csv_input.setText(file_path)
            
            # Show file info
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    lines = sum(1 for _ in f) - 1  # Subtract header
                self.file_info_label.setText(f"✅ Loaded: {lines} channels")
                self.file_info_label.setStyleSheet(f"color: {Theme.SUCCESS}; font-size: {Theme.FONT_SIZE_XS}; margin-top: 8px;")
            except Exception as e:
                self.file_info_label.setText(f"⚠️ Error reading file: {str(e)[:30]}")
                self.file_info_label.setStyleSheet(f"color: {Theme.WARNING}; font-size: {Theme.FONT_SIZE_XS}; margin-top: 8px;")
    
    def clear_email_inputs(self):
        """Clear email finder inputs"""
        self.csv_input.clear()
        self.file_info_label.setText("No file loaded")
        self.file_info_label.setStyleSheet(f"color: {Theme.TEXT_TERTIARY}; font-size: {Theme.FONT_SIZE_XS}; margin-top: 8px;")
        self.email_table.setRowCount(0)
        self.email_stats_total.setText("Total Scanned: 0")
        self.email_stats_found.setText("✅ Emails Found: 0")
        self.email_stats_social.setText("📱 Social Only: 0")
        self.email_stats_signin.setText("🔐 Sign-in Required: 0")
        self.email_stats_none.setText("❌ Not Found: 0")
    
    def cleanup_thread(self, thread):
        """Remove finished thread from active threads list"""
        if thread in self.active_threads:
            self.active_threads.remove(thread)
        
        # Check if all scraping threads are complete
        if len(self.active_threads) == 0:
            self.scrape_btn.setEnabled(True)
            self.status_badge.setText("READY")
            self.status_badge.status = "success"
            self.status_badge.update_style()
            self.update_status("🎉 All threads completed! Scraping finished.", "success")
            
            # Show summary
            total_rows = self.scrape_table.rowCount()
            self.update_status(f"📊 Total channels found: {total_rows}", "info")
    
    def closeEvent(self, event):
        """Handle window close event - cleanup all resources"""
        # Stop all active threads
        for thread in self.active_threads:
            if thread and thread.isRunning():
                try:
                    thread.stop()
                    thread.wait(1000)  # Wait up to 1 second
                    if thread.isRunning():
                        thread.terminate()
                except:
                    pass
        
        # Clear thread list
        self.active_threads.clear()
        
        # Accept the close event
        event.accept()


def main():
    app = QApplication(sys.argv)
    
    # Set application font
    font = QFont(Theme.FONT_FAMILY.strip("'"))
    font.setPixelSize(14)
    app.setFont(font)
    
    window = YouTubeAutomationPro()
    window.show()
    
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
