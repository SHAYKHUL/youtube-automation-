# PowerShell script to recover all missing Python modules from VS Code history

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Recovering Missing Python Modules" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

$historyBase = "$env:APPDATA\Code\User\History"
$targetDir = "C:\Users\pc\Desktop\YoutubeAutomation"

# Define modules and their history folders (using most recent version for each)
$modules = @{
    'auto.py' = '-18042288'
    'youtube_login.py' = '574320d0'
    'email_finder.py' = '4ec999d6'
    'subcunt.py' = '3e0aacc5'
    'multi_thread.py' = 'de00fa1'
    'database_manager.py' = '-6deba918'
    'chrome_utils.py' = '-63c7b98d'
    'gui_utils.py' = '438d5e02'
}

$recovered = 0
$skipped = 0
$errors = 0

foreach ($module in $modules.Keys) {
    $historyFolder = Join-Path $historyBase $modules[$module]
    $targetPath = Join-Path $targetDir $module
    
    Write-Host "Processing: $module" -ForegroundColor Cyan
    
    try {
        # Check if file already exists
        if (Test-Path $targetPath) {
            Write-Host "  File already exists, skipping: $module" -ForegroundColor Yellow
            $skipped++
            continue
        }
        
        # Find the most recent .py file in the history folder
        $sourceFile = Get-ChildItem -Path $historyFolder -Filter "*.py" -File | 
                      Sort-Object LastWriteTime -Descending | 
                      Select-Object -First 1
        
        if ($sourceFile) {
            Copy-Item -Path $sourceFile.FullName -Destination $targetPath -Force
            $fileSize = [math]::Round($sourceFile.Length / 1KB, 2)
            Write-Host "  Recovered: $module ($fileSize KB)" -ForegroundColor Green
            $recovered++
        } else {
            Write-Host "  No .py file found in history folder" -ForegroundColor Red
            $errors++
        }
    }
    catch {
        Write-Host "  Error: $($_.Exception.Message)" -ForegroundColor Red
        $errors++
    }
    
    Write-Host ""
}

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Recovery Complete!" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Recovered: $recovered files" -ForegroundColor Green
Write-Host "Skipped: $skipped files (already exist)" -ForegroundColor Yellow
Write-Host "Errors: $errors files" -ForegroundColor Red
Write-Host ""
Write-Host "You can now run: python youtube_automation_gui.py" -ForegroundColor Cyan
Write-Host ""
