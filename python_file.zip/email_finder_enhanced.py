"""
Enhanced Email and Contact Information Finder
Improved extraction patterns, structured output, and quality scoring
"""

import csv
import re
import time
import json
import threading
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Tuple, Optional, Set
from dataclasses import dataclass, asdict
from collections import defaultdict

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException


@dataclass
class ContactInfo:
    """Structured contact information for a channel"""
    channel_url: str
    emails: List[str]
    social_media: Dict[str, List[str]]
    usernames: List[str]
    phone_numbers: List[str]
    websites: List[str]
    other_contacts: List[str]
    source_locations: List[str]  # Where the info was found (about, video_desc, etc)
    timestamp: str
    quality_score: float = 0.0
    
    def to_dict(self) -> Dict:
        """Convert to dictionary for JSON export"""
        return asdict(self)
    
    def has_email(self) -> bool:
        """Check if any email addresses were found"""
        return len(self.emails) > 0
    
    def has_social(self) -> bool:
        """Check if any social media was found"""
        return any(len(links) > 0 for links in self.social_media.values())
    
    def has_contact(self) -> bool:
        """Check if any contact information was found"""
        return self.has_email() or self.has_social() or len(self.phone_numbers) > 0


class ContactQualityScorer:
    """Score contact information quality"""
    
    @staticmethod
    def calculate_score(contact: ContactInfo) -> float:
        """
        Calculate quality score (0-100) based on:
        - Email presence and type (business vs personal)
        - Number and variety of social media platforms
        - Additional contact methods (phone, website)
        - Verification indicators
        """
        score = 0.0
        
        # Email scoring (0-40 points)
        if contact.emails:
            score += 20  # Base points for having email
            
            # Business email bonus
            business_domains = ['business', 'contact', 'info', 'hello', 'support']
            for email in contact.emails:
                local_part = email.split('@')[0].lower()
                if any(keyword in local_part for keyword in business_domains):
                    score += 10
                    break
            
            # Multiple emails bonus
            if len(contact.emails) > 1:
                score += 5
            
            # Domain quality (avoid generic emails)
            generic_domains = ['gmail.com', 'yahoo.com', 'hotmail.com', 'outlook.com']
            has_custom_domain = any(
                email.split('@')[1].lower() not in generic_domains 
                for email in contact.emails
            )
            if has_custom_domain:
                score += 5
        
        # Social media scoring (0-30 points)
        if contact.social_media:
            platforms_found = sum(1 for links in contact.social_media.values() if links)
            score += min(platforms_found * 5, 20)  # Max 20 points for platforms
            
            # Professional platform bonus (LinkedIn)
            if contact.social_media.get('linkedin'):
                score += 10
        
        # Additional contacts (0-15 points)
        if contact.phone_numbers:
            score += 10
        
        if contact.websites:
            score += 5
        
        # Source diversity bonus (0-10 points)
        if len(set(contact.source_locations)) > 1:
            score += 10
        
        # Username bonus (0-5 points)
        if contact.usernames:
            score += 5
        
        return min(score, 100.0)


class EnhancedExtractor:
    """Enhanced extraction engine with comprehensive patterns"""
    
    # Extended email patterns
    EMAIL_PATTERNS = [
        # Standard formats
        r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
        
        # Obfuscated formats
        r'\b[A-Za-z0-9._%+-]+\s*[\[\(]at[\)\]]\s*[A-Za-z0-9.-]+\s*[\[\(]dot[\)\]]\s*[A-Za-z]{2,}\b',
        r'\b[A-Za-z0-9._%+-]+\s*@\s*[A-Za-z0-9.-]+\s*\.\s*[A-Z|a-z]{2,}\b',
        r'\b[A-Za-z0-9._%+-]+\s*\[at\]\s*[A-Za-z0-9.-]+\s*\[dot\]\s*[A-Za-z]{2,}\b',
        r'\b[A-Za-z0-9._%+-]+\s+at\s+[A-Za-z0-9.-]+\s+dot\s+[A-Za-z]{2,}\b',
        
        # Unicode variants
        r'\b[A-Za-z0-9._%+-]+[＠⒜][A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
        
        # With labels
        r'(?:mailto:|email:|e-mail:|contact:|business:)\s*([A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,})',
    ]
    
    # Phone number patterns (international formats)
    PHONE_PATTERNS = [
        r'\+\d{1,3}[-.\s]?\(?\d{1,4}\)?[-.\s]?\d{1,4}[-.\s]?\d{1,9}',
        r'\(\d{3}\)\s*\d{3}[-.\s]?\d{4}',
        r'\d{3}[-.\s]?\d{3}[-.\s]?\d{4}',
    ]
    
    # Comprehensive social media patterns
    SOCIAL_PATTERNS = {
        'facebook': [
            r'(?:https?://)?(?:www\.)?(?:facebook\.com|fb\.com)/([A-Za-z0-9._%+-]+)',
            r'(?:facebook|fb)\.com/(?:profile\.php\?id=\d+|pages?|groups?)/([A-Za-z0-9._%+-]+)',
            r'(?:facebook|fb)\s*[:@]\s*([A-Za-z0-9._%+-]+)',
        ],
        'instagram': [
            r'(?:https?://)?(?:www\.)?(?:instagram\.com|instagr\.am)/([A-Za-z0-9._%+-]+)',
            r'(?:instagram|ig|insta)\s*[:@]\s*([A-Za-z0-9._%+-]+)',
        ],
        'twitter': [
            r'(?:https?://)?(?:www\.)?(?:twitter\.com|x\.com)/([A-Za-z0-9._%+-]+)',
            r'(?:twitter|x)\s*[:@]\s*([A-Za-z0-9._%+-]+)',
        ],
        'tiktok': [
            r'(?:https?://)?(?:www\.)?(?:tiktok\.com|vm\.tiktok\.com|vt\.tiktok\.com)/(@?[A-Za-z0-9._%+-]+)',
            r'tiktok\s*[:@]\s*([A-Za-z0-9._%+-]+)',
        ],
        'linkedin': [
            r'(?:https?://)?(?:www\.)?(?:linkedin\.com|lnkd\.in)/(?:in|company)/([A-Za-z0-9._%+-]+)',
            r'linkedin\s*[:@]\s*([A-Za-z0-9._%+-]+)',
        ],
        'youtube': [
            r'youtube\.com/(@[A-Za-z0-9._%+-]+)',
            r'youtube\.com/(?:channel|c|user)/([A-Za-z0-9._%+-]+)',
        ],
        'twitch': [
            r'(?:https?://)?(?:www\.)?twitch\.tv/([A-Za-z0-9._%+-]+)',
            r'twitch\s*[:@]\s*([A-Za-z0-9._%+-]+)',
        ],
        'discord': [
            r'(?:https?://)?(?:discord\.gg|discord\.com/invite)/([A-Za-z0-9]+)',
            r'discord\s*[:@]\s*([A-Za-z0-9._%+-]+)',
        ],
        'telegram': [
            r'(?:https?://)?(?:t\.me|telegram\.me)/([A-Za-z0-9._%+-]+)',
            r'telegram\s*[:@]\s*([A-Za-z0-9._%+-]+)',
        ],
        'reddit': [
            r'(?:https?://)?(?:www\.)?reddit\.com/(?:u|user|r)/([A-Za-z0-9._%+-]+)',
            r'reddit\s*[:@]\s*([A-Za-z0-9._%+-]+)',
        ],
        'github': [
            r'(?:https?://)?(?:www\.)?github\.com/([A-Za-z0-9._%+-]+)',
            r'github\s*[:@]\s*([A-Za-z0-9._%+-]+)',
        ],
        'website': [
            r'(?:https?://)?(?:www\.)?([A-Za-z0-9][A-Za-z0-9.-]+\.[A-Za-z]{2,}(?:/[^\s\)\"\'<>]*)?)',
            r'(?:website|site|web):\s*((?:https?://)?[A-Za-z0-9][A-Za-z0-9.-]+\.[A-Za-z]{2,})',
        ],
    }
    
    @classmethod
    def extract_all(cls, text: str) -> Tuple[List[str], Dict[str, List[str]], List[str], List[str]]:
        """
        Extract all contact information from text
        Returns: (emails, social_media, usernames, phone_numbers)
        """
        if not text:
            return [], {}, [], []
        
        # Decode URL-encoded text
        try:
            import urllib.parse
            decoded = urllib.parse.unquote(text)
            text = text + " " + decoded
        except:
            pass
        
        text_lower = text.lower()
        
        # Extract emails
        emails = cls._extract_emails(text)
        
        # Extract social media
        social_media = cls._extract_social_media(text_lower)
        
        # Extract usernames (@mentions)
        usernames = cls._extract_usernames(text)
        
        # Extract phone numbers
        phone_numbers = cls._extract_phone_numbers(text)
        
        return emails, social_media, usernames, phone_numbers
    
    @classmethod
    def _extract_emails(cls, text: str) -> List[str]:
        """Extract and validate email addresses"""
        emails = set()
        
        for pattern in cls.EMAIL_PATTERNS:
            matches = re.findall(pattern, text, re.IGNORECASE | re.MULTILINE)
            for match in matches:
                # Handle tuple results
                if isinstance(match, tuple):
                    match = match[0]
                
                # Clean obfuscated formats
                clean = re.sub(r'\s+|\[at\]|\(at\)|＠|⒜|\[dot\]|\(dot\)', lambda m: '@' if 'at' in m.group().lower() else '.', match)
                clean = clean.replace(' dot ', '.').strip().lower()
                
                # Validate email
                if '@' in clean and '.' in clean.split('@')[1]:
                    # Filter out youtube/google domains
                    domain = clean.split('@')[1]
                    if domain not in ['youtube.com', 'google.com']:
                        emails.add(clean)
        
        return sorted(list(emails))
    
    @classmethod
    def _extract_social_media(cls, text: str) -> Dict[str, List[str]]:
        """Extract social media links"""
        social_media = defaultdict(list)
        
        for platform, patterns in cls.SOCIAL_PATTERNS.items():
            for pattern in patterns:
                matches = re.findall(pattern, text, re.IGNORECASE)
                for match in matches:
                    if not match or len(match.strip()) < 2:
                        continue
                    
                    # Normalize link
                    link = cls._normalize_social_link(platform, match.strip())
                    
                    # Filter out irrelevant matches
                    if cls._is_valid_social_link(platform, link):
                        if link not in social_media[platform]:
                            social_media[platform].append(link)
        
        return dict(social_media)
    
    @classmethod
    def _extract_usernames(cls, text: str) -> List[str]:
        """Extract @username mentions"""
        usernames = set()
        
        # Find @mentions
        mentions = re.findall(r'(?<![\w@])@([A-Za-z0-9_\.]+)', text)
        for username in mentions:
            if len(username) > 1:
                usernames.add(f"@{username}")
        
        return sorted(list(usernames))
    
    @classmethod
    def _extract_phone_numbers(cls, text: str) -> List[str]:
        """Extract phone numbers"""
        phones = set()
        
        for pattern in cls.PHONE_PATTERNS:
            matches = re.findall(pattern, text)
            for match in matches:
                # Clean and validate
                clean = re.sub(r'[^\d+]', '', match)
                if len(clean) >= 10:  # Minimum valid phone length
                    phones.add(match.strip())
        
        return sorted(list(phones))
    
    @classmethod
    def _normalize_social_link(cls, platform: str, link: str) -> str:
        """Normalize social media link to standard format"""
        link = link.strip().lower()
        
        # Remove tracking parameters
        if '?' in link:
            link = link.split('?')[0]
        
        # Add https if not present
        if not link.startswith('http'):
            base_urls = {
                'facebook': 'https://facebook.com/',
                'instagram': 'https://instagram.com/',
                'twitter': 'https://twitter.com/',
                'tiktok': 'https://tiktok.com/',
                'linkedin': 'https://linkedin.com/in/',
                'youtube': 'https://youtube.com/',
                'twitch': 'https://twitch.tv/',
                'discord': 'https://discord.gg/',
                'telegram': 'https://t.me/',
                'reddit': 'https://reddit.com/u/',
                'github': 'https://github.com/',
            }
            
            base = base_urls.get(platform, 'https://')
            if platform == 'tiktok' and not link.startswith('@'):
                link = f"@{link}"
            link = base + link.lstrip('/')
        
        return link
    
    @classmethod
    def _is_valid_social_link(cls, platform: str, link: str) -> bool:
        """Validate social media link"""
        # Filter out generic/invalid links
        invalid_indicators = ['youtube.com', 'google.com', 'example.com']
        
        if platform == 'website':
            # For websites, exclude social media domains
            social_domains = ['facebook', 'instagram', 'twitter', 'tiktok', 'youtube', 'linkedin']
            return not any(domain in link.lower() for domain in social_domains)
        
        return not any(invalid in link.lower() for invalid in invalid_indicators)


class EnhancedEmailFinder:
    """Enhanced email finder with structured output"""
    
    def __init__(self, num_windows: int = 3, output_dir: str = "./output"):
        self.num_windows = num_windows
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(exist_ok=True)
        self.extractor = EnhancedExtractor()
        self.scorer = ContactQualityScorer()
        self.csv_lock = threading.Lock()
        
        # Statistics
        self.stats = {
            'total_processed': 0,
            'with_email': 0,
            'social_only': 0,
            'signin_required': 0,
            'nothing_found': 0,
        }
    
    def run(self, input_csv: str, progress_callback=None, result_callback=None, error_callback=None):
        """Run the enhanced email finder"""
        # Read input channels
        channels = self._read_channels(input_csv)
        
        if not channels:
            print(f"❌ No valid channels found in {input_csv}")
            return
        
        print(f"📊 Processing {len(channels)} channels with {self.num_windows} parallel windows")
        
        # Initialize output files with enhanced headers
        self._initialize_output_files()
        
        # Split channels into chunks
        chunks = self._chunkify(channels, self.num_windows)
        
        # Process chunks in parallel threads
        threads = []
        for i, chunk in enumerate(chunks):
            if chunk:
                t = threading.Thread(
                    target=self._process_chunk,
                    args=(chunk, i+1, progress_callback, result_callback, error_callback)
                )
                t.start()
                threads.append(t)
        
        # Wait for completion
        for t in threads:
            t.join()
        
        # Generate summary reports
        self._generate_reports()
        
        print("\n" + "="*80)
        print("✅ Processing Complete!")
        print("="*80)
        print(f"📊 Statistics:")
        print(f"   Total Processed: {self.stats['total_processed']}")
        print(f"   ✅ With Email: {self.stats['with_email']}")
        print(f"   📱 Social Only: {self.stats['social_only']}")
        print(f"   🔒 Sign-in Required: {self.stats['signin_required']}")
        print(f"   ❌ Nothing Found: {self.stats['nothing_found']}")
        print(f"\n📁 Output files saved to: {self.output_dir}")
    
    def _read_channels(self, input_csv: str) -> List[str]:
        """Read channel URLs from CSV"""
        channels = []
        try:
            with open(input_csv, 'r', encoding='utf-8') as f:
                reader = csv.reader(f)
                next(reader, None)  # Skip header
                for row in reader:
                    if row and row[0].startswith('http'):
                        channels.append(row[0])
        except Exception as e:
            print(f"❌ Error reading {input_csv}: {e}")
        
        return channels
    
    def _chunkify(self, lst: List, n: int) -> List[List]:
        """Split list into n chunks"""
        return [lst[i::n] for i in range(n)]
    
    def _initialize_output_files(self):
        """Initialize output CSV files with enhanced headers"""
        headers = {
            'with_email.csv': [
                'Channel URL', 'Emails', 'Facebook', 'Instagram', 'Twitter', 
                'TikTok', 'LinkedIn', 'YouTube', 'Twitch', 'Discord', 'Telegram',
                'Reddit', 'GitHub', 'Websites', '@Usernames', 'Phone Numbers',
                'Sources', 'Quality Score', 'Timestamp'
            ],
            'social_only.csv': [
                'Channel URL', 'Facebook', 'Instagram', 'Twitter', 'TikTok',
                'LinkedIn', 'YouTube', 'Twitch', 'Discord', 'Telegram', 'Reddit',
                'GitHub', 'Websites', '@Usernames', 'Phone Numbers', 'Sources',
                'Quality Score', 'Timestamp'
            ],
            'signin_required.csv': [
                'Channel URL', 'Partial Info', 'Timestamp'
            ],
            'nothing_found.csv': [
                'Channel URL', 'Timestamp'
            ],
        }
        
        for filename, header in headers.items():
            filepath = self.output_dir / filename
            with open(filepath, 'w', encoding='utf-8', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(header)
    
    def _process_chunk(self, channels: List[str], thread_id: int, 
                      progress_callback=None, result_callback=None, error_callback=None):
        """Process a chunk of channels in a single browser"""
        driver = None
        
        try:
            driver = webdriver.Chrome()
            driver.maximize_window()
            
            for channel_url in channels:
                try:
                    print(f"[Thread {thread_id}] 🔍 Processing: {channel_url}")
                    
                    if progress_callback:
                        progress_callback(f"[Thread {thread_id}] Scanning: {channel_url}")
                    
                    # Extract contact information
                    contact_info = self._extract_channel_info(driver, channel_url)
                    
                    # Calculate quality score
                    contact_info.quality_score = self.scorer.calculate_score(contact_info)
                    
                    # Save results
                    self._save_contact(contact_info)
                    
                    # Update statistics
                    with self.csv_lock:
                        self.stats['total_processed'] += 1
                        if contact_info.has_email():
                            self.stats['with_email'] += 1
                        elif contact_info.has_social():
                            self.stats['social_only'] += 1
                    
                    # Callback for real-time updates
                    if result_callback:
                        result_type = 'email' if contact_info.has_email() else \
                                     'social' if contact_info.has_social() else 'none'
                        result_callback(result_type, channel_url, contact_info.to_dict())
                    
                    # Small delay between requests
                    time.sleep(2)
                    
                except Exception as e:
                    print(f"❌ Error processing {channel_url}: {e}")
                    if error_callback:
                        error_callback(e, {'channel': channel_url, 'thread': thread_id})
        
        except Exception as e:
            print(f"❌ Thread {thread_id} error: {e}")
            if error_callback:
                error_callback(e, {'thread': thread_id})
        
        finally:
            if driver:
                try:
                    driver.quit()
                except:
                    pass
    
    def _extract_channel_info(self, driver, channel_url: str) -> ContactInfo:
        """Extract all contact information from a channel"""
        all_emails = []
        all_social = defaultdict(list)
        all_usernames = []
        all_phones = []
        all_websites = []
        sources = []
        
        # 1. Check About section
        print("   📝 Checking About section...")
        about_text = self._get_about_section(driver, channel_url)
        if about_text:
            emails, social, usernames, phones = self.extractor.extract_all(about_text)
            all_emails.extend(emails)
            self._merge_social(all_social, social)
            all_usernames.extend(usernames)
            all_phones.extend(phones)
            if emails or social or phones:
                sources.append('about')
        
        # 2. Check video descriptions (if no email yet)
        if not all_emails:
            print("   🎥 Checking video descriptions...")
            video_text = self._get_video_description(driver, channel_url)
            if video_text:
                emails, social, usernames, phones = self.extractor.extract_all(video_text)
                all_emails.extend(emails)
                self._merge_social(all_social, social)
                all_usernames.extend(usernames)
                all_phones.extend(phones)
                if emails or social or phones:
                    sources.append('video_description')
        
        # Extract websites from social
        if 'website' in all_social:
            all_websites = all_social.pop('website')
        
        # Create ContactInfo object
        contact = ContactInfo(
            channel_url=channel_url,
            emails=list(set(all_emails)),
            social_media=dict(all_social),
            usernames=list(set(all_usernames)),
            phone_numbers=list(set(all_phones)),
            websites=list(set(all_websites)),
            other_contacts=[],
            source_locations=sources,
            timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        )
        
        return contact
    
    def _get_about_section(self, driver, channel_url: str) -> str:
        """Get About section text"""
        try:
            about_url = channel_url.rstrip('/') + '/about'
            driver.get(about_url)
            time.sleep(3)
            
            # Wait for page load
            WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.TAG_NAME, "body"))
            )
            
            # Extract text from multiple sources
            text_parts = []
            
            # Description
            try:
                desc = driver.find_element(By.XPATH, "//yt-formatted-string[@id='description']")
                text_parts.append(desc.text)
            except:
                pass
            
            # Links
            try:
                links = driver.find_elements(By.XPATH, "//div[@id='links']//a")
                for link in links:
                    text_parts.append(link.get_attribute('href') or '')
                    text_parts.append(link.text or '')
            except:
                pass
            
            # Details
            try:
                details = driver.find_elements(By.XPATH, "//div[@id='details']//yt-formatted-string")
                for detail in details:
                    text_parts.append(detail.text)
            except:
                pass
            
            return ' '.join(text_parts)
        
        except Exception as e:
            print(f"      ⚠️ Error getting about section: {e}")
            return ""
    
    def _get_video_description(self, driver, channel_url: str) -> str:
        """Get latest video description"""
        try:
            videos_url = channel_url.rstrip('/') + '/videos'
            driver.get(videos_url)
            time.sleep(3)
            
            # Find first video
            video_link = driver.find_element(By.XPATH, "//a[contains(@href, '/watch?v=')]")
            video_url = video_link.get_attribute('href')
            
            if not video_url:
                return ""
            
            # Navigate to video
            driver.get(video_url)
            time.sleep(3)
            
            # Try to expand description
            try:
                expand_btn = driver.find_element(By.XPATH, "//tp-yt-paper-button[@id='expand']")
                expand_btn.click()
                time.sleep(2)
            except:
                pass
            
            # Get description text
            try:
                desc = driver.find_element(By.XPATH, "//div[@id='description']//yt-formatted-string")
                return desc.text
            except:
                return ""
        
        except Exception as e:
            print(f"      ⚠️ Error getting video description: {e}")
            return ""
    
    def _merge_social(self, target: Dict, source: Dict):
        """Merge social media dictionaries"""
        for platform, links in source.items():
            if platform not in target:
                target[platform] = []
            for link in links:
                if link not in target[platform]:
                    target[platform].append(link)
    
    def _save_contact(self, contact: ContactInfo):
        """Save contact information to appropriate CSV file"""
        with self.csv_lock:
            if contact.has_email():
                self._save_to_csv('with_email.csv', contact, include_all=True)
            elif contact.has_social():
                self._save_to_csv('social_only.csv', contact, include_all=False)
            else:
                self._save_to_csv('nothing_found.csv', contact, minimal=True)
    
    def _save_to_csv(self, filename: str, contact: ContactInfo, include_all: bool = True, minimal: bool = False):
        """Save contact to CSV file"""
        filepath = self.output_dir / filename
        
        with open(filepath, 'a', encoding='utf-8', newline='') as f:
            writer = csv.writer(f)
            
            if minimal:
                writer.writerow([contact.channel_url, contact.timestamp])
            elif include_all:
                writer.writerow([
                    contact.channel_url,
                    '; '.join(contact.emails),
                    '; '.join(contact.social_media.get('facebook', [])),
                    '; '.join(contact.social_media.get('instagram', [])),
                    '; '.join(contact.social_media.get('twitter', [])),
                    '; '.join(contact.social_media.get('tiktok', [])),
                    '; '.join(contact.social_media.get('linkedin', [])),
                    '; '.join(contact.social_media.get('youtube', [])),
                    '; '.join(contact.social_media.get('twitch', [])),
                    '; '.join(contact.social_media.get('discord', [])),
                    '; '.join(contact.social_media.get('telegram', [])),
                    '; '.join(contact.social_media.get('reddit', [])),
                    '; '.join(contact.social_media.get('github', [])),
                    '; '.join(contact.websites),
                    '; '.join(contact.usernames),
                    '; '.join(contact.phone_numbers),
                    '; '.join(contact.source_locations),
                    f"{contact.quality_score:.1f}",
                    contact.timestamp
                ])
            else:
                writer.writerow([
                    contact.channel_url,
                    '; '.join(contact.social_media.get('facebook', [])),
                    '; '.join(contact.social_media.get('instagram', [])),
                    '; '.join(contact.social_media.get('twitter', [])),
                    '; '.join(contact.social_media.get('tiktok', [])),
                    '; '.join(contact.social_media.get('linkedin', [])),
                    '; '.join(contact.social_media.get('youtube', [])),
                    '; '.join(contact.social_media.get('twitch', [])),
                    '; '.join(contact.social_media.get('discord', [])),
                    '; '.join(contact.social_media.get('telegram', [])),
                    '; '.join(contact.social_media.get('reddit', [])),
                    '; '.join(contact.social_media.get('github', [])),
                    '; '.join(contact.websites),
                    '; '.join(contact.usernames),
                    '; '.join(contact.phone_numbers),
                    '; '.join(contact.source_locations),
                    f"{contact.quality_score:.1f}",
                    contact.timestamp
                ])
    
    def _generate_reports(self):
        """Generate summary reports"""
        # JSON export with all contact details
        json_file = self.output_dir / 'contact_summary.json'
        
        summary = {
            'generated_at': datetime.now().isoformat(),
            'statistics': self.stats,
            'channels': []
        }
        
        # Read all results and convert to JSON
        for filename in ['with_email.csv', 'social_only.csv']:
            filepath = self.output_dir / filename
            if filepath.exists():
                with open(filepath, 'r', encoding='utf-8') as f:
                    reader = csv.DictReader(f)
                    for row in reader:
                        summary['channels'].append(row)
        
        with open(json_file, 'w', encoding='utf-8') as f:
            json.dump(summary, f, indent=2, ensure_ascii=False)
        
        print(f"\n📊 Summary report saved to: {json_file}")
        
        # Statistics report
        stats_file = self.output_dir / 'statistics.txt'
        with open(stats_file, 'w', encoding='utf-8') as f:
            f.write("="*60 + "\n")
            f.write("YouTube Contact Discovery - Statistics Report\n")
            f.write("="*60 + "\n\n")
            f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
            f.write(f"Total Channels Processed: {self.stats['total_processed']}\n")
            f.write(f"  ✅ With Email: {self.stats['with_email']} ({self.stats['with_email']/max(self.stats['total_processed'],1)*100:.1f}%)\n")
            f.write(f"  📱 Social Only: {self.stats['social_only']} ({self.stats['social_only']/max(self.stats['total_processed'],1)*100:.1f}%)\n")
            f.write(f"  🔒 Sign-in Required: {self.stats['signin_required']} ({self.stats['signin_required']/max(self.stats['total_processed'],1)*100:.1f}%)\n")
            f.write(f"  ❌ Nothing Found: {self.stats['nothing_found']} ({self.stats['nothing_found']/max(self.stats['total_processed'],1)*100:.1f}%)\n")
        
        print(f"📊 Statistics saved to: {stats_file}")


# Main execution
if __name__ == "__main__":
    print("="*80)
    print("🎯 Enhanced YouTube Email & Contact Finder")
    print("="*80)
    
    input_csv = input("\nEnter CSV file name (default: save.csv): ").strip() or "save.csv"
    
    try:
        num_windows = int(input("Number of parallel browser windows (default: 3): ").strip() or "3")
        num_windows = max(1, min(10, num_windows))
    except:
        num_windows = 3
    
    output_dir = input("Output directory (default: ./output): ").strip() or "./output"
    
    print(f"\n🚀 Starting enhanced email finder...")
    print(f"   Input: {input_csv}")
    print(f"   Windows: {num_windows}")
    print(f"   Output: {output_dir}")
    print()
    
    finder = EnhancedEmailFinder(num_windows=num_windows, output_dir=output_dir)
    finder.run(input_csv)
