"""
Quick test to verify bundled extension is accessible in packaged EXE
Run this INSIDE the distribution package folder
"""

import os
import sys

print("=" * 70)
print("TESTING BUNDLED EXTENSION IN PACKAGED EXE")
print("=" * 70)

# Check if running from PyInstaller bundle
if hasattr(sys, '_MEIPASS'):
    print(f"✅ Running from PyInstaller bundle")
    print(f"   sys._MEIPASS: {sys._MEIPASS}")
    
    # Check for bundled_extensions in _MEIPASS
    bundled_path = os.path.join(sys._MEIPASS, 'bundled_extensions', 'rektcaptcha')
    if os.path.exists(bundled_path):
        print(f"✅ Bundled extension found in _MEIPASS")
        print(f"   Path: {bundled_path}")
        
        # Check manifest
        manifest = os.path.join(bundled_path, 'manifest.json')
        if os.path.exists(manifest):
            print(f"✅ manifest.json exists")
            import json
            with open(manifest, 'r') as f:
                data = json.load(f)
                print(f"   Extension: {data.get('name', 'Unknown')}")
                print(f"   Version: {data.get('version', 'Unknown')}")
        else:
            print(f"❌ manifest.json not found")
    else:
        print(f"❌ Bundled extension NOT found in _MEIPASS")
        print(f"   Expected: {bundled_path}")
else:
    print(f"⚠️ Not running from PyInstaller bundle (running as script)")
    print(f"   This test is meant for the packaged EXE")
    
    # Check local bundled_extensions
    bundled_path = os.path.join(os.getcwd(), 'bundled_extensions', 'rektcaptcha')
    if os.path.exists(bundled_path):
        print(f"✅ Local bundled extension found: {bundled_path}")
    else:
        print(f"❌ Local bundled extension not found")

print("\n" + "=" * 70)

# Test chrome_utils
try:
    import chrome_utils
    print("✅ chrome_utils imported successfully")
    
    extensions = chrome_utils.get_extensions_list()
    if extensions:
        print(f"✅ Found {len(extensions)} extension(s):")
        for ext in extensions:
            print(f"   - {ext}")
    else:
        print("❌ No extensions found by chrome_utils")
except Exception as e:
    print(f"❌ Error with chrome_utils: {e}")

print("=" * 70)
