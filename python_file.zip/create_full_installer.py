"""
Create Full Installer for YTReach
Builds an Inno Setup installer with all dependencies
"""

import os
import sys
import subprocess
import shutil
from pathlib import Path

def find_inno_setup():
    """Find Inno Setup installation"""
    possible_paths = [
        r"C:\Program Files (x86)\Inno Setup 6\ISCC.exe",
        r"C:\Program Files\Inno Setup 6\ISCC.exe",
        r"C:\Program Files (x86)\Inno Setup 5\ISCC.exe",
        r"C:\Program Files\Inno Setup 5\ISCC.exe",
    ]
    
    for path in possible_paths:
        if os.path.exists(path):
            return path
    
    return None

def create_inno_script():
    """Create Inno Setup script for the installer"""
    
    script_content = r"""
; YTReach Installer Script
; Created with Inno Setup

#define MyAppName "YTReach"
#define MyAppVersion "1.0.0"
#define MyAppPublisher "YTReach"
#define MyAppURL "https://github.com/yourusername/ytreach"
#define MyAppExeName "YTReach.exe"

[Setup]
AppId={{A1B2C3D4-E5F6-7890-ABCD-EF1234567890}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
AppPublisherURL={#MyAppURL}
AppSupportURL={#MyAppURL}
AppUpdatesURL={#MyAppURL}
DefaultDirName={autopf}\{#MyAppName}
DefaultGroupName={#MyAppName}
AllowNoIcons=yes
LicenseFile=LICENSE.txt
OutputDir=.
OutputBaseFilename=YTReach_Setup
SetupIconFile=icon.ico
Compression=lzma2/max
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=admin
ArchitecturesAllowed=x64
ArchitecturesInstallIn64BitMode=x64

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: unchecked
Name: "quicklaunchicon"; Description: "{cm:CreateQuickLaunchIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: unchecked; OnlyBelowVersion: 6.1; Check: not IsAdminInstallMode

[Files]
Source: "dist\YTReach.exe"; DestDir: "{app}"; Flags: ignoreversion
Source: "gmail_accounts.csv.example"; DestDir: "{app}"; Flags: ignoreversion
Source: "README.txt"; DestDir: "{app}"; Flags: ignoreversion isreadme
Source: "LICENSE.txt"; DestDir: "{app}"; Flags: ignoreversion
Source: "requirements.txt"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"
Name: "{group}\{cm:UninstallProgram,{#MyAppName}}"; Filename: "{uninstallexe}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "{cm:LaunchProgram,{#StringChange(MyAppName, '&', '&&')}}"; Flags: nowait postinstall skipifsilent

[Code]
function InitializeSetup(): Boolean;
var
  ResultCode: Integer;
begin
  Result := True;
  
  // Check if Chrome is installed
  if not FileExists(ExpandConstant('{autopf}\Google\Chrome\Application\chrome.exe')) and
     not FileExists(ExpandConstant('{autopf32}\Google\Chrome\Application\chrome.exe')) then
  begin
    if MsgBox('Google Chrome is not installed. YTReach requires Chrome to function.' + #13#10 + #13#10 +
              'Would you like to continue with the installation anyway?', mbConfirmation, MB_YESNO) = IDNO then
      Result := False;
  end;
end;

procedure CurStepChanged(CurStep: TSetupStep);
var
  ResultCode: Integer;
begin
  if CurStep = ssPostInstall then
  begin
    // Show message about ChromeDriver
    MsgBox('Installation complete!' + #13#10 + #13#10 +
           'IMPORTANT: You need to install ChromeDriver separately.' + #13#10 +
           'Visit: https://chromedriver.chromium.org/' + #13#10 + #13#10 +
           'Match the ChromeDriver version to your Chrome browser version.', mbInformation, MB_OK);
  end;
end;
"""
    
    with open('ytreach_installer.iss', 'w', encoding='utf-8') as f:
        f.write(script_content)
    
    print("✅ Created Inno Setup script: ytreach_installer.iss")

def create_readme():
    """Create README.txt for distribution"""
    
    readme_content = """
================================================================================
YTReach - Professional YouTube Contact Discovery Tool
================================================================================

QUICK START GUIDE
-----------------

1. SYSTEM REQUIREMENTS
   - Windows 10/11 (64-bit)
   - 4GB RAM minimum (8GB recommended)
   - Internet connection
   - Google Chrome browser
   - ChromeDriver (must match Chrome version)

2. FIRST-TIME SETUP

   Step 1: Install Google Chrome
   ------------------------------
   If not already installed:
   Download from: https://www.google.com/chrome/

   Step 2: Install ChromeDriver
   -----------------------------
   VERY IMPORTANT - ChromeDriver version must match your Chrome version!
   
   a) Check your Chrome version:
      - Open Chrome
      - Go to: chrome://version/
      - Note the version number (e.g., 119.0.6045.105)
   
   b) Download matching ChromeDriver:
      - Visit: https://chromedriver.chromium.org/downloads
      - Download the version matching your Chrome
      - Extract chromedriver.exe
   
   c) Install ChromeDriver (choose ONE method):
      
      Method 1 (Recommended): Add to System PATH
      - Move chromedriver.exe to: C:\Windows\System32\
      
      Method 2: Custom Location
      - Create folder: C:\ChromeDriver\
      - Move chromedriver.exe there
      - Add C:\ChromeDriver\ to Windows PATH:
        * Search "Environment Variables" in Windows
        * Edit "Path" variable
        * Add new entry: C:\ChromeDriver\
   
   Step 3: Configure Gmail Accounts (Optional)
   --------------------------------------------
   For authenticated email discovery:
   
   - Rename: gmail_accounts.csv.example → gmail_accounts.csv
   - Edit the file with Notepad
   - Add your Gmail credentials:
     email,password
     your.email@gmail.com,yourpassword

3. LAUNCHING THE APPLICATION

   - Double-click: YTReach.exe
   - Or run from Start Menu: YTReach
   - First launch may take 10-15 seconds
   - You may need to grant admin permissions

4. FEATURES OVERVIEW

   A. VIDEO SCRAPING
      - Search YouTube by topics
      - Apply filters (views, duration, quality)
      - Extract channel links
      - Output: save.csv

   B. SUBSCRIBER ANALYSIS
      - Categorize channels by subscriber count
      - Output files:
        * below_1k.csv (under 1,000 subscribers)
        * 1k_10k.csv (1,000-10,000 subscribers)
        * above_10k.csv (over 10,000 subscribers)

   C. EMAIL FINDER
      - Extract emails from descriptions
      - Scan About sections
      - Find social media links
      - Output files:
        * founded_email.csv (emails found)
        * not_email_but_social.csv (social only)
        * signin_to_see_email.csv (needs auth)
        * non_founded_email.csv (nothing found)

   D. AUTHENTICATED EMAIL DISCOVERY
      - Login with Gmail to access hidden contacts
      - Handle protected channel information
      - Output: discovered_emails_authenticated.csv

5. TROUBLESHOOTING

   Problem: "ChromeDriver not found"
   Solution: Install ChromeDriver and add to PATH (see Step 2)

   Problem: "Chrome version mismatch"
   Solution: Download ChromeDriver version matching your Chrome

   Problem: Application won't start
   Solutions:
   - Right-click YTReach.exe → Properties → Unblock
   - Run as Administrator
   - Check Windows Defender isn't blocking it

   Problem: Browser automation detected
   Solutions:
   - Normal behavior for some videos
   - Use different Gmail accounts
   - Add delays between requests

   Problem: No results found
   Solutions:
   - Check internet connection
   - Verify topics are spelled correctly
   - Try broader search terms
   - Increase views range

6. TIPS FOR BEST RESULTS

   - Start with 1-2 Chrome windows for testing
   - Use specific, targeted search topics
   - Recommended views range: 0-50,000
   - Check output CSV files regularly
   - Back up your data periodically

7. OUTPUT FILES EXPLAINED

   save.csv
   - Raw channel links from scraping
   - Starting point for further analysis

   below_1k.csv, 1k_10k.csv, above_10k.csv
   - Channels categorized by subscriber count
   - Useful for targeting specific channel sizes

   founded_email.csv
   - Channels with successfully extracted emails
   - Ready for outreach campaigns

   not_email_but_social.csv
   - Channels with social media links only
   - Alternative contact methods

   signin_to_see_email.csv
   - Channels requiring authentication to view email
   - Use authenticated discovery feature

   non_founded_email.csv
   - Channels with no contact info found
   - May need manual verification

8. LEGAL & ETHICAL USE

   ⚠️ IMPORTANT DISCLAIMERS:
   
   - This tool is for educational and research purposes
   - Respect YouTube's Terms of Service
   - Don't spam or harass content creators
   - Use for legitimate business outreach only
   - Follow data protection laws (GDPR, CCPA, etc.)
   - Obtain consent before sending marketing emails
   - Respect opt-out requests immediately

9. SUPPORT & UPDATES

   For issues or questions:
   - Check this README first
   - Review error messages in the application
   - Check output CSV files for clues
   - Visit: https://github.com/yourusername/ytreach

10. ADVANCED SETTINGS

    Chrome Windows
    - Setting: Number of parallel browser windows
    - Recommendation: Start with 3, increase gradually
    - Too many windows = system slowdown

    Views Range
    - Default: 0-10,000
    - Recommendation: 0-50,000 for more results
    - Higher range = more channels but longer processing

    Parallel Processing
    - Email Finder: 3-5 windows recommended
    - Subscriber Analysis: 3-10 windows
    - Monitor your system resources

================================================================================
Built with Python, Selenium, and Tkinter
Version 1.0.0
================================================================================
"""
    
    with open('README.txt', 'w', encoding='utf-8') as f:
        f.write(readme_content)
    
    print("✅ Created README.txt")

def create_license():
    """Create LICENSE.txt if it doesn't exist"""
    if not os.path.exists('LICENSE.txt'):
        license_content = """MIT License

Copyright (c) 2025 YTReach

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""
        with open('LICENSE.txt', 'w', encoding='utf-8') as f:
            f.write(license_content)
        print("✅ Created LICENSE.txt")

def build_installer():
    """Build the installer using Inno Setup"""
    
    print("\n" + "=" * 70)
    print("CREATING YTREACH INSTALLER")
    print("=" * 70)
    print()
    
    # Check if EXE exists
    exe_path = os.path.join('dist', 'YTReach.exe')
    if not os.path.exists(exe_path):
        print("❌ Error: YTReach.exe not found in dist/ folder")
        print("   Please run build_exe.py first to create the executable")
        return False
    
    # Create necessary files
    create_readme()
    create_license()
    
    # Find Inno Setup
    inno_path = find_inno_setup()
    
    if not inno_path:
        print("⚠️  Inno Setup not found!")
        print("\nTo create the installer:")
        print("1. Download Inno Setup from: https://jrsoftware.org/isdl.php")
        print("2. Install Inno Setup")
        print("3. Run this script again")
        print("\nAlternatively, you can:")
        print("- Distribute the YTReach_Package folder as a ZIP file")
        print("- Users can extract and run YTReach.exe directly")
        return False
    
    print(f"✅ Found Inno Setup: {inno_path}")
    
    # Create Inno Setup script
    create_inno_script()
    
    # Build installer
    print("\n🔨 Building installer...")
    print("   This may take 1-2 minutes...")
    
    try:
        result = subprocess.run(
            [inno_path, 'ytreach_installer.iss'],
            capture_output=True,
            text=True,
            check=True
        )
        
        print("\n✅ Installer created successfully!")
        
        if os.path.exists('YTReach_Setup.exe'):
            size_mb = os.path.getsize('YTReach_Setup.exe') / (1024 * 1024)
            print("\n" + "=" * 70)
            print("🎉 INSTALLER READY!")
            print("=" * 70)
            print(f"\n📦 File: YTReach_Setup.exe")
            print(f"📊 Size: {size_mb:.1f} MB")
            print("\n📋 DISTRIBUTION:")
            print("   1. Share YTReach_Setup.exe with users")
            print("   2. Users run the installer")
            print("   3. Installer guides them through setup")
            print("   4. Creates desktop shortcut automatically")
            print("\n⚠️  USERS STILL NEED:")
            print("   - Chrome browser installed")
            print("   - ChromeDriver installed (matching Chrome version)")
            print("   - Internet connection")
            print()
            return True
        else:
            print("❌ Installer file not found")
            return False
            
    except subprocess.CalledProcessError as e:
        print(f"❌ Installer creation failed:")
        print(e.stderr)
        return False
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        return False

def main():
    """Main function"""
    success = build_installer()
    
    if success:
        print("\n" + "=" * 70)
        print("✅ ALL DONE!")
        print("=" * 70)
        print("\nYou now have:")
        print("   ✅ Standalone EXE: dist/YTReach.exe")
        print("   ✅ Distribution Package: YTReach_Package/")
        print("   ✅ Professional Installer: YTReach_Setup.exe")
        print("\nReady to share with users! 🚀")
        print()
    else:
        print("\n⚠️  Installer creation skipped")
        print("\nYou can still distribute:")
        print("   📦 YTReach_Package/ folder (as ZIP)")
        print("   📄 Users extract and run YTReach.exe")
        print()

if __name__ == "__main__":
    main()
