from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
import os
import time
import json

def main():
    profile_dir = os.path.join(os.getcwd(), 'chrome_profile')
    extension_id = 'bbdhfoclddncoaomddgkaaphcnddbpdh'
    extension_url = f'https://chromewebstore.google.com/detail/rektcaptcha-recaptcha-sol/{extension_id}'
    
    print("\n" + "="*70)
    print("ONE-TIME EXTENSION SETUP")
    print("="*70)
    
    # Set up Chrome options
    chrome_options = Options()
    chrome_options.add_argument(f'--user-data-dir={profile_dir}')
    chrome_options.add_argument('--no-sandbox')
    chrome_options.add_argument('--start-maximized')
    chrome_options.add_experimental_option('excludeSwitches', ['enable-automation'])
    chrome_options.add_experimental_option('useAutomationExtension', False)
    
    driver = None
    try:
        print("\nOpening Chrome Web Store...")
        driver = webdriver.Chrome(options=chrome_options)
        driver.get(extension_url)
        
        print("\nPlease follow these steps EXACTLY:")
        print("1. In the Chrome Web Store page that opens:")
        print("   - Click 'Add to Chrome'")
        print("   - When prompted, click 'Add extension'")
        print("2. Wait for the extension to finish installing")
        print("3. DO NOT CLOSE CHROME!")
        print("4. Return here and press Enter")
        
        input("\nPress Enter after the extension is installed (but keep Chrome open)...")
        
        # Save extension info
        marker = {
            'extension_id': extension_id,
            'extension_url': extension_url,
            'installed': True
        }
        with open(os.path.join(profile_dir, 'required_extension.json'), 'w', encoding='utf-8') as f:
            json.dump(marker, f)
        
        print("\nVerifying installation...")
        driver.get('chrome://extensions')
        time.sleep(3)
        
        # Enable developer mode
        driver.execute_script("""
            const devMode = document.querySelector('extensions-manager').shadowRoot
                .querySelector('extensions-toolbar').shadowRoot
                .querySelector('#devMode');
            if (devMode && !devMode.checked) {
                devMode.click();
            }
        """)
        time.sleep(1)
        
        ext_root = driver.find_element(By.TAG_NAME, 'extensions-manager')
        if ext_root and ext_root.find_elements(By.CSS_SELECTOR, f'extensions-item[id*="{extension_id}"]'):
            print("✅ Extension verified in chrome://extensions")
            
            print("\nTesting extension functionality...")
            driver.get('https://www.youtube.com')
            time.sleep(5)
            
            try:
                has_scripts = bool(driver.find_elements(By.CSS_SELECTOR, f'script[src*="{extension_id}"]'))
                has_elements = bool(driver.find_elements(By.CSS_SELECTOR, '[class*="recaptcha"],[class*="captcha"]'))
                if has_scripts or has_elements:
                    print("✅ Extension appears to be working!")
                else:
                    print("\n⚠️ Extension might need configuration:")
                    print("1. Click the extension icon in Chrome toolbar")
                    print("2. Configure any required settings")
                    input("\nPress Enter after configuring (if needed)...")
            except:
                print("⚠️ Could not verify extension scripts, but installation was successful")
            
            print("\n✅ Setup completed successfully!")
            print("You can now close Chrome and run discover_signin_emails.py")
            return True
        else:
            print("\n❌ Extension not found in Chrome. Please try again.")
            return False
            
    except Exception as e:
        print(f"\n❌ Error during setup: {e}")
        return False
        
    finally:
        try:
            if driver:
                driver.quit()
        except:
            pass

if __name__ == "__main__":
    # Kill any existing Chrome processes
    try:
        import subprocess
        subprocess.run(['taskkill', '/F', '/IM', 'chrome.exe'], capture_output=True)
        time.sleep(2)
    except:
        pass
    
    success = False
    while not success:
        success = main()
        if not success:
            choice = input("\nWould you like to try again? (y/n): ").lower().strip()
            if choice != 'y':
                break
            print("\nRetrying setup...")
            time.sleep(2)