"""
Pre-Build Verification - Check if everything is ready for EXE build
Run this before building to ensure the extension is bundled
"""

import os
import json
from pathlib import Path

print("=" * 70)
print("  PRE-BUILD VERIFICATION FOR YOUTUBE AUTOMATION SUITE")
print("=" * 70)
print()

all_checks_passed = True

# Check 1: Main GUI file
print("✓ Checking main GUI file...")
if os.path.exists('youtube_automation_gui.py'):
    size = os.path.getsize('youtube_automation_gui.py') / 1024
    print(f"  ✅ youtube_automation_gui.py found ({size:.1f} KB)")
else:
    print("  ❌ youtube_automation_gui.py NOT FOUND")
    all_checks_passed = False

# Check 2: Required modules
print("\n✓ Checking required modules...")
required_modules = [
    'auto.py',
    'chrome_utils.py',
    'multi_thread.py',
    'discover_signin_emails.py',
    'extension_manager.py',
    'email_finder.py',
    'database_manager.py',
]

missing_modules = []
for module in required_modules:
    if os.path.exists(module):
        print(f"  ✅ {module}")
    else:
        print(f"  ❌ {module} NOT FOUND")
        missing_modules.append(module)
        all_checks_passed = False

# Check 3: Bundled extension (CRITICAL for CAPTCHA solving)
print("\n✓ Checking bundled extension (CAPTCHA solver)...")
bundled_ext = Path("bundled_extensions/rektcaptcha")
if bundled_ext.exists():
    manifest = bundled_ext / "manifest.json"
    if manifest.exists():
        try:
            with open(manifest, 'r', encoding='utf-8') as f:
                data = json.load(f)
            print(f"  ✅ Extension found: {data.get('name', 'Unknown')}")
            print(f"  ✅ Version: {data.get('version', 'Unknown')}")
            
            # Count files
            file_count = sum(1 for _ in bundled_ext.rglob('*') if _.is_file())
            total_size = sum(f.stat().st_size for f in bundled_ext.rglob('*') if f.is_file())
            print(f"  ✅ Files: {file_count}")
            print(f"  ✅ Size: {total_size / 1024 / 1024:.2f} MB")
            print(f"  ✅ Location: {bundled_ext}")
            print("\n  🎉 CAPTCHA solver will be bundled in EXE!")
        except Exception as e:
            print(f"  ❌ Extension found but manifest is corrupted: {e}")
            print(f"  ⚠️  Run: python setup_rektcaptcha.py")
            all_checks_passed = False
    else:
        print("  ❌ Extension folder exists but manifest.json missing")
        print(f"  ⚠️  Run: python setup_rektcaptcha.py")
        all_checks_passed = False
else:
    print("  ❌ bundled_extensions/rektcaptcha/ NOT FOUND")
    print(f"  ⚠️  CAPTCHA solving will NOT work in the EXE!")
    print(f"  ⚠️  Run: python setup_rektcaptcha.py to install extension")
    all_checks_passed = False

# Check 4: Configuration examples
print("\n✓ Checking configuration files...")
config_files = {
    'gmail_accounts.csv.example': 'Gmail account template',
    'requirements.txt': 'Python dependencies',
}

for file, desc in config_files.items():
    if os.path.exists(file):
        print(f"  ✅ {file} - {desc}")
    else:
        print(f"  ⚠️  {file} not found - {desc}")

# Check 5: PyInstaller
print("\n✓ Checking PyInstaller...")
try:
    import PyInstaller
    print(f"  ✅ PyInstaller installed")
except ImportError:
    print(f"  ⚠️  PyInstaller not installed (will be installed during build)")

# Final verdict
print("\n" + "=" * 70)
if all_checks_passed:
    print("✅ ALL CHECKS PASSED - READY TO BUILD!")
    print("=" * 70)
    print("\n🚀 Next steps:")
    print("   1. Run: python build_exe.py")
    print("   2. Wait 5-10 minutes for build to complete")
    print("   3. Find EXE in: YouTube_Automation_Suite_Package/")
    print("\n📦 The EXE will include:")
    print("   ✓ All Python modules")
    print("   ✓ Pre-configured CAPTCHA solver extension")
    print("   ✓ Zero-setup for end users")
    print("   ✓ Automatic reCAPTCHA solving")
else:
    print("❌ SOME CHECKS FAILED")
    print("=" * 70)
    print("\n⚠️  Issues found:")
    if missing_modules:
        print(f"   - Missing modules: {', '.join(missing_modules)}")
    if not bundled_ext.exists():
        print(f"   - Extension not installed")
        print(f"     Run: python setup_rektcaptcha.py")
    print("\n🔧 Fix the issues above before building")

print()
