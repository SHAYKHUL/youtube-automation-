"""
Auto-load Chrome Extension Setup for Standalone EXE
Creates bundled_extensions folder that will be automatically loaded
"""

import os
import sys
import shutil
import urllib.request
import zipfile
import tempfile
from pathlib import Path

def create_bundled_extensions_folder():
    """Create bundled_extensions folder structure"""
    
    print("\n" + "=" * 70)
    print("CHROME EXTENSION AUTO-LOAD SETUP")
    print("=" * 70)
    print()
    
    # Create bundled_extensions folder
    ext_folder = Path("bundled_extensions")
    if ext_folder.exists():
        print("⚠️  bundled_extensions folder already exists")
        response = input("Delete and recreate? (y/n): ")
        if response.lower() != 'y':
            return False
        shutil.rmtree(ext_folder)
    
    ext_folder.mkdir(parents=True, exist_ok=True)
    print(f"✅ Created: {ext_folder}/")
    
    return ext_folder

def download_extension_from_webstore(extension_id, output_folder):
    """Download extension CRX from Chrome Web Store"""
    
    print(f"\n📥 Downloading extension: {extension_id}")
    
    try:
        # Chrome Web Store CRX download URL
        # Note: This may require Chrome browser or specific headers
        crx_url = f"https://clients2.google.com/service/update2/crx?response=redirect&prodversion=95.0.4638.69&acceptformat=crx2,crx3&x=id%3D{extension_id}%26uc"
        
        crx_file = output_folder / f"{extension_id}.crx"
        
        print(f"   URL: {crx_url}")
        print(f"   Saving to: {crx_file}")
        
        # Add user agent to mimic Chrome browser
        req = urllib.request.Request(
            crx_url,
            headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36'}
        )
        
        with urllib.request.urlopen(req, timeout=30) as response:
            with open(crx_file, 'wb') as out_file:
                shutil.copyfileobj(response, out_file)
        
        if crx_file.exists() and crx_file.stat().st_size > 1000:
            print(f"✅ Downloaded: {crx_file.name} ({crx_file.stat().st_size} bytes)")
            return crx_file
        else:
            print("❌ Download failed or file too small")
            return None
            
    except Exception as e:
        print(f"❌ Download error: {e}")
        return None

def extract_crx_to_unpacked(crx_path, output_folder):
    """Extract CRX file to unpacked extension folder"""
    
    print(f"\n📦 Extracting extension...")
    
    try:
        # CRX is essentially a ZIP with a header
        # Try to extract it as ZIP
        unpacked_folder = output_folder / crx_path.stem
        unpacked_folder.mkdir(parents=True, exist_ok=True)
        
        with zipfile.ZipFile(crx_path, 'r') as zip_ref:
            zip_ref.extractall(unpacked_folder)
        
        # Check if manifest.json exists
        manifest = unpacked_folder / "manifest.json"
        if manifest.exists():
            print(f"✅ Extracted to: {unpacked_folder}/")
            print(f"   manifest.json found")
            return unpacked_folder
        else:
            print("❌ Invalid extension - no manifest.json")
            return None
            
    except Exception as e:
        print(f"⚠️  CRX extraction failed: {e}")
        print("   Extension will be loaded as .crx file instead")
        return crx_path  # Return CRX path if extraction fails

def setup_rektcaptcha_extension():
    """Setup RektCaptcha extension for CAPTCHA solving"""
    
    print("\n🔧 Setting up RektCaptcha Extension")
    print("="*70)
    
    extension_id = "bbdhfoclddncoaomddgkaaphcnddbpdh"
    extension_name = "RektCaptcha"
    
    ext_folder = create_bundled_extensions_folder()
    if not ext_folder:
        return False
    
    print(f"\n📋 Extension Info:")
    print(f"   Name: {extension_name}")
    print(f"   ID: {extension_id}")
    print(f"   Store URL: https://chromewebstore.google.com/detail/{extension_id}")
    
    # Method 1: Try automatic download
    print("\n🔄 Attempting automatic download...")
    crx_file = download_extension_from_webstore(extension_id, ext_folder)
    
    if crx_file:
        # Try to extract for better compatibility
        unpacked = extract_crx_to_unpacked(crx_file, ext_folder)
        if unpacked and unpacked != crx_file:
            # Successfully extracted - can remove CRX
            try:
                crx_file.unlink()
                print("   Removed CRX file (using unpacked version)")
            except:
                pass
        
        print("\n✅ Extension setup complete!")
        print(f"\n📁 Extension folder: {ext_folder.absolute()}")
        return True
    
    # Method 2: Manual installation instructions
    print("\n⚠️  Automatic download not available")
    print("\n📋 MANUAL SETUP INSTRUCTIONS:")
    print("="*70)
    print("\nOption 1: Download CRX file manually")
    print("---------------------------------------")
    print("1. Visit: https://chrome-extension-downloader.com/")
    print(f"2. Enter extension ID: {extension_id}")
    print("3. Download the .crx file")
    print(f"4. Save to: {ext_folder.absolute()}/")
    print(f"5. Rename to: {extension_id}.crx")
    
    print("\nOption 2: Use unpacked extension")
    print("---------------------------------------")
    print("1. Download extension from Chrome Web Store")
    print("2. Extract the extension files")
    print(f"3. Copy the extracted folder to: {ext_folder.absolute()}/")
    print("4. Ensure manifest.json is present")
    
    print("\nOption 3: Skip extension (not recommended)")
    print("---------------------------------------")
    print("Extension helps solve CAPTCHAs automatically")
    print("Without it, you'll need to solve CAPTCHAs manually")
    
    response = input("\n>>> Do you want to add the extension manually now? (y/n): ")
    
    if response.lower() == 'y':
        print(f"\n📂 Opening extension folder: {ext_folder.absolute()}")
        try:
            os.startfile(ext_folder.absolute())
        except:
            print(f"   Path: {ext_folder.absolute()}")
        
        input("\n>>> Press Enter after copying the extension files...")
        
        # Verify extension was added
        files = list(ext_folder.iterdir())
        if files:
            print(f"\n✅ Found {len(files)} file(s) in extension folder")
            for f in files:
                print(f"   - {f.name}")
            return True
        else:
            print("\n❌ No files found in extension folder")
            return False
    else:
        print("\n⚠️  Skipping extension setup")
        print("   You can add extensions to bundled_extensions/ folder later")
        return False

def create_extension_readme():
    """Create README in bundled_extensions folder"""
    
    readme_content = """
# Bundled Extensions Folder

This folder contains Chrome extensions that will be automatically loaded when the application runs.

## How It Works

The application automatically loads extensions from this folder:
- `.crx` files are loaded as packed extensions
- Folders with `manifest.json` are loaded as unpacked extensions

## Adding Extensions

### Method 1: Packed Extension (.crx)
1. Download the extension as a .crx file
2. Place it in this folder
3. Rebuild the application

### Method 2: Unpacked Extension (folder)
1. Extract the extension to a folder
2. Ensure the folder contains `manifest.json`
3. Copy the folder here
4. Rebuild the application

## Pre-configured Extensions

### RektCaptcha (Recommended)
- **Purpose:** Automatic CAPTCHA solving
- **ID:** bbdhfoclddncoaomddgkaaphcnddbpdh
- **Store URL:** https://chromewebstore.google.com/detail/bbdhfoclddncoaomddgkaaphcnddbpdh
- **Setup:** Run `python setup_extension_bundle.py`

## For Users

Users don't need to install extensions separately - they're bundled in the EXE!

When the application runs:
✅ Extensions are automatically extracted
✅ Chrome loads them automatically
✅ No manual installation needed

## Troubleshooting

**Extension not loading?**
- Check manifest.json exists
- Verify extension ID is correct
- Rebuild the application after changes

**Need a different extension?**
- Find extension ID in Chrome Web Store URL
- Download as .crx or extract files
- Add to this folder and rebuild
"""
    
    readme_path = Path("bundled_extensions") / "README.txt"
    with open(readme_path, 'w', encoding='utf-8') as f:
        f.write(readme_content)
    
    print(f"✅ Created: {readme_path}")

def main():
    """Main setup function"""
    
    print("\n" + "=" * 70)
    print("SETUP BUNDLED EXTENSIONS FOR STANDALONE EXE")
    print("=" * 70)
    print()
    print("This script prepares Chrome extensions to be bundled into your")
    print("standalone executable. Users won't need to install extensions!")
    print()
    
    # Setup RektCaptcha
    success = setup_rektcaptcha_extension()
    
    # Create README
    if Path("bundled_extensions").exists():
        create_extension_readme()
    
    print("\n" + "=" * 70)
    print("SETUP COMPLETE")
    print("=" * 70)
    
    if success:
        print("\n✅ Extensions ready for bundling!")
        print("\nNext steps:")
        print("1. Run: python build_exe.py")
        print("2. Extensions will be bundled automatically")
        print("3. Users get extensions pre-loaded - no manual setup!")
    else:
        print("\n⚠️  No extensions configured")
        print("\nYou can:")
        print("1. Add extension files to bundled_extensions/ folder")
        print("2. Run this script again")
        print("3. Build without extensions (users install manually)")
    
    print("\n📁 Extension folder: bundled_extensions/")
    print("   Add any Chrome extension here before building")
    print()

if __name__ == "__main__":
    main()
