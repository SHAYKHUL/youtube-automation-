"""
Test script to verify extension setup for discover_signin_emails.py
This will check if the extension system is properly configured
"""

import os
import sys
from pathlib import Path

print("=" * 60)
print("  Extension System Check for discover_signin_emails.py")
print("=" * 60)

# Check working directory
print(f"\n📂 Working Directory: {os.getcwd()}")

# Test imports
print("\n🔍 Testing Module Imports...")
try:
    import discover_signin_emails
    print("  ✓ discover_signin_emails")
except Exception as e:
    print(f"  ✗ discover_signin_emails: {e}")
    sys.exit(1)

try:
    from extension_manager import ExtensionManager
    print("  ✓ extension_manager")
except Exception as e:
    print(f"  ✗ extension_manager: {e}")
    sys.exit(1)

try:
    import chrome_utils
    print("  ✓ chrome_utils")
except Exception as e:
    print(f"  ✗ chrome_utils: {e}")
    sys.exit(1)

# Check for bundled extension
print("\n🧩 Checking for Bundled Extension...")
bundled_ext = Path("bundled_extensions/rektcaptcha")
if bundled_ext.exists():
    manifest = bundled_ext / "manifest.json"
    if manifest.exists():
        try:
            import json
            with open(manifest, 'r', encoding='utf-8') as f:
                data = json.load(f)
            print(f"  ✓ Found: {data.get('name', 'Unknown')}")
            print(f"  ✓ Version: {data.get('version', 'Unknown')}")
            file_count = sum(1 for _ in bundled_ext.rglob('*') if _.is_file())
            print(f"  ✓ Files: {file_count}")
        except Exception as e:
            print(f"  ⚠️  Extension found but manifest corrupted: {e}")
            print("  ℹ️  Run: python setup_rektcaptcha.py")
    else:
        print("  ⚠️  Extension folder found but no manifest.json")
        print("  ℹ️  Run: python setup_rektcaptcha.py")
else:
    print("  ⚠️  No bundled extension found")
    print("  ℹ️  Run: python setup_rektcaptcha.py")

# Check chrome_profile extension
print("\n🌐 Checking Chrome Profile Extension...")
chrome_profile_ext = Path("chrome_profile/Default/Extensions/bbdhfoclddncoaomddgkaaphcnddbpdh")
if chrome_profile_ext.exists():
    version_dirs = list(chrome_profile_ext.glob("*"))
    if version_dirs:
        ext_dir = version_dirs[0]
        manifest = ext_dir / "manifest.json"
        if manifest.exists():
            try:
                import json
                with open(manifest, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                print(f"  ✓ Found: {data.get('name', 'Unknown')}")
                print(f"  ✓ Location: {ext_dir}")
            except Exception as e:
                print(f"  ⚠️  Extension in profile but manifest corrupted: {e}")
                print("  ℹ️  Run: python setup_rektcaptcha.py")
        else:
            print("  ⚠️  Extension folder in profile but no manifest.json")
    else:
        print("  ⚠️  Extension ID folder exists but no version folder")
else:
    print("  ℹ️  No extension in chrome_profile (will be added on first run)")

# Check CSV files
print("\n📋 Checking Required CSV Files...")
csv_files = {
    "signin_to_see_email.csv": "Input file with channels to discover",
    "gmail_accounts.csv": "Gmail accounts for authentication",
    "discovered_emails_authenticated.csv": "Output file for discovered emails"
}

for csv_file, description in csv_files.items():
    csv_path = Path(csv_file)
    if csv_path.exists():
        print(f"  ✓ {csv_file} - {description}")
    else:
        print(f"  ℹ️  {csv_file} - Will be created if needed")

# Final status
print("\n" + "=" * 60)
print("  Status Summary")
print("=" * 60)

all_good = True
if not bundled_ext.exists():
    print("⚠️  Extension not installed - CAPTCHA solving won't work")
    print("   → Run: python setup_rektcaptcha.py")
    all_good = False
else:
    manifest = bundled_ext / "manifest.json"
    if manifest.exists():
        try:
            import json
            with open(manifest, 'r', encoding='utf-8') as f:
                data = json.load(f)
            print("✅ Extension installed and ready for CAPTCHA solving")
        except:
            print("⚠️  Extension found but corrupted")
            print("   → Run: python setup_rektcaptcha.py")
            all_good = False
    else:
        print("⚠️  Extension found but incomplete")
        print("   → Run: python setup_rektcaptcha.py")
        all_good = False

print("\n📝 To discover authenticated emails:")
print("   1. Make sure extension is installed (see above)")
print("   2. Add channels to signin_to_see_email.csv")
print("   3. Add Gmail accounts to gmail_accounts.csv")
print("   4. Run: python discover_signin_emails.py")
print("   5. Or use the GUI: python youtube_automation_gui.py")
print()
