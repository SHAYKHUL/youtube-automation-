"""
Test script to verify EXE can import modules
Run this from the dist folder: python -c "exec(open('../test_exe_modules.py').read())"
"""
import sys
import os

print("=" * 70)
print("TESTING MODULE IMPORTS FROM FROZEN EXE")
print("=" * 70)

# Check if running as frozen
if getattr(sys, 'frozen', False):
    print(f"✅ Running as FROZEN executable")
    print(f"   Bundle dir: {sys._MEIPASS}")
    bundle_dir = sys._MEIPASS
else:
    print(f"ℹ️  Running as Python script")
    bundle_dir = os.path.dirname(os.path.abspath(__file__))

print(f"\nPython Path:")
for i, path in enumerate(sys.path[:5], 1):
    print(f"   {i}. {path}")

print(f"\n" + "=" * 70)
print("TESTING IMPORTS...")
print("=" * 70)

# Test imports
modules_to_test = [
    'auto',
    'chrome_utils', 
    'email_finder',
    'youtube_login',
    'discover_signin_emails',
]

success_count = 0
failed_modules = []

for module_name in modules_to_test:
    try:
        # Try importing
        module = __import__(module_name)
        print(f"✅ {module_name:30s} - OK")
        
        # Show location
        if hasattr(module, '__file__'):
            print(f"   └─ Location: {module.__file__}")
        success_count += 1
    except Exception as e:
        print(f"❌ {module_name:30s} - FAILED: {e}")
        failed_modules.append(module_name)

print(f"\n" + "=" * 70)
print(f"RESULTS: {success_count}/{len(modules_to_test)} modules loaded successfully")
print("=" * 70)

if failed_modules:
    print(f"\n❌ Failed modules: {', '.join(failed_modules)}")
    sys.exit(1)
else:
    print(f"\n✅ All critical modules loaded successfully!")
    sys.exit(0)
