"""
Test script to verify email finder functionality
"""
import os
import csv

def create_test_csv():
    """Create a test CSV file with sample YouTube channel links"""
    test_file = "test_channels.csv"
    
    # Sample YouTube channel links for testing
    test_channels = [
        "https://www.youtube.com/@mkbhd",
        "https://www.youtube.com/@LinusTechTips",
        "https://www.youtube.com/@veritasium",
    ]
    
    with open(test_file, 'w', encoding='utf-8', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(["Channel Link"])  # Header
        for channel in test_channels:
            writer.writerow([channel])
    
    print(f"✅ Created test CSV: {test_file}")
    print(f"   Contains {len(test_channels)} channel links")
    return test_file

def verify_output_files():
    """Verify that output CSV files are created correctly"""
    output_files = [
        'founded_email.csv',
        'not_email_but_social.csv',
        'non_founded_email.csv',
        'signin_to_see_email.csv'
    ]
    
    print("\n📊 Output Files Status:")
    for file in output_files:
        if os.path.exists(file):
            with open(file, 'r', encoding='utf-8') as f:
                lines = sum(1 for _ in f)
            print(f"   ✅ {file}: {lines} rows")
        else:
            print(f"   ❌ {file}: Not found")

if __name__ == "__main__":
    print("🧪 Email Finder Test Utility\n")
    print("=" * 50)
    
    # Create test CSV
    test_file = create_test_csv()
    
    print(f"\n📝 Instructions:")
    print(f"   1. Open the GUI: python youtube_automation_gui_pro.py")
    print(f"   2. Go to 'Email Finder' tab")
    print(f"   3. Browse and select: {test_file}")
    print(f"   4. Set parallel windows: 1-3")
    print(f"   5. Click 'Start Email Finder'")
    print(f"   6. Watch live results populate the table")
    print(f"   7. Check statistics panel for counts")
    
    print(f"\n🔍 Expected Results:")
    print(f"   • Table should show results in real-time")
    print(f"   • Statistics should update live")
    print(f"   • Different badge colors for each status")
    print(f"   • Final summary dialog on completion")
    
    print(f"\n📂 Output Files:")
    print(f"   After completion, check these files:")
    print(f"   • founded_email.csv (emails found)")
    print(f"   • not_email_but_social.csv (social only)")
    print(f"   • signin_to_see_email.csv (signin required)")
    print(f"   • non_founded_email.csv (nothing found)")
    
    print("\n" + "=" * 50)
    
    # Check if output files exist from previous runs
    verify_output_files()
