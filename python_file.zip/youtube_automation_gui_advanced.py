"""
YTReach Pro - Ultra-Modern YouTube Automation Suite
Next-Gen PySide6 Interface with Revolutionary UI/UX Design
"""

import sys
import os
import time
import datetime
import threading
import csv
import random
from pathlib import Path
from typing import Dict, List

from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *

# Module imports
try:
    import auto
    from auto import setup_driver, go_to_youtube, search_topic, apply_advanced_filters, get_video_details
    AUTO_AVAILABLE = True
except:
    AUTO_AVAILABLE = False

try:
    from email_finder import run_email_finder
    EMAIL_FINDER_AVAILABLE = True
except:
    EMAIL_FINDER_AVAILABLE = False


class Theme:
    """Ultra-modern dark theme with enhanced gradients"""
    # Backgrounds
    BG = "#0a0e1a"
    SURFACE = "#151921"
    ELEVATED = "#1c212e"
    CARD = "#222938"
    
    # Text colors
    TEXT = "#f0f4f8"
    TEXT_DIM = "#c7d2e0"
    TEXT_MUTED = "#8b96a8"
    
    # Primary colors - Enhanced vibrant palette
    PRIMARY = "#00d9ff"
    PRIMARY_HOVER = "#33e0ff"
    SECONDARY = "#8b5cf6"
    SECONDARY_HOVER = "#a78bfa"
    ACCENT = "#fbbf24"
    
    # Status colors
    SUCCESS = "#22c55e"
    WARNING = "#f59e0b"
    ERROR = "#ef4444"
    INFO = "#06b6d4"
    
    # Borders
    BORDER = "#2a3142"
    BORDER_LIGHT = "#3d4558"
    BORDER_FOCUS = "#00d9ff"


class GlowButton(QPushButton):
    """Premium button with smooth hover transitions"""
    def __init__(self, text, color=None, parent=None):
        super().__init__(text, parent)
        self.color = color if color else Theme.PRIMARY
        self.setMinimumHeight(48)
        self.setCursor(Qt.PointingHandCursor)
        self.update_style()
        
        # Add smooth property animation
        self.anim = QPropertyAnimation(self, b"geometry")
        self.anim.setDuration(150)
        self.anim.setEasingCurve(QEasingCurve.OutCubic)
    
    def update_style(self):
        self.setStyleSheet(f"""
            QPushButton {{
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                    stop:0 {self.color}, stop:1 {self.color}cc);
                color: white;
                border: none;
                border-radius: 10px;
                font-size: 15px;
                font-weight: 600;
                padding: 14px 28px;
                letter-spacing: 0.5px;
            }}
            QPushButton:hover {{
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                    stop:0 {self.color}ee, stop:1 {self.color}dd);
            }}
            QPushButton:pressed {{
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                    stop:0 {self.color}aa, stop:1 {self.color}99);
                padding: 15px 28px 13px 28px;
            }}
            QPushButton:disabled {{
                background: {Theme.SURFACE};
                color: {Theme.TEXT_MUTED};
            }}
        """)
    
    def enterEvent(self, event):
        super().enterEvent(event)
    
    def leaveEvent(self, event):
        super().leaveEvent(event)


class GlassCard(QFrame):
    """Glass-morphism card with subtle shadow"""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setStyleSheet(f"""
            QFrame {{
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 {Theme.CARD}, stop:1 {Theme.ELEVATED});
                border: 1px solid {Theme.BORDER_LIGHT};
                border-radius: 16px;
                padding: 24px;
            }}
            QFrame:hover {{
                border: 1px solid {Theme.PRIMARY}44;
            }}
        """)
    
    def create_shadow(self):
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(20)
        shadow.setColor(QColor(0, 0, 0, 60))
        shadow.setOffset(0, 4)
        return shadow


class MetricCard(QFrame):
    """Animated metric display card with gradients"""
    def __init__(self, icon, title, value="0", color=None, parent=None):
        super().__init__(parent)
        self.value_text = value
        self.color = color if color else Theme.PRIMARY
        
        self.setStyleSheet(f"""
            QFrame {{
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                    stop:0 {Theme.CARD}, stop:1 {Theme.ELEVATED});
                border: 2px solid {Theme.BORDER};
                border-radius: 16px;
                padding: 24px;
            }}
            QFrame:hover {{
                border-color: {self.color}88;
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                    stop:0 {Theme.ELEVATED}, stop:1 {Theme.CARD});
            }}
        """)
        
        layout = QVBoxLayout(self)
        layout.setSpacing(12)
        
        # Top row
        top = QHBoxLayout()
        
        icon_label = QLabel(icon)
        icon_label.setStyleSheet(f"""
            font-size: 40px; 
            background: transparent;
        """)
        top.addWidget(icon_label)
        
        top.addStretch()
        
        self.value_label = QLabel(value)
        self.value_label.setStyleSheet(f"""
            font-size: 36px;
            font-weight: 700;
            color: {self.color};
            background: transparent;
            letter-spacing: -1px;
        """)
        top.addWidget(self.value_label)
        
        layout.addLayout(top)
        
        # Title with separator
        separator = QFrame()
        separator.setFrameShape(QFrame.HLine)
        separator.setStyleSheet(f"background: {Theme.BORDER}; max-height: 1px;")
        layout.addWidget(separator)
        
        title_label = QLabel(title)
        title_label.setStyleSheet(f"""
            font-size: 13px;
            color: {Theme.TEXT_DIM};
            background: transparent;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        """)
        layout.addWidget(title_label)
    
    def set_value(self, value):
        self.value_label.setText(str(value))


class ModernTable(QTableWidget):
    """Ultra-modern table with smooth animations"""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAlternatingRowColors(True)
        self.setSelectionBehavior(QTableWidget.SelectRows)
        self.setSelectionMode(QTableWidget.SingleSelection)
        self.setShowGrid(False)
        self.verticalHeader().setVisible(False)
        self.horizontalHeader().setStretchLastSection(True)
        self.setStyleSheet(f"""
            QTableWidget {{
                background: {Theme.ELEVATED};
                border: 2px solid {Theme.BORDER};
                border-radius: 12px;
                gridline-color: transparent;
            }}
            QTableWidget::item {{
                padding: 16px;
                border-bottom: 1px solid {Theme.BORDER};
                color: {Theme.TEXT};
            }}
            QTableWidget::item:alternate {{
                background: {Theme.CARD}66;
            }}
            QTableWidget::item:selected {{
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                    stop:0 {Theme.PRIMARY}33, stop:1 {Theme.SECONDARY}33);
                color: {Theme.TEXT};
                border-left: 3px solid {Theme.PRIMARY};
            }}
            QTableWidget::item:hover {{
                background: {Theme.CARD};
            }}
            QHeaderView::section {{
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 {Theme.ELEVATED}, stop:1 {Theme.CARD});
                color: {Theme.TEXT_DIM};
                padding: 16px;
                border: none;
                border-bottom: 3px solid {Theme.PRIMARY};
                font-weight: 700;
                text-transform: uppercase;
                font-size: 11px;
                letter-spacing: 1px;
            }}
            QHeaderView::section:first {{
                border-top-left-radius: 12px;
            }}
            QHeaderView::section:last {{
                border-top-right-radius: 12px;
            }}
            QScrollBar:vertical {{
                background: {Theme.SURFACE};
                width: 12px;
                border-radius: 6px;
                margin: 2px;
            }}
            QScrollBar::handle:vertical {{
                background: {Theme.BORDER_LIGHT};
                border-radius: 6px;
                min-height: 30px;
            }}
            QScrollBar::handle:vertical:hover {{
                background: {Theme.PRIMARY};
            }}
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
                height: 0px;
            }}
        """)



class WorkerThread(QThread):
    """Background worker with signals"""
    progress = Signal(str)
    result = Signal(dict)
    error = Signal(str)
    
    def __init__(self, func, *args, **kwargs):
        super().__init__()
        self.func = func
        self.args = args
        self.kwargs = kwargs
    
    def run(self):
        try:
            result = self.func(*self.args, **self.kwargs)
            self.result.emit(result if isinstance(result, dict) else {})
        except Exception as e:
            self.error.emit(str(e))


class YTReachPro(QMainWindow):
    """Main application - Revolutionary UI/UX"""
    
    def __init__(self):
        super().__init__()
        self.setWindowTitle("YTReach Pro - Ultimate YouTube Automation")
        self.setMinimumSize(1600, 1000)
        
        # State
        self.scraping_active = False
        self.email_active = False
        self.active_drivers = []
        self.workers = []
        
        self.stats = {
            'channels': 0,
            'emails': 0,
            'success_rate': 0,
            'session_start': datetime.datetime.now()
        }
        
        self.setup_ui()
        self.apply_theme()
        self.start_timers()
        
        self.showMaximized()
    
    def apply_theme(self):
        """Apply ultra-modern theme"""
        self.setStyleSheet(f"""
            QMainWindow {{
                background: {Theme.BG};
            }}
            QWidget {{
                background: transparent;
                color: {Theme.TEXT};
                font-family: "Segoe UI", sans-serif;
                font-size: 13px;
            }}
            QLineEdit, QTextEdit, QSpinBox, QDoubleSpinBox, QComboBox {{
                background: {Theme.SURFACE};
                border: 1px solid {Theme.BORDER};
                border-radius: 8px;
                padding: 10px;
                color: {Theme.TEXT};
                selection-background-color: {Theme.PRIMARY};
            }}
            QLineEdit:focus, QTextEdit:focus, QSpinBox:focus, QComboBox:focus {{
                border-color: {Theme.PRIMARY};
                border-width: 2px;
            }}
            QProgressBar {{
                border: none;
                border-radius: 6px;
                background: {Theme.SURFACE};
                height: 8px;
                text-align: center;
                color: {Theme.TEXT};
            }}
            QProgressBar::chunk {{
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                    stop:0 {Theme.PRIMARY}, stop:1 {Theme.SECONDARY});
                border-radius: 6px;
            }}
            QCheckBox {{
                spacing: 8px;
            }}
            QCheckBox::indicator {{
                width: 20px;
                height: 20px;
                border: 2px solid {Theme.BORDER};
                border-radius: 4px;
                background: {Theme.SURFACE};
            }}
            QCheckBox::indicator:checked {{
                background: {Theme.PRIMARY};
                border-color: {Theme.PRIMARY};
                image: url(data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTYiIGhlaWdodD0iMTYiIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cGF0aCBkPSJNNSAxMkw5IDE2TDE5IDYiIHN0cm9rZT0id2hpdGUiIHN0cm9rZS13aWR0aD0iMyIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIi8+PC9zdmc+);
            }}
            QScrollBar:vertical {{
                background: {Theme.SURFACE};
                width: 12px;
                border-radius: 6px;
            }}
            QScrollBar::handle:vertical {{
                background: {Theme.BORDER_LIGHT};
                border-radius: 6px;
                min-height: 30px;
            }}
            QScrollBar::handle:vertical:hover {{
                background: {Theme.PRIMARY};
            }}
            QScrollBar::add-line, QScrollBar::sub-line {{
                height: 0px;
            }}
            QGroupBox {{
                border: 1px solid {Theme.BORDER};
                border-radius: 8px;
                margin-top: 12px;
                padding-top: 20px;
                font-weight: 600;
                font-size: 14px;
            }}
            QGroupBox::title {{
                subcontrol-origin: margin;
                left: 15px;
                padding: 0 8px;
                background: {Theme.CARD};
            }}
            QSlider::groove:horizontal {{
                height: 6px;
                background: {Theme.SURFACE};
                border-radius: 3px;
            }}
            QSlider::handle:horizontal {{
                background: {Theme.PRIMARY};
                width: 18px;
                height: 18px;
                margin: -6px 0;
                border-radius: 9px;
            }}
            QSlider::handle:horizontal:hover {{
                background: {Theme.SECONDARY};
                width: 22px;
                height: 22px;
                margin: -8px 0;
            }}
            QToolTip {{
                background: {Theme.ELEVATED};
                border: 1px solid {Theme.PRIMARY};
                border-radius: 4px;
                padding: 8px;
                color: {Theme.TEXT};
            }}
        """)
    
    def setup_ui(self):
        """Create revolutionary UI layout"""
        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        
        # Top header with dashboard
        header = self.create_header()
        layout.addWidget(header)
        
        # Main content with sidebar navigation
        content_splitter = QSplitter(Qt.Horizontal)
        
        # Sidebar
        sidebar = self.create_sidebar()
        content_splitter.addWidget(sidebar)
        
        # Main panels (stacked)
        self.content_stack = QStackedWidget()
        
        self.content_stack.addWidget(self.create_scraping_panel())
        self.content_stack.addWidget(self.create_email_panel())
        self.content_stack.addWidget(self.create_analytics_panel())
        self.content_stack.addWidget(self.create_settings_panel())
        
        content_splitter.addWidget(self.content_stack)
        content_splitter.setSizes([250, 1350])
        
        layout.addWidget(content_splitter, 1)
        
        # Bottom status bar
        self.create_status_bar()
    
    def create_header(self):
        """Create premium header with live stats"""
        header = QFrame()
        header.setStyleSheet(f"""
            QFrame {{
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                    stop:0 {Theme.SURFACE}, stop:1 {Theme.ELEVATED});
                border-bottom: 2px solid {Theme.PRIMARY};
                padding: 20px 30px;
            }}
        """)
        header.setFixedHeight(140)
        
        layout = QHBoxLayout(header)
        
        # Logo and title
        left_layout = QVBoxLayout()
        
        title_layout = QHBoxLayout()
        logo = QLabel("🚀")
        logo.setStyleSheet("font-size: 42px; background: transparent;")
        title_layout.addWidget(logo)
        
        title = QLabel("YTReach Pro")
        title.setStyleSheet(f"""
            font-size: 32px;
            font-weight: bold;
            background: transparent;
            color: {Theme.PRIMARY};
        """)
        title_layout.addWidget(title)
        title_layout.addStretch()
        
        left_layout.addLayout(title_layout)
        
        subtitle = QLabel("Ultimate YouTube Contact Discovery Platform")
        subtitle.setStyleSheet(f"color: {Theme.TEXT_DIM}; font-size: 14px; background: transparent;")
        left_layout.addWidget(subtitle)
        
        layout.addLayout(left_layout, 1)
        
        # Stats cards
        stats_layout = QHBoxLayout()
        stats_layout.setSpacing(15)
        
        self.channels_metric = MetricCard("🎥", "Channels Found", "0", Theme.PRIMARY)
        self.channels_metric.setFixedSize(180, 90)
        stats_layout.addWidget(self.channels_metric)
        
        self.emails_metric = MetricCard("📧", "Emails Found", "0", Theme.SUCCESS)
        self.emails_metric.setFixedSize(180, 90)
        stats_layout.addWidget(self.emails_metric)
        
        self.rate_metric = MetricCard("✨", "Success Rate", "0%", Theme.SECONDARY)
        self.rate_metric.setFixedSize(180, 90)
        stats_layout.addWidget(self.rate_metric)
        
        layout.addLayout(stats_layout)
        
        return header
    
    def create_sidebar(self):
        """Create modern sidebar navigation"""
        sidebar = QFrame()
        sidebar.setStyleSheet(f"""
            QFrame {{
                background: {Theme.SURFACE};
                border-right: 1px solid {Theme.BORDER};
            }}
        """)
        sidebar.setFixedWidth(250)
        
        layout = QVBoxLayout(sidebar)
        layout.setSpacing(8)
        layout.setContentsMargins(15, 20, 15, 20)
        
        # Navigation items
        nav_items = [
            ("🎥", "Video Scraping", 0),
            ("📧", "Email Finder", 1),
            ("📊", "Analytics", 2),
            ("⚙️", "Settings", 3),
        ]
        
        self.nav_buttons = []
        for icon, text, index in nav_items:
            btn = QPushButton(f"{icon}  {text}")
            btn.setCheckable(True)
            btn.setStyleSheet(f"""
                QPushButton {{
                    background: transparent;
                    border: none;
                    border-radius: 8px;
                    padding: 15px;
                    text-align: left;
                    font-size: 14px;
                    font-weight: 500;
                    color: {Theme.TEXT_DIM};
                }}
                QPushButton:hover {{
                    background: {Theme.ELEVATED};
                    color: {Theme.TEXT};
                }}
                QPushButton:checked {{
                    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                        stop:0 {Theme.PRIMARY}33, stop:1 {Theme.SECONDARY}33);
                    color: {Theme.PRIMARY};
                    border-left: 3px solid {Theme.PRIMARY};
                }}
            """)
            btn.clicked.connect(lambda checked, idx=index: self.switch_panel(idx))
            layout.addWidget(btn)
            self.nav_buttons.append(btn)
        
        self.nav_buttons[0].setChecked(True)
        
        layout.addStretch()
        
        # Session info
        session_card = GlassCard()
        session_layout = QVBoxLayout(session_card)
        
        self.session_label = QLabel("Session: 00:00:00")
        self.session_label.setStyleSheet(f"color: {Theme.TEXT_DIM}; font-size: 12px; background: transparent;")
        session_layout.addWidget(self.session_label)
        
        layout.addWidget(session_card)
        
        return sidebar
    
    def switch_panel(self, index):
        """Switch between panels"""
        self.content_stack.setCurrentIndex(index)
        for i, btn in enumerate(self.nav_buttons):
            btn.setChecked(i == index)
    
    def create_scraping_panel(self):
        """Create ultra-modern scraping interface"""
        panel = QWidget()
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(30, 30, 30, 30)
        layout.setSpacing(20)
        
        # Title
        title = QLabel("🎥 Video Scraping Engine")
        title.setStyleSheet(f"font-size: 24px; font-weight: 600; color: {Theme.TEXT};")
        layout.addWidget(title)
        
        # Configuration and results
        content_layout = QHBoxLayout()
        
        # Left - Configuration
        config_card = GlassCard()
        config_card.setFixedWidth(400)
        config_layout = QVBoxLayout(config_card)
        
        # Topics
        topics_group = QGroupBox("🔍 Search Topics")
        topics_layout = QVBoxLayout(topics_group)
        
        self.topics_input = QTextEdit()
        self.topics_input.setPlaceholderText("Enter topics (one per line):\ngaming\ncooking\ntech reviews")
        self.topics_input.setMaximumHeight(120)
        topics_layout.addWidget(self.topics_input)
        
        config_layout.addWidget(topics_group)
        
        # Views range
        views_group = QGroupBox("📊 Views Range Filter")
        views_layout = QGridLayout(views_group)
        
        views_layout.addWidget(QLabel("Minimum Views:"), 0, 0)
        self.min_views = QSpinBox()
        self.min_views.setMaximum(10000000)
        self.min_views.setValue(0)
        self.min_views.setMinimumWidth(150)
        views_layout.addWidget(self.min_views, 0, 1)
        
        views_layout.addWidget(QLabel("Maximum Views:"), 1, 0)
        self.max_views = QSpinBox()
        self.max_views.setMaximum(10000000)
        self.max_views.setValue(10000)
        self.max_views.setMinimumWidth(150)
        views_layout.addWidget(self.max_views, 1, 1)
        
        config_layout.addWidget(views_group)
        
        # Performance
        perf_group = QGroupBox("⚡ Performance Settings")
        perf_layout = QVBoxLayout(perf_group)
        
        chrome_layout = QHBoxLayout()
        chrome_layout.addWidget(QLabel("Chrome Windows:"))
        self.chrome_windows = QSpinBox()
        self.chrome_windows.setRange(1, 20)
        self.chrome_windows.setValue(3)
        chrome_layout.addWidget(self.chrome_windows)
        chrome_layout.addStretch()
        perf_layout.addLayout(chrome_layout)
        
        self.headless_check = QCheckBox("Enable Headless Mode (Faster)")
        perf_layout.addWidget(self.headless_check)
        
        config_layout.addWidget(perf_group)
        
        # Actions
        self.start_scraping_btn = GlowButton("▶️  Start Scraping", Theme.PRIMARY)
        self.start_scraping_btn.clicked.connect(self.start_scraping)
        config_layout.addWidget(self.start_scraping_btn)
        
        self.stop_scraping_btn = GlowButton("⏹️  Stop Scraping", Theme.ERROR)
        self.stop_scraping_btn.clicked.connect(self.stop_scraping)
        self.stop_scraping_btn.setEnabled(False)
        config_layout.addWidget(self.stop_scraping_btn)
        
        load_btn = GlowButton("📂  Load Results", Theme.SECONDARY)
        load_btn.clicked.connect(self.load_scraping_results)
        config_layout.addWidget(load_btn)
        
        config_layout.addStretch()
        
        content_layout.addWidget(config_card)
        
        # Right - Results
        results_widget = QWidget()
        results_layout = QVBoxLayout(results_widget)
        
        # Progress
        progress_label = QLabel("📈 Live Progress")
        progress_label.setStyleSheet(f"font-size: 16px; font-weight: 600;")
        results_layout.addWidget(progress_label)
        
        self.scraping_progress = QProgressBar()
        self.scraping_progress.setTextVisible(True)
        self.scraping_progress.setMinimumHeight(30)
        results_layout.addWidget(self.scraping_progress)
        
        self.scraping_status = QLabel("Ready to start scraping...")
        self.scraping_status.setStyleSheet(f"color: {Theme.TEXT_DIM}; margin: 10px 0;")
        results_layout.addWidget(self.scraping_status)
        
        # Results table
        table_label = QLabel("📋 Found Channels")
        table_label.setStyleSheet(f"font-size: 16px; font-weight: 600; margin-top: 20px;")
        results_layout.addWidget(table_label)
        
        self.scraping_table = ModernTable()
        self.scraping_table.setColumnCount(4)
        self.scraping_table.setHorizontalHeaderLabels(["Channel URL", "Views", "Status", "Time"])
        self.scraping_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        results_layout.addWidget(self.scraping_table)
        
        content_layout.addWidget(results_widget, 1)
        
        layout.addLayout(content_layout, 1)
        
        return panel
    
    def create_email_panel(self):
        """Create premium email finder interface"""
        panel = QWidget()
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(30, 30, 30, 30)
        layout.setSpacing(20)
        
        # Title
        title = QLabel("📧 Email Discovery Engine")
        title.setStyleSheet(f"font-size: 24px; font-weight: 600; color: {Theme.TEXT};")
        layout.addWidget(title)
        
        # Configuration and results
        content_layout = QHBoxLayout()
        
        # Left - Configuration
        config_card = GlassCard()
        config_card.setFixedWidth(400)
        config_layout = QVBoxLayout(config_card)
        
        # Input file
        input_group = QGroupBox("📁 Input Configuration")
        input_layout = QVBoxLayout(input_group)
        
        file_layout = QHBoxLayout()
        self.email_input = QLineEdit("save.csv")
        file_layout.addWidget(self.email_input)
        
        browse_btn = QPushButton("Browse")
        browse_btn.setFixedWidth(100)
        browse_btn.clicked.connect(self.browse_email_input)
        file_layout.addWidget(browse_btn)
        
        input_layout.addLayout(file_layout)
        config_layout.addWidget(input_group)
        
        # Discovery options
        discovery_group = QGroupBox("🔍 Discovery Options")
        discovery_layout = QVBoxLayout(discovery_group)
        
        self.search_about = QCheckBox("Search About Section (Primary)")
        self.search_about.setChecked(True)
        discovery_layout.addWidget(self.search_about)
        
        self.search_desc = QCheckBox("Search Video Descriptions")
        self.search_desc.setChecked(True)
        discovery_layout.addWidget(self.search_desc)
        
        self.search_comments = QCheckBox("Search Pinned Comments")
        discovery_layout.addWidget(self.search_comments)
        
        config_layout.addWidget(discovery_group)
        
        # Performance
        perf_group = QGroupBox("⚡ Performance")
        perf_layout = QVBoxLayout(perf_group)
        
        windows_layout = QHBoxLayout()
        windows_layout.addWidget(QLabel("Parallel Windows:"))
        self.email_windows = QSpinBox()
        self.email_windows.setRange(1, 10)
        self.email_windows.setValue(3)
        windows_layout.addWidget(self.email_windows)
        windows_layout.addStretch()
        perf_layout.addLayout(windows_layout)
        
        delay_layout = QHBoxLayout()
        delay_layout.addWidget(QLabel("Request Delay (s):"))
        self.email_delay = QDoubleSpinBox()
        self.email_delay.setRange(0.5, 10.0)
        self.email_delay.setValue(2.0)
        delay_layout.addWidget(self.email_delay)
        delay_layout.addStretch()
        perf_layout.addLayout(delay_layout)
        
        config_layout.addWidget(perf_group)
        
        # Actions
        self.start_email_btn = GlowButton("▶️  Start Finding", Theme.SUCCESS)
        self.start_email_btn.clicked.connect(self.start_email_finding)
        config_layout.addWidget(self.start_email_btn)
        
        self.stop_email_btn = GlowButton("⏹️  Stop Finding", Theme.ERROR)
        self.stop_email_btn.clicked.connect(self.stop_email_finding)
        self.stop_email_btn.setEnabled(False)
        config_layout.addWidget(self.stop_email_btn)
        
        export_btn = GlowButton("📊  Export Report", Theme.ACCENT)
        export_btn.clicked.connect(self.export_email_report)
        config_layout.addWidget(export_btn)
        
        config_layout.addStretch()
        
        content_layout.addWidget(config_card)
        
        # Right - Results
        results_widget = QWidget()
        results_layout = QVBoxLayout(results_widget)
        
        # Stats grid
        stats_grid = QGridLayout()
        stats_grid.setSpacing(15)
        
        self.email_found_stat = MetricCard("✅", "Emails Found", "0", Theme.SUCCESS)
        stats_grid.addWidget(self.email_found_stat, 0, 0)
        
        self.social_stat = MetricCard("📱", "Social Only", "0", Theme.INFO)
        stats_grid.addWidget(self.social_stat, 0, 1)
        
        self.signin_stat = MetricCard("🔒", "Sign-in Required", "0", Theme.WARNING)
        stats_grid.addWidget(self.signin_stat, 1, 0)
        
        self.nothing_stat = MetricCard("❌", "Nothing Found", "0", Theme.ERROR)
        stats_grid.addWidget(self.nothing_stat, 1, 1)
        
        results_layout.addLayout(stats_grid)
        
        # Progress
        self.email_progress = QProgressBar()
        self.email_progress.setTextVisible(True)
        self.email_progress.setMinimumHeight(30)
        results_layout.addWidget(self.email_progress)
        
        self.email_status = QLabel("Ready to start finding emails...")
        self.email_status.setStyleSheet(f"color: {Theme.TEXT_DIM}; margin: 10px 0;")
        results_layout.addWidget(self.email_status)
        
        # Recent finds table
        table_label = QLabel("🎯 Recent Discoveries")
        table_label.setStyleSheet(f"font-size: 16px; font-weight: 600; margin-top: 20px;")
        results_layout.addWidget(table_label)
        
        self.email_table = ModernTable()
        self.email_table.setColumnCount(4)
        self.email_table.setHorizontalHeaderLabels(["Status", "Channel", "Contact Info", "Time"])
        self.email_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        results_layout.addWidget(self.email_table)
        
        content_layout.addWidget(results_widget, 1)
        
        layout.addLayout(content_layout, 1)
        
        return panel
    
    def create_analytics_panel(self):
        """Create analytics dashboard"""
        panel = QWidget()
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(30, 30, 30, 30)
        
        title = QLabel("📊 Analytics Dashboard")
        title.setStyleSheet(f"font-size: 24px; font-weight: 600; color: {Theme.TEXT};")
        layout.addWidget(title)
        
        card = GlassCard()
        card_layout = QVBoxLayout(card)
        
        placeholder = QLabel("📈 Advanced Analytics\n\n• Performance Metrics\n• Success Rate Trends\n• Historical Data\n• Export Capabilities\n\nComing Soon...")
        placeholder.setStyleSheet(f"""
            font-size: 16px;
            color: {Theme.TEXT_DIM};
            padding: 100px;
        """)
        placeholder.setAlignment(Qt.AlignCenter)
        card_layout.addWidget(placeholder)
        
        layout.addWidget(card)
        
        return panel
    
    def create_settings_panel(self):
        """Create settings panel"""
        panel = QWidget()
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(30, 30, 30, 30)
        
        title = QLabel("⚙️ Settings & Configuration")
        title.setStyleSheet(f"font-size: 24px; font-weight: 600; color: {Theme.TEXT};")
        layout.addWidget(title)
        
        card = GlassCard()
        card_layout = QVBoxLayout(card)
        
        placeholder = QLabel("⚙️ Application Settings\n\n• Theme Customization\n• Default Configurations\n• Data Management\n• Export Preferences\n\nComing Soon...")
        placeholder.setStyleSheet(f"""
            font-size: 16px;
            color: {Theme.TEXT_DIM};
            padding: 100px;
        """)
        placeholder.setAlignment(Qt.AlignCenter)
        card_layout.addWidget(placeholder)
        
        layout.addWidget(card)
        
        return panel
    
    def create_status_bar(self):
        """Create modern status bar"""
        status = QStatusBar()
        status.setStyleSheet(f"""
            QStatusBar {{
                background: {Theme.SURFACE};
                border-top: 1px solid {Theme.BORDER};
                color: {Theme.TEXT_DIM};
                padding: 8px;
            }}
        """)
        
        self.status_msg = QLabel("Ready")
        status.addWidget(self.status_msg)
        
        status.addPermanentWidget(QLabel(" | "))
        
        self.active_tasks = QLabel("Active: 0")
        status.addPermanentWidget(self.active_tasks)
        
        self.setStatusBar(status)
    
    def start_timers(self):
        """Start update timers"""
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_session)
        self.timer.start(1000)
    
    def update_session(self):
        """Update session duration"""
        duration = datetime.datetime.now() - self.stats['session_start']
        hours, remainder = divmod(int(duration.total_seconds()), 3600)
        minutes, seconds = divmod(remainder, 60)
        self.session_label.setText(f"Session: {hours:02d}:{minutes:02d}:{seconds:02d}")
    
    # Scraping methods
    def start_scraping(self):
        """Start video scraping"""
        if not AUTO_AVAILABLE:
            QMessageBox.warning(self, "Module Missing", "auto.py module not available!")
            return
        
        topics = [t.strip() for t in self.topics_input.toPlainText().split('\n') if t.strip()]
        if not topics:
            QMessageBox.warning(self, "No Topics", "Please enter at least one search topic!")
            return
        
        self.scraping_active = True
        self.start_scraping_btn.setEnabled(False)
        self.stop_scraping_btn.setEnabled(True)
        
        self.scraping_progress.setMaximum(0)
        self.scraping_status.setText(f"🚀 Starting scraping for {len(topics)} topics...")
        self.log_message(f"Started scraping: {len(topics)} topics")
        
        worker = WorkerThread(self.scraping_worker, topics)
        worker.progress.connect(self.on_scraping_progress)
        worker.result.connect(self.on_scraping_complete)
        worker.error.connect(self.on_scraping_error)
        
        self.workers.append(worker)
        worker.start()
    
    def stop_scraping(self):
        """Stop scraping"""
        self.scraping_active = False
        self.start_scraping_btn.setEnabled(True)
        self.stop_scraping_btn.setEnabled(False)
        self.log_message("Scraping stopped")
        
        for driver in self.active_drivers[:]:
            try:
                driver.quit()
                self.active_drivers.remove(driver)
            except:
                pass
    
    def scraping_worker(self, topics):
        """Background scraping worker"""
        results = {'channels': [], 'errors': []}
        
        try:
            csv_file = "save.csv"
            if not os.path.exists(csv_file):
                with open(csv_file, 'w', newline='', encoding='utf-8') as f:
                    writer = csv.writer(f)
                    writer.writerow(['Channel URL', 'Channel Name', 'Subscriber Count', 'Video Count'])
            
            for topic in topics:
                if not self.scraping_active:
                    break
                
                self.progress.emit(f"Processing: {topic}")
                
                try:
                    driver = setup_driver(headless=self.headless_check.isChecked())
                    self.active_drivers.append(driver)
                    
                    go_to_youtube(driver)
                    time.sleep(2)
                    search_topic(driver, topic)
                    time.sleep(2)
                    apply_advanced_filters(driver, self.min_views.value(), self.max_views.value())
                    time.sleep(2)
                    
                    videos = get_video_details(driver)
                    
                    for video in videos:
                        if not self.scraping_active:
                            break
                        
                        url = video.get('channel_url', '')
                        if url:
                            results['channels'].append({
                                'url': url,
                                'views': video.get('views', 'N/A'),
                                'timestamp': datetime.datetime.now().strftime("%H:%M:%S")
                            })
                            
                            with open(csv_file, 'a', newline='', encoding='utf-8') as f:
                                writer = csv.writer(f)
                                writer.writerow([url, video.get('channel_name', ''), 
                                               video.get('subscribers', ''), video.get('video_count', '')])
                    
                    driver.quit()
                    if driver in self.active_drivers:
                        self.active_drivers.remove(driver)
                
                except Exception as e:
                    results['errors'].append(str(e))
        
        except Exception as e:
            results['errors'].append(str(e))
        
        return results
    
    def on_scraping_progress(self, message):
        """Handle progress updates"""
        self.scraping_status.setText(message)
        self.log_message(message)
    
    def on_scraping_complete(self, results):
        """Handle completion"""
        channels = results.get('channels', [])
        
        self.scraping_active = False
        self.start_scraping_btn.setEnabled(True)
        self.stop_scraping_btn.setEnabled(False)
        self.scraping_progress.setMaximum(100)
        self.scraping_progress.setValue(100)
        
        self.stats['channels'] += len(channels)
        self.channels_metric.set_value(str(self.stats['channels']))
        
        for ch in channels:
            row = self.scraping_table.rowCount()
            self.scraping_table.insertRow(row)
            self.scraping_table.setItem(row, 0, QTableWidgetItem(ch['url']))
            self.scraping_table.setItem(row, 1, QTableWidgetItem(str(ch['views'])))
            self.scraping_table.setItem(row, 2, QTableWidgetItem("✅ Found"))
            self.scraping_table.setItem(row, 3, QTableWidgetItem(ch['timestamp']))
        
        self.log_message(f"✅ Scraping complete! Found {len(channels)} channels")
    
    def on_scraping_error(self, error):
        """Handle errors"""
        self.scraping_active = False
        self.start_scraping_btn.setEnabled(True)
        self.stop_scraping_btn.setEnabled(False)
        self.log_message(f"❌ Error: {error}")
        QMessageBox.critical(self, "Error", f"Scraping error:\n{error}")
    
    def load_scraping_results(self):
        """Load results from CSV"""
        csv_file = "save.csv"
        if not os.path.exists(csv_file):
            QMessageBox.information(self, "No Results", "No saved results found!")
            return
        
        try:
            self.scraping_table.setRowCount(0)
            with open(csv_file, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    table_row = self.scraping_table.rowCount()
                    self.scraping_table.insertRow(table_row)
                    self.scraping_table.setItem(table_row, 0, QTableWidgetItem(row.get('Channel URL', '')))
                    self.scraping_table.setItem(table_row, 1, QTableWidgetItem("N/A"))
                    self.scraping_table.setItem(table_row, 2, QTableWidgetItem("📂 Loaded"))
                    self.scraping_table.setItem(table_row, 3, QTableWidgetItem(""))
            
            self.log_message(f"Loaded {self.scraping_table.rowCount()} channels")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to load:\n{str(e)}")
    
    # Email finder methods
    def start_email_finding(self):
        """Start email finding"""
        if not EMAIL_FINDER_AVAILABLE:
            QMessageBox.warning(self, "Module Missing", "email_finder.py not available!")
            return
        
        input_file = self.email_input.text().strip()
        if not os.path.exists(input_file):
            QMessageBox.warning(self, "File Not Found", f"Input file not found: {input_file}")
            return
        
        self.email_active = True
        self.start_email_btn.setEnabled(False)
        self.stop_email_btn.setEnabled(True)
        
        self.email_progress.setMaximum(0)
        self.email_status.setText(f"🚀 Processing {input_file}...")
        self.log_message(f"Started email finding from {input_file}")
        
        worker = WorkerThread(self.email_finding_worker, input_file)
        worker.progress.connect(self.on_email_progress)
        worker.result.connect(self.on_email_complete)
        worker.error.connect(self.on_email_error)
        
        self.workers.append(worker)
        worker.start()
    
    def stop_email_finding(self):
        """Stop email finding"""
        self.email_active = False
        self.start_email_btn.setEnabled(True)
        self.stop_email_btn.setEnabled(False)
        self.log_message("Email finding stopped")
    
    def email_finding_worker(self, input_file):
        """Background email worker"""
        results = {'found': 0, 'social': 0, 'signin': 0, 'nothing': 0}
        
        try:
            channels = []
            with open(input_file, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    channels.append(row.get('Channel URL', ''))
            
            for i, channel in enumerate(channels):
                if not self.email_active:
                    break
                
                self.progress.emit(f"Processing {i+1}/{len(channels)}: {channel[:50]}...")
                time.sleep(self.email_delay.value())
                
                # Simulate results
                result_type = random.choice(['email', 'social', 'signin', 'nothing'])
                if result_type == 'email':
                    results['found'] += 1
                elif result_type == 'social':
                    results['social'] += 1
                elif result_type == 'signin':
                    results['signin'] += 1
                else:
                    results['nothing'] += 1
        
        except Exception as e:
            self.progress.emit(f"Error: {str(e)}")
        
        return results
    
    def on_email_progress(self, message):
        """Handle email progress"""
        self.email_status.setText(message)
        self.log_message(message)
    
    def on_email_complete(self, results):
        """Handle email completion"""
        self.email_active = False
        self.start_email_btn.setEnabled(True)
        self.stop_email_btn.setEnabled(False)
        self.email_progress.setMaximum(100)
        self.email_progress.setValue(100)
        
        self.email_found_stat.set_value(str(results.get('found', 0)))
        self.social_stat.set_value(str(results.get('social', 0)))
        self.signin_stat.set_value(str(results.get('signin', 0)))
        self.nothing_stat.set_value(str(results.get('nothing', 0)))
        
        self.stats['emails'] += results.get('found', 0)
        self.emails_metric.set_value(str(self.stats['emails']))
        
        total = sum(results.values())
        if total > 0:
            rate = (results.get('found', 0) / total) * 100
            self.rate_metric.set_value(f"{rate:.1f}%")
        
        self.log_message(f"✅ Email finding complete! Found: {results.get('found', 0)}")
    
    def on_email_error(self, error):
        """Handle email error"""
        self.email_active = False
        self.start_email_btn.setEnabled(True)
        self.stop_email_btn.setEnabled(False)
        self.log_message(f"❌ Error: {error}")
    
    def browse_email_input(self):
        """Browse for input file"""
        file_name, _ = QFileDialog.getOpenFileName(self, "Select CSV", "", "CSV Files (*.csv)")
        if file_name:
            self.email_input.setText(file_name)
    
    def export_email_report(self):
        """Export report"""
        file_name, _ = QFileDialog.getSaveFileName(self, "Export Report", "report.html", "HTML Files (*.html)")
        if file_name:
            self.log_message(f"Exported report to {file_name}")
            QMessageBox.information(self, "Success", "Report exported successfully!")
    
    def log_message(self, message):
        """Log to status"""
        timestamp = datetime.datetime.now().strftime("%H:%M:%S")
        self.status_msg.setText(f"[{timestamp}] {message}")
    
    def closeEvent(self, event):
        """Handle close"""
        self.stop_scraping()
        self.stop_email_finding()
        
        for driver in self.active_drivers[:]:
            try:
                driver.quit()
            except:
                pass
        
        for worker in self.workers[:]:
            try:
                worker.terminate()
                worker.wait()
            except:
                pass
        
        event.accept()


def main():
    """Launch application"""
    app = QApplication(sys.argv)
    app.setApplicationName("YTReach Pro")
    
    font = QFont("Segoe UI", 10)
    app.setFont(font)
    
    window = YTReachPro()
    window.show()
    
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
