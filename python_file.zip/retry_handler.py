"""
Retry handler for managing rate limits and transient failures
"""
import time
import random
from functools import wraps
from selenium.common.exceptions import (
    StaleElementReferenceException, 
    TimeoutException,
    WebDriverException,
    ElementClickInterceptedException
)

class RetryHandler:
    def __init__(self, max_retries=3, base_delay=1, max_delay=10):
        self.max_retries = max_retries
        self.base_delay = base_delay
        self.max_delay = max_delay
        self.retry_count = 0
        self._reset_timer()
    
    def _reset_timer(self):
        self.last_request = time.time()
    
    def _get_delay(self):
        """Calculate exponential backoff with jitter"""
        delay = min(self.base_delay * (2 ** self.retry_count), self.max_delay)
        jitter = random.uniform(0, 0.1 * delay)  # 10% jitter
        return delay + jitter
    
    def _should_retry(self, exception):
        """Determine if exception warrants a retry"""
        retry_exceptions = (
            StaleElementReferenceException,
            TimeoutException,
            ElementClickInterceptedException,
            ConnectionError,
            ConnectionResetError
        )
        
        # Check for rate limit indicators
        if isinstance(exception, WebDriverException):
            error_msg = str(exception).lower()
            rate_limit_indicators = [
                'rate limit',
                'too many requests',
                '429',
                'try again later',
                'temporary hold',
                'please wait'
            ]
            if any(indicator in error_msg for indicator in rate_limit_indicators):
                self.base_delay *= 2  # Increase delay on rate limits
                return True
        
        return isinstance(exception, retry_exceptions)
    
    def execute_with_retry(self, func, *args, **kwargs):
        """Execute function with retry logic"""
        last_exception = None
        
        for attempt in range(self.max_retries):
            try:
                # Ensure minimum delay between requests
                elapsed = time.time() - self.last_request
                if elapsed < self.base_delay:
                    time.sleep(self.base_delay - elapsed)
                
                result = func(*args, **kwargs)
                self._reset_timer()
                return result
                
            except Exception as e:
                last_exception = e
                if not self._should_retry(e):
                    raise
                
                self.retry_count += 1
                delay = self._get_delay()
                print(f"⚠️ Attempt {attempt + 1}/{self.max_retries} failed. Retrying in {delay:.1f}s...")
                time.sleep(delay)
        
        raise last_exception

def with_retry(max_retries=3, base_delay=1, max_delay=10):
    """Decorator for retry logic"""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            handler = RetryHandler(max_retries, base_delay, max_delay)
            return handler.execute_with_retry(func, *args, **kwargs)
        return wrapper
    return decorator