

import os
import subprocess
import sys
import tempfile
import shutil
import atexit
from pathlib import Path
from selenium.webdriver.chrome.options import Options

def get_extensions_list():
    """Return a list of extension paths from the environment.

    Supports these forms in the EXTENSION_PATH or EXTENSIONS env var:
    - Single path to a .crx file
    - Single path to an unpacked extension folder
    - Multiple paths separated by os.pathsep (";" on Windows, ":" on Unix)
    - Comma separated list if only commas provided
    """
    val = os.environ.get("EXTENSION_PATH") or os.environ.get("EXTENSIONS")

    # If environment var provided, use that
    if val:
        parts = [p.strip() for p in val.split(os.pathsep) if p.strip()]
        if len(parts) == 1 and "," in parts[0]:
            parts = [p.strip() for p in parts[0].split(",") if p.strip()]
        return parts

    # No env var — look for bundled 'bundled_extensions' folder (for single-exe builds)
    bundled_paths = []
    # When running from PyInstaller, resources are in sys._MEIPASS
    candidates = []
    try:
        meipass = getattr(sys, '_MEIPASS', None)
        if meipass:
            candidates.append(os.path.join(meipass, 'bundled_extensions'))
    except Exception:
        meipass = None

    # Also check relative to project source (useful during development)
    src_based = os.path.join(os.path.dirname(__file__), 'bundled_extensions')
    candidates.append(src_based)

    for c in candidates:
        if c and os.path.isdir(c):
            # include all immediate children (folders or files)
            for entry in os.listdir(c):
                bundled_paths.append(os.path.join(c, entry))
            if bundled_paths:
                return bundled_paths

    return []


def apply_extensions(chrome_options: Options, silent=False):
    """Apply extensions found in EXTENSION_PATH/EXTENSIONS to the given Chrome Options.

    Behavior:
    - If path is a directory, use --load-extension for unpacked extension.
    - Only uses unpacked extensions (folders with manifest.json) to avoid unzip errors.
    - Automatically finds and loads bundled extensions without user interaction.
    
    Args:
        chrome_options: Selenium Chrome Options to configure
        silent: If True, suppress informational messages
    """
    paths = get_extensions_list()
    if not paths:
        if not silent:
            print("[chrome_utils] No bundled extensions found")
        return

    # If extensions are bundled inside the exe (MEIPASS) or project, copy them to a temp dir
    paths = _prepare_extension_paths(paths)

    if not paths:
        if not silent:
            print("[chrome_utils] No valid extensions to load")
        return

    applied = 0
    extension_args = []
    
    for p in paths:
        if not p:
            continue
        if not os.path.exists(p):
            print(f"[chrome_utils] Extension path does not exist: {p}")
            continue

        if os.path.isdir(p):
            # Verify manifest exists
            manifest_path = os.path.join(p, 'manifest.json')
            if not os.path.exists(manifest_path):
                print(f"[chrome_utils] Skipping {p} - no manifest.json")
                continue
            
            # Verify extension structure
            try:
                import json
                with open(manifest_path, 'r', encoding='utf-8') as f:
                    manifest = json.load(f)
                    ext_name = manifest.get('name', 'Unknown')
                    ext_version = manifest.get('version', 'Unknown')
                    
                if not silent:
                    print(f"[chrome_utils] Loading extension: {ext_name} v{ext_version}")
            except Exception as e:
                print(f"[chrome_utils] Invalid manifest in {p}: {e}")
                continue
            
            # Use --load-extension for unpacked extension (most reliable)
            extension_args.append(p)
            applied += 1
            
    # Apply all extensions in a single --load-extension argument (more reliable)
    if extension_args:
        extensions_str = ','.join(extension_args)
        chrome_options.add_argument(f"--load-extension={extensions_str}")
        if not silent:
            print(f"[chrome_utils] ✅ Loaded {applied} extension(s)")
    elif not silent:
        print("[chrome_utils] ⚠️ No valid extensions were applied")


def _prepare_extension_paths(paths):
    """Copy bundled extension folders/files to a temp directory and return new paths.

    This ensures Chrome can load unpacked extension folders or CRX files when running from
    a single-file executable where resources are unpacked in a read-only location.
    
    Each call creates a UNIQUE temp directory to avoid conflicts with parallel browser instances.
    """
    import random
    import time
    
    prepared = []
    # Create unique temp folder for each browser instance (avoid conflicts in parallel processing)
    unique_id = f"{os.getpid()}_{int(time.time() * 1000)}_{random.randint(1000, 9999)}"
    tmproot = Path(tempfile.gettempdir()) / f"yt_auto_ext_{unique_id}"
    tmproot.mkdir(parents=True, exist_ok=True)

    # register temp root for cleanup later
    try:
        _register_temp_path(str(tmproot))
    except Exception:
        pass

    for p in paths:
        try:
            if os.path.isdir(p):
                # Verify this is a valid extension folder
                manifest_path = os.path.join(p, 'manifest.json')
                if not os.path.exists(manifest_path):
                    print(f"[chrome_utils] Skipping {p} - no manifest.json found")
                    continue
                
                # copy directory to temp with unique path
                dest = tmproot / Path(p).name
                if dest.exists():
                    try:
                        shutil.rmtree(dest)
                    except Exception:
                        # If can't remove, create with different name
                        dest = tmproot / f"{Path(p).name}_{random.randint(1000, 9999)}"
                
                # Copy with proper permissions
                shutil.copytree(p, dest, dirs_exist_ok=True)
                
                # Verify copy was successful
                if os.path.exists(os.path.join(dest, 'manifest.json')):
                    prepared.append(str(dest))
                    print(f"[chrome_utils] Prepared extension: {dest}")
                else:
                    print(f"[chrome_utils] Failed to copy extension {p} properly")
                    
            elif os.path.isfile(p):
                # Skip CRX files - they often cause unzip errors
                # Convert to unpacked if it's a .crx
                if p.lower().endswith('.crx'):
                    print(f"[chrome_utils] Skipping CRX file (use unpacked extension instead): {p}")
                    continue
                    
                # copy other files to temp
                dest = tmproot / Path(p).name
                shutil.copy2(p, dest)
                prepared.append(str(dest))
        except Exception as e:
            print(f"[chrome_utils] Could not prepare bundled extension {p}: {e}")
    
    return prepared


# --- Temporary path tracking & cleanup ---
_TEMP_PATHS = set()


def _register_temp_path(p: str):
    """Register a path created by this module for later cleanup."""
    try:
        if not p:
            return
        # Only register paths under the system temp dir for safety
        tempdir = os.path.normpath(tempfile.gettempdir())
        pnorm = os.path.normpath(p)
        if pnorm.startswith(tempdir):
            _TEMP_PATHS.add(pnorm)
    except Exception:
        pass


def cleanup_temp_paths(retries: int = 3, wait_between: float = 1.0):
    """Attempt to remove temporary paths previously created for extensions/profiles.

    This is best-effort: directories that are still in use may fail to be removed.
    The function will retry removal a few times (default 3) with a short wait
    between attempts to allow Chrome to fully exit and release file handles.

    Args:
        retries: number of attempts to try removing registered temp paths.
        wait_between: seconds to wait between retries.
    """
    tempdir = os.path.normpath(tempfile.gettempdir())

    # Do up to `retries` attempts to remove temp paths. If at any pass we
    # successfully remove a path, it will be discarded from the registry.
    for attempt in range(1, max(1, int(retries)) + 1):
        if not _TEMP_PATHS:
            return

        to_remove = list(_TEMP_PATHS)
        any_removed = False

        for p in to_remove:
            pnorm = None
            try:
                pnorm = os.path.normpath(p)
                # Safety check: only remove inside temp dir
                if not pnorm.startswith(tempdir):
                    _TEMP_PATHS.discard(p)
                    continue

                if not os.path.exists(pnorm):
                    # Nothing to remove
                    _TEMP_PATHS.discard(p)
                    continue

                renamed = pnorm + f".to_delete_{os.getpid()}"
                try:
                    os.rename(pnorm, renamed)
                except Exception:
                    # Directory likely in use by Chrome or another process; skip for now
                    print(f"[chrome_utils] Skipping removal (in use): {pnorm} (attempt {attempt}/{retries})")
                    continue

                try:
                    shutil.rmtree(renamed)
                    print(f"[chrome_utils] Removed temp path: {pnorm}")
                    any_removed = True
                except Exception as e:
                    print(f"[chrome_utils] Could not remove temp path {pnorm} after rename: {e}")
                    # Attempt best-effort cleanup of the renamed folder
                    try:
                        if os.path.exists(renamed):
                            shutil.rmtree(renamed, ignore_errors=True)
                            any_removed = True
                    except Exception:
                        pass

            except Exception as e:
                print(f"[chrome_utils] Error during cleanup of {p}: {e}")
            finally:
                try:
                    # Remove from registry if it no longer exists
                    if pnorm is None or not os.path.exists(pnorm):
                        _TEMP_PATHS.discard(p)
                except Exception:
                    pass

        # If nothing was removed this pass, wait before trying again (unless it's the last attempt)
        if _TEMP_PATHS and attempt < retries:
            try:
                import time as _time
                _time.sleep(float(wait_between))
            except Exception:
                pass
        else:
            # Either nothing left to remove or attempts exhausted
            break


def cleanup_temp_paths_force():
    """Forcefully remove all registered temp paths (dangerous):

    This will attempt to delete every registered path without doing the in-use
    rename check. Use only if you are sure Chrome is not running with those
    profiles.
    """
    tempdir = os.path.normpath(tempfile.gettempdir())
    to_remove = list(_TEMP_PATHS)
    for p in to_remove:
        try:
            pnorm = os.path.normpath(p)
            if not pnorm.startswith(tempdir):
                continue
            if os.path.exists(pnorm):
                try:
                    shutil.rmtree(pnorm)
                    print(f"[chrome_utils] Force-removed temp path: {pnorm}")
                except Exception as e:
                    print(f"[chrome_utils] Could not force-remove temp path {pnorm}: {e}")
        finally:
            try:
                _TEMP_PATHS.discard(p)
            except Exception:
                pass


def get_registered_temp_paths():
    """Return a snapshot list of paths currently registered for cleanup."""
    return list(_TEMP_PATHS)


# Register cleanup at process exit
try:
    atexit.register(cleanup_temp_paths)
except Exception:
    pass


def apply_user_profile(chrome_options: Options):
    """Use a persistent Chrome user-data directory/profile if provided via env vars.

    Environment variables supported:
    - CHROME_USER_DATA_DIR : full path to a Chrome user data directory to reuse
    - CHROME_PROFILE       : profile directory/name within the user data dir (e.g., 'Default' or 'Profile 1')

    Behavior:
    - If CHROME_USER_DATA_DIR is set and exists, adds --user-data-dir and optional --profile-directory to options.
    - This allows you to manually install and configure extensions once by launching Chrome with the same user-data-dir,
      and subsequent Selenium sessions will reuse the same extensions and settings.
    """
    user_dir = os.environ.get("CHROME_USER_DATA_DIR")
    profile = os.environ.get("CHROME_PROFILE")
    if not user_dir:
        return

    if not os.path.exists(user_dir):
        print(f"[chrome_utils] CHROME_USER_DATA_DIR does not exist: {user_dir}")
        return

    # Read required extension id/url early so cloning can use it
    required_ext = os.environ.get("REQUIRED_EXTENSION_ID")
    required_url = os.environ.get("REQUIRED_EXTENSION_URL")

    # By default use the provided user data dir. However, callers may want to reuse the
    # extension settings but not the signed-in session (cookies). If so, set
    # env var EXTENSION_CLONE_MODE=extension-only and we'll clone only extension
    # related folders into a temporary profile and use that as the user-data-dir.
    clone_mode = os.environ.get('EXTENSION_CLONE_MODE') or os.environ.get('CLONE_EXTENSION_TO_TEMP')
    if clone_mode and clone_mode.lower() in ('1', 'yes', 'true', 'extension-only'):
        # Clone only extension data into a temp profile to avoid reusing login cookies
        if required_ext:
            temp_profile = _clone_extension_to_temp_profile(user_dir, required_ext)
        else:
            temp_profile = None
        if temp_profile:
            chrome_options.add_argument(f"--user-data-dir={temp_profile}")
            print(f"[chrome_utils] Using temp profile with cloned extension: {temp_profile}")
        else:
            chrome_options.add_argument(f"--user-data-dir={user_dir}")
            print(f"[chrome_utils] Could not clone extension; falling back to original user data dir: {user_dir}")
    else:
        # Add user-data-dir argument
        chrome_options.add_argument(f"--user-data-dir={user_dir}")
        print(f"[chrome_utils] Using Chrome user data dir: {user_dir}")

    if profile:
        # profile should be the folder name inside the user data dir (e.g., 'Default' or 'Profile 1')
        chrome_options.add_argument(f"--profile-directory={profile}")
        print(f"[chrome_utils] Using Chrome profile directory: {profile}")

    # If user requested a specific extension ID to be present, verify it's installed
    required_ext = os.environ.get("REQUIRED_EXTENSION_ID")
    required_url = os.environ.get("REQUIRED_EXTENSION_URL")
    if required_ext:
        if not _is_extension_installed_in_profile(user_dir, required_ext):
            print(f"[chrome_utils] Required extension {required_ext} not found in profile.\n"
                  "Opening Chrome for manual installation. Follow the browser UI to install the extension, then close Chrome and press Enter to continue.")
            _launch_chrome_for_manual_install(user_dir, profile, required_url)
            input("After installing the extension and closing Chrome, press Enter to continue...")
            # Re-check
            if not _is_extension_installed_in_profile(user_dir, required_ext):
                print(f"[chrome_utils] Still could not find extension {required_ext} in profile after manual install. Please verify and try again.")
            else:
                # Write marker so future runs know the extension is installed for this profile
                try:
                    _write_required_extension_marker(user_dir, required_ext, required_url)
                except Exception:
                    pass
        else:
            # extension already present - ensure marker exists
            try:
                _write_required_extension_marker(user_dir, required_ext, required_url)
            except Exception:
                pass


def _is_extension_installed_in_profile(user_dir: str, extension_id: str) -> bool:
    """Check whether the extension ID exists under the profile's Extensions folder."""
    try:
        # First check the Extensions directory
        ext_path = os.path.join(user_dir, 'Extensions', extension_id)
        if os.path.isdir(ext_path):
            for entry in os.listdir(ext_path):
                version_dir = os.path.join(ext_path, entry)
                if os.path.isdir(version_dir) and os.listdir(version_dir):
                    print(f"[chrome_utils] Found extension in Extensions directory: {ext_path}")
                    return True
        
        # Also check Default/Extensions as an alternative location
        default_ext_path = os.path.join(user_dir, 'Default', 'Extensions', extension_id)
        if os.path.isdir(default_ext_path):
            for entry in os.listdir(default_ext_path):
                version_dir = os.path.join(default_ext_path, entry)
                if os.path.isdir(version_dir) and os.listdir(version_dir):
                    print(f"[chrome_utils] Found extension in Default/Extensions directory: {default_ext_path}")
                    return True
                    
        return False
    except Exception as e:
        print(f"[chrome_utils] Error checking extension installation: {e}")
        return False


def _find_chrome_executable() -> str:
    """Try to locate chrome.exe on Windows in common installation paths."""
    candidates = []
    pf = os.environ.get('PROGRAMFILES')
    pfx86 = os.environ.get('PROGRAMFILES(X86)')
    local = os.environ.get('LOCALAPPDATA')
    if pf:
        candidates.append(os.path.join(pf, 'Google', 'Chrome', 'Application', 'chrome.exe'))
    if pfx86:
        candidates.append(os.path.join(pfx86, 'Google', 'Chrome', 'Application', 'chrome.exe'))
    if local:
        candidates.append(os.path.join(local, 'Google', 'Chrome', 'Application', 'chrome.exe'))
    # Also try common PATH name
    candidates.append('chrome')

    for c in candidates:
        try:
            if c == 'chrome':
                # Assume in PATH
                return 'chrome'
            if os.path.exists(c):
                return c
        except Exception:
            continue
    return None


def _launch_chrome_for_manual_install(user_dir: str, profile: str = None, url: str = None):
    """Launch Chrome using the provided user-data-dir (and profile) so the user can install the extension manually.

    This function attempts to find chrome.exe; if not found it falls back to the system 'start' command.
    """
    chrome_exe = _find_chrome_executable()
    args = []
    if chrome_exe and chrome_exe.lower() != 'chrome':
        args = [chrome_exe, f'--user-data-dir={user_dir}', '--new-window']
        if profile:
            args.append(f'--profile-directory={profile}')
        if url:
            args.append(url)
        try:
            subprocess.Popen(args)
            return
        except Exception as e:
            print(f"[chrome_utils] Failed to launch Chrome directly: {e}")

    # Fallback: use start (works on Windows; will use default registered chrome)
    start_cmd = f'start chrome --user-data-dir="{user_dir}"'
    if profile:
        start_cmd += f' --profile-directory="{profile}"'
    if url:
        start_cmd += f' "{url}"'
    try:
        # Use shell True to allow the start command
        subprocess.Popen(start_cmd, shell=True)
    except Exception as e:
        print(f"[chrome_utils] Failed to launch Chrome via start: {e}")


def _write_required_extension_marker(user_dir: str, extension_id: str, url: str = None):
    """Write a small json marker file into the user profile to remember the installed extension.

    This prevents future runs from prompting the user for the extension id again.
    """
    try:
        import json
        marker = {
            'extension_id': extension_id,
            'extension_url': url
        }
        marker_path = os.path.join(user_dir, 'required_extension.json')
        with open(marker_path, 'w', encoding='utf-8') as f:
            json.dump(marker, f)
        # Attempt to make file hidden on Windows (best effort)
        try:
            if sys.platform.startswith('win'):
                import ctypes
                FILE_ATTRIBUTE_HIDDEN = 0x02
                ctypes.windll.kernel32.SetFileAttributesW(marker_path, FILE_ATTRIBUTE_HIDDEN)
        except Exception:
            pass
        return True
    except Exception:
        return False


def _read_required_extension_marker(user_dir: str):
    """Read required_extension.json marker from a user profile folder.
    Returns (extension_id, extension_url) or (None, None) if not present.
    """
    try:
        import json
        marker_path = os.path.join(user_dir, 'required_extension.json')
        if not os.path.exists(marker_path):
            return (None, None)
        with open(marker_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return (data.get('extension_id'), data.get('extension_url'))
    except Exception:
        return (None, None)


def _clone_extension_to_temp_profile(user_dir: str, extension_id: str):
    """Clone only extension folders from a configured user profile into a fresh temp profile.

    Copies these folders if present:
    - Extensions/<extension_id>
    - Local Extension Settings/<extension_id>
    - Extension State/<extension_id>
    - IndexedDB/ or other extension storage folders if present (best-effort)

    Returns path to the new temp profile directory, or None on failure.
    """
    try:
        if not extension_id:
            return None
        src = Path(user_dir)
        temp_dir = Path(tempfile.mkdtemp(prefix='yt_ext_profile_'))
        # Create required profile skeleton
        (temp_dir / 'Default').mkdir(parents=True, exist_ok=True)

        candidates = [
            ('Extensions', extension_id),
            ('Local Extension Settings', extension_id),
            ('Extension State', extension_id),
        ]
        for folder, ext in candidates:
            src_folder = src / folder / ext
            if src_folder.exists():
                dest_folder = temp_dir / folder / ext
                dest_folder.parent.mkdir(parents=True, exist_ok=True)
                shutil.copytree(src_folder, dest_folder)

        # Also try copying extension-specific IndexedDB or storage (best effort)
        idb_src = src / 'IndexedDB'
        if idb_src.exists():
            for entry in idb_src.iterdir():
                if extension_id in entry.name:
                    dest = temp_dir / 'IndexedDB' / entry.name
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    try:
                        if entry.is_dir():
                            shutil.copytree(entry, dest)
                    except Exception:
                        pass

        # register for cleanup
        try:
            _register_temp_path(str(temp_dir))
        except Exception:
            pass
        return str(temp_dir)
    except Exception as e:
        print(f"[chrome_utils] Failed to clone extension to temp profile: {e}")
        return None
