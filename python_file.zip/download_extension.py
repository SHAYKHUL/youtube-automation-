"""
Download and prepare Chrome extensions for bundling
"""
import os
import requests
import zipfile
import io

def download_rektcaptcha():
    """Download RektCaptcha extension"""
    print("Downloading RektCaptcha extension...")
    
    # RektCaptcha GitHub release
    # Note: You may need to update this URL to the latest release
    url = "https://github.com/Wikidepia/RektCaptcha/releases/latest/download/rektcaptcha-chrome.zip"
    
    try:
        response = requests.get(url, timeout=30)
        response.raise_for_status()
        
        # Create extension folder
        ext_folder = "bundled_extensions/rektcaptcha"
        os.makedirs(ext_folder, exist_ok=True)
        
        # Extract zip
        with zipfile.ZipFile(io.BytesIO(response.content)) as z:
            z.extractall(ext_folder)
        
        print(f"✅ RektCaptcha downloaded and extracted to: {ext_folder}")
        return True
        
    except requests.exceptions.RequestException as e:
        print(f"❌ Failed to download: {e}")
        print("\nManual download instructions:")
        print("1. Visit: https://github.com/Wikidepia/RektCaptcha/releases")
        print("2. Download: rektcaptcha-chrome.zip")
        print("3. Extract to: bundled_extensions/rektcaptcha/")
        return False

def create_readme():
    """Create README for extensions folder"""
    readme = """# Bundled Chrome Extensions

This folder contains Chrome extensions that will be automatically loaded when
the YTReach application starts.

## Current Extensions:

### RektCaptcha
- **Purpose:** Automatically solves reCAPTCHA challenges
- **Source:** https://github.com/Wikidepia/RektCaptcha
- **Location:** bundled_extensions/rektcaptcha/

## Adding More Extensions:

1. Create a new folder inside bundled_extensions/
2. Extract the extension files into that folder
3. The extension must have a manifest.json file
4. Rebuild the application with: python build_exe.py

## How It Works:

When running as an EXE, the application:
1. Detects it's running from PyInstaller bundle
2. Looks for bundled_extensions/ in the bundle
3. Automatically loads all extensions found
4. No user action required!

## For Developers:

The chrome_utils.py module handles extension loading automatically:
- get_extensions_list() - Returns list of extension folders
- apply_extensions() - Loads extensions into Chrome options
"""
    
    with open("bundled_extensions/README.md", "w", encoding="utf-8") as f:
        f.write(readme)
    
    print("✅ Created bundled_extensions/README.md")

if __name__ == "__main__":
    print("=" * 70)
    print("CHROME EXTENSION DOWNLOADER")
    print("=" * 70)
    print()
    
    # Download RektCaptcha
    success = download_rektcaptcha()
    
    # Create README
    create_readme()
    
    print()
    print("=" * 70)
    if success:
        print("✅ Extensions ready for bundling!")
        print("\nNext step: Run 'python build_exe.py' to rebuild with extensions")
    else:
        print("⚠️  Manual download required")
        print("\nAfter manual download, run 'python build_exe.py'")
    print("=" * 70)
