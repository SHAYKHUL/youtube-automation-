"""
Download and bundle RektCaptcha extension for distribution
This creates a pre-configured extension that users don't need to install
"""

import os
import sys
import shutil
import zipfile
import tempfile
import subprocess
from pathlib import Path

def download_extension_from_chrome_store():
    """Download extension using chrome-extension-downloader"""
    extension_id = 'bbdhfoclddncoaomddgkaaphcnddbpdh'
    
    print("\n" + "="*70)
    print("DOWNLOADING REKTCAPTCHA EXTENSION")
    print("="*70)
    print(f"\nExtension ID: {extension_id}")
    
    # Create temp directory
    temp_dir = tempfile.mkdtemp()
    
    try:
        # Try using crx3 module to download
        print("\n📥 Attempting to download extension...")
        
        try:
            import requests
            
            # Chrome Web Store CRX download URL
            crx_url = f"https://clients2.google.com/service/update2/crx?response=redirect&acceptformat=crx2,crx3&prodversion=100.0&x=id%3D{extension_id}%26installsource%3Dondemand%26uc"
            
            print(f"   Downloading from Chrome Web Store...")
            response = requests.get(crx_url, allow_redirects=True, timeout=30)
            
            if response.status_code == 200 and len(response.content) > 1000:
                crx_path = os.path.join(temp_dir, f"{extension_id}.crx")
                with open(crx_path, 'wb') as f:
                    f.write(response.content)
                
                print(f"   ✅ Downloaded: {len(response.content)} bytes")
                return crx_path
            else:
                print(f"   ⚠️ Download failed: Status {response.status_code}")
                
        except Exception as e:
            print(f"   ⚠️ Automatic download failed: {e}")
        
        return None
        
    except Exception as e:
        print(f"❌ Error: {e}")
        return None


def extract_crx_to_folder(crx_path, output_folder):
    """Extract CRX file to a folder"""
    print(f"\n📦 Extracting extension...")
    
    try:
        # CRX files are ZIP files with a header
        # We need to skip the CRX header and extract the ZIP content
        
        with open(crx_path, 'rb') as f:
            # Read CRX header
            header = f.read(4)
            
            if header[:3] == b'Cr2' or header[:3] == b'Cr3':
                # Skip CRX header
                if header[3:4] == b'4':  # CRX3
                    header_size = int.from_bytes(f.read(4), 'little')
                    f.seek(12 + header_size)
                else:  # CRX2
                    version = int.from_bytes(f.read(4), 'little')
                    key_length = int.from_bytes(f.read(4), 'little')
                    sig_length = int.from_bytes(f.read(4), 'little')
                    f.seek(16 + key_length + sig_length)
                
                # Read ZIP content
                zip_content = f.read()
                
                # Extract ZIP
                temp_zip = os.path.join(tempfile.gettempdir(), 'temp_ext.zip')
                with open(temp_zip, 'wb') as zf:
                    zf.write(zip_content)
                
                # Extract to output folder
                os.makedirs(output_folder, exist_ok=True)
                with zipfile.ZipFile(temp_zip, 'r') as zip_ref:
                    zip_ref.extractall(output_folder)
                
                os.remove(temp_zip)
                print(f"   ✅ Extracted to: {output_folder}")
                return True
            else:
                print("   ⚠️ Not a valid CRX file")
                return False
                
    except Exception as e:
        print(f"   ❌ Extraction failed: {e}")
        return False


def copy_from_installed_extension():
    """Copy extension from Chrome profile if already installed"""
    print("\n📋 Checking for installed extension...")
    
    extension_id = 'bbdhfoclddncoaomddgkaaphcnddbpdh'
    
    # Check common Chrome profile locations
    possible_locations = [
        os.path.join(os.getcwd(), 'chrome_profile', 'Default', 'Extensions', extension_id),
        os.path.join(os.getcwd(), 'chrome_profile', 'Extensions', extension_id),
    ]
    
    for loc in possible_locations:
        if os.path.exists(loc):
            # Find the version folder
            try:
                version_dirs = [d for d in os.listdir(loc) if os.path.isdir(os.path.join(loc, d))]
                if version_dirs:
                    source_dir = os.path.join(loc, version_dirs[0])
                    print(f"   ✅ Found installed extension: {source_dir}")
                    return source_dir
            except Exception as e:
                print(f"   ⚠️ Error checking {loc}: {e}")
    
    return None


def create_bundled_extension():
    """Create bundled extension folder for distribution"""
    print("\n" + "="*70)
    print("CREATING BUNDLED EXTENSION")
    print("="*70)
    
    extension_id = 'bbdhfoclddncoaomddgkaaphcnddbpdh'
    output_folder = 'bundled_extensions/rektcaptcha'
    
    # Method 1: Copy from installed extension
    source_dir = copy_from_installed_extension()
    
    if source_dir:
        print("\n📁 Copying from installed extension...")
        try:
            if os.path.exists(output_folder):
                shutil.rmtree(output_folder)
            shutil.copytree(source_dir, output_folder)
            print(f"   ✅ Extension copied to: {output_folder}")
            return True
        except Exception as e:
            print(f"   ❌ Copy failed: {e}")
    
    # Method 2: Download from Chrome Web Store
    print("\n📥 Downloading from Chrome Web Store...")
    crx_path = download_extension_from_chrome_store()
    
    if crx_path:
        success = extract_crx_to_folder(crx_path, output_folder)
        if success:
            return True
    
    # Method 3: Manual instructions
    print("\n" + "="*70)
    print("⚠️  MANUAL DOWNLOAD REQUIRED")
    print("="*70)
    print("\nAutomatic download failed. Please follow these steps:")
    print("\n1. Install the extension in Chrome first:")
    print("   Run: setup_captcha_solver.bat")
    print("\n2. Then run this script again to copy the installed extension")
    print("\nOR download manually:")
    print("1. Visit: https://github.com/Wikidepia/RektCaptcha/releases")
    print("2. Download: rektcaptcha-chrome.zip")
    print("3. Extract to: bundled_extensions/rektcaptcha/")
    print("4. Make sure manifest.json is in the folder")
    
    return False


def verify_bundled_extension():
    """Verify the bundled extension is valid"""
    print("\n🔍 Verifying bundled extension...")
    
    manifest_path = 'bundled_extensions/rektcaptcha/manifest.json'
    
    if not os.path.exists(manifest_path):
        print("   ❌ manifest.json not found")
        return False
    
    try:
        import json
        with open(manifest_path, 'r', encoding='utf-8') as f:
            manifest = json.load(f)
        
        name = manifest.get('name', 'Unknown')
        version = manifest.get('version', 'Unknown')
        
        print(f"   ✅ Extension: {name}")
        print(f"   ✅ Version: {version}")
        print(f"   ✅ Manifest valid")
        
        # Count files
        file_count = sum(1 for root, dirs, files in os.walk('bundled_extensions/rektcaptcha') for f in files)
        print(f"   ✅ Files: {file_count}")
        
        return True
        
    except Exception as e:
        print(f"   ❌ Validation failed: {e}")
        return False


def create_readme():
    """Create README for bundled extensions"""
    readme_content = """# Bundled Chrome Extension - RektCaptcha

## What is this?

This folder contains a pre-configured Chrome extension that automatically solves CAPTCHA challenges.

**Users don't need to do anything!** The extension is automatically loaded when the application starts.

## Extension Details

- **Name**: RektCaptcha
- **Purpose**: Automatic reCAPTCHA solving
- **ID**: bbdhfoclddncoaomddgkaaphcnddbpdh
- **Source**: https://github.com/Wikidepia/RektCaptcha

## How It Works

1. Application starts
2. Extension is automatically extracted from bundle
3. Chrome loads with extension pre-installed
4. CAPTCHA solving works automatically

## No User Action Required!

✅ No manual installation
✅ No Web Store visits
✅ No configuration
✅ Works offline

## For Developers

To update the extension:
1. Run: `python download_and_bundle_extension.py`
2. Rebuild: `python build_exe.py`

The extension will be bundled into the EXE automatically.
"""
    
    readme_path = 'bundled_extensions/README.md'
    os.makedirs('bundled_extensions', exist_ok=True)
    
    with open(readme_path, 'w', encoding='utf-8') as f:
        f.write(readme_content)
    
    print(f"\n✅ Created: {readme_path}")


def main():
    print("\n" + "="*70)
    print("EXTENSION BUNDLING TOOL")
    print("="*70)
    print("\nThis will bundle RektCaptcha extension for distribution.")
    print("Users will NOT need to install or configure anything!")
    print()
    
    # Create bundled extension
    success = create_bundled_extension()
    
    if success:
        # Verify it
        if verify_bundled_extension():
            # Create README
            create_readme()
            
            print("\n" + "="*70)
            print("✅ SUCCESS!")
            print("="*70)
            print("\n✅ Extension bundled successfully!")
            print("\n📦 Next steps:")
            print("   1. Run: python build_exe.py")
            print("   2. Extension will be included in the EXE")
            print("   3. Users get automatic CAPTCHA solving!")
            print("\n📁 Bundled location: bundled_extensions/rektcaptcha/")
            print()
            return 0
        else:
            print("\n❌ Extension validation failed")
            return 1
    else:
        print("\n❌ Extension bundling failed")
        print("\nPlease follow the manual instructions above.")
        return 1


if __name__ == "__main__":
    sys.exit(main())
