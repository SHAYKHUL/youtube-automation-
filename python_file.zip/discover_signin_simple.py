"""
Simple Authenticated Email Discovery
Reads channels from signin_to_see_email.csv and discovers emails after manual login
"""

import csv
import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.chrome.options import Options
import re


def extract_emails_from_text(text):
    """Extract emails from text"""
    if not text:
        return []
    email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
    emails = re.findall(email_pattern, text, re.IGNORECASE)
    return list(set(emails))  # Remove duplicates


def get_channel_emails(driver, channel_url, wait_time=10):
    """Get emails from a channel after authentication"""
    try:
        driver.get(channel_url)
        time.sleep(3)
        
        all_emails = []
        
        # Click on About tab
        try:
            about_tab = WebDriverWait(driver, wait_time).until(
                EC.element_to_be_clickable((By.XPATH, "//yt-tab-shape[@tab-title='About' or @tab-title='ABOUT']"))
            )
            about_tab.click()
            time.sleep(2)
        except:
            print(f"Could not find About tab for {channel_url}")
            return []
        
        # Get page source and extract emails
        page_source = driver.page_source
        emails = extract_emails_from_text(page_source)
        all_emails.extend(emails)
        
        # Try to click "View email address" if it exists
        try:
            email_button = driver.find_element(By.XPATH, "//button[contains(@aria-label, 'email')]")
            email_button.click()
            time.sleep(1)
            
            # Get updated page source
            page_source = driver.page_source
            new_emails = extract_emails_from_text(page_source)
            all_emails.extend(new_emails)
        except:
            pass  # Button might not exist
        
        # Remove duplicates
        all_emails = list(set(all_emails))
        
        return all_emails
        
    except Exception as e:
        print(f"Error processing {channel_url}: {e}")
        return []


def run_discover_signin(input_csv='signin_to_see_email.csv', 
                        progress_callback=None, 
                        result_callback=None,
                        error_callback=None):
    """
    Discover emails from channels requiring sign-in
    
    Args:
        input_csv: Path to signin_to_see_email.csv
        progress_callback: callable(str) - receives status messages
        result_callback: callable(event_type, channel, payload) - receives result events
        error_callback: callable(exception, context)
    """
    
    # Read channels from CSV
    try:
        with open(input_csv, 'r', encoding='utf-8') as f:
            reader = csv.reader(f)
            header = next(reader, None)
            channels = [row[0] for row in reader if row and row[0].startswith('http')]
    except FileNotFoundError:
        if callable(error_callback):
            error_callback(FileNotFoundError(f"{input_csv} not found"), {'file': input_csv})
        return
    
    if not channels:
        print(f"No channels found in {input_csv}")
        return
    
    # Setup Chrome
    chrome_options = Options()
    chrome_options.add_argument("--disable-blink-features=AutomationControlled")
    chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
    chrome_options.add_experimental_option('useAutomationExtension', False)
    chrome_options.add_argument("--start-maximized")
    
    driver = None
    
    try:
        driver = webdriver.Chrome(options=chrome_options)
        driver.maximize_window()
        
        # Navigate to YouTube for manual login
        if callable(progress_callback):
            progress_callback("Opening YouTube... Please login if needed")
        
        driver.get("https://www.youtube.com")
        time.sleep(3)
        
        # Give user time to login
        if callable(progress_callback):
            progress_callback("⏳ Please login to YouTube in the browser window...")
        
        # Wait for user to login (check if signed in)
        for i in range(60):  # Wait up to 60 seconds
            try:
                # Check if user icon exists (sign of being logged in)
                driver.find_element(By.ID, "avatar-btn")
                if callable(progress_callback):
                    progress_callback("✅ Login detected! Starting discovery...")
                break
            except:
                time.sleep(1)
                if i % 5 == 0 and callable(progress_callback):
                    progress_callback(f"⏳ Waiting for login... ({60-i}s remaining)")
        
        # Process each channel
        total = len(channels)
        discovered_count = 0
        failed_count = 0
        
        for idx, channel_url in enumerate(channels, 1):
            if callable(progress_callback):
                progress_callback(f"Processing {idx}/{total}: {channel_url[:60]}...")
            
            emails = get_channel_emails(driver, channel_url)
            
            if emails:
                discovered_count += 1
                if callable(result_callback):
                    result_callback('email', channel_url, {
                        'emails': emails,
                        'total_discovered': discovered_count,
                        'total_processed': idx
                    })
                print(f"✅ [{idx}/{total}] Found emails: {emails}")
            else:
                failed_count += 1
                if callable(result_callback):
                    result_callback('none', channel_url, {
                        'total_failed': failed_count,
                        'total_processed': idx
                    })
                print(f"❌ [{idx}/{total}] No email found")
            
            time.sleep(2)  # Delay between channels
        
        if callable(progress_callback):
            progress_callback(f"✅ Complete! Discovered {discovered_count}/{total} emails")
        
    except Exception as e:
        print(f"Error: {e}")
        if callable(error_callback):
            error_callback(e, {'stage': 'discovery'})
    finally:
        if driver:
            try:
                # Don't close immediately - give user time to see results
                if callable(progress_callback):
                    progress_callback("Discovery complete! Browser will close in 10 seconds...")
                time.sleep(10)
                driver.quit()
            except:
                pass


if __name__ == "__main__":
    # Test the function
    def progress_cb(msg):
        print(f"[PROGRESS] {msg}")
    
    def result_cb(event_type, channel, payload):
        if event_type == 'email':
            print(f"[EMAIL FOUND] {channel}: {payload['emails']}")
        else:
            print(f"[NO EMAIL] {channel}")
    
    def error_cb(exception, context):
        print(f"[ERROR] {exception} - {context}")
    
    run_discover_signin(
        progress_callback=progress_cb,
        result_callback=result_cb,
        error_callback=error_cb
    )
