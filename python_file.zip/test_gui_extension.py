"""
Test if GUI's AuthenticatedEmailDiscovery uses bundled CAPTCHA solver extension
"""

import os
import sys

def test_extension_loading():
    """Test that GUI class properly loads bundled extension"""
    
    print("=" * 70)
    print("TESTING GUI EXTENSION LOADING")
    print("=" * 70)
    
    # Import the GUI module
    try:
        from youtube_automation_gui import AuthenticatedEmailDiscovery
        print("✅ Successfully imported AuthenticatedEmailDiscovery from GUI")
    except Exception as e:
        print(f"❌ Failed to import: {e}")
        return False
    
    # Check if extension_manager is imported in GUI
    try:
        from extension_manager import ExtensionManager
        print("✅ ExtensionManager available")
    except Exception as e:
        print(f"❌ ExtensionManager not available: {e}")
        return False
    
    # Check for bundled extension
    print("\n🔍 Checking for bundled extension...")
    bundled_ext_path = os.path.join(os.getcwd(), 'bundled_extensions', 'rektcaptcha')
    
    if os.path.exists(bundled_ext_path):
        manifest_path = os.path.join(bundled_ext_path, 'manifest.json')
        if os.path.exists(manifest_path):
            print(f"✅ Bundled extension found: {bundled_ext_path}")
            import json
            with open(manifest_path, 'r') as f:
                manifest = json.load(f)
                print(f"   📦 Extension: {manifest.get('name', 'Unknown')}")
                print(f"   📦 Version: {manifest.get('version', 'Unknown')}")
        else:
            print(f"⚠️ Extension folder exists but manifest.json missing")
            return False
    else:
        print(f"❌ Bundled extension not found at: {bundled_ext_path}")
        return False
    
    # Test ExtensionManager can find bundled extension
    print("\n🔍 Testing ExtensionManager...")
    try:
        ext_manager = ExtensionManager(profile_dir=os.path.join(os.getcwd(), 'chrome_profile'))
        if ext_manager._check_bundled_extension():
            print("✅ ExtensionManager can find bundled extension")
        else:
            print("❌ ExtensionManager cannot find bundled extension")
            return False
    except Exception as e:
        print(f"❌ ExtensionManager error: {e}")
        return False
    
    print("\n" + "=" * 70)
    print("✅ ALL CHECKS PASSED - GUI should use bundled CAPTCHA solver")
    print("=" * 70)
    print("\n📝 When you run authenticated email discovery in the GUI:")
    print("   1. Click 'Discover Authenticated Emails' button")
    print("   2. Look for these messages in the output:")
    print("      - '🔧 [GUI] Checking for bundled CAPTCHA solver...'")
    print("      - '✅ [GUI] Bundled CAPTCHA solver found - configuring Chrome...'")
    print("      - '✅ [GUI] Browser ready with CAPTCHA solver'")
    print("\n   3. Chrome should open with the extension loaded (check extensions icon)")
    
    return True

if __name__ == "__main__":
    success = test_extension_loading()
    sys.exit(0 if success else 1)
