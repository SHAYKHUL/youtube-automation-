from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from extension_installer import install_extension

def main():
    # Set up Chrome options
    chrome_options = Options()
    chrome_options.add_experimental_option('detach', True)
    chrome_options.add_experimental_option('excludeSwitches', ['enable-logging'])
    chrome_options.add_argument('--no-sandbox')
    chrome_options.add_argument('--disable-dev-shm-usage')
    
    # Initialize the Chrome driver
    service = Service()
    driver = webdriver.Chrome(service=service, options=chrome_options)
    
    # Extension details
    extension_id = "bbdhfoclddncoaomddgkaaphcnddbpdh"
    extension_url = "https://chromewebstore.google.com/detail/rektcaptcha-recaptcha-sol/bbdhfoclddncoaomddgkaaphcnddbpdh"
    
    try:
        # Install the extension
        success = install_extension(driver, extension_id, extension_url)
        if success:
            print("\nExtension installation process completed successfully!")
        else:
            print("\nExtension installation was not successful.")
    except Exception as e:
        print(f"\nAn error occurred: {e}")
    finally:
        # Keep the browser open
        input("\nPress Enter to close the browser...")
        driver.quit()

if __name__ == "__main__":
    main()