"""
Build script to create standalone EXE for YouTube Automation Suite
Run this script to build the executable: python build_exe.py
"""

import os
import sys
import subprocess
import shutil
from pathlib import Path

def check_pyinstaller():
    """Check if PyInstaller is installed"""
    try:
        import PyInstaller
        print("✅ PyInstaller is installed")
        return True
    except ImportError:
        print("❌ PyInstaller not found")
        print("Installing PyInstaller...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "pyinstaller"])
        print("✅ PyInstaller installed successfully")
        return True

def clean_build_folders():
    """Clean previous build folders"""
    print("\n🧹 Cleaning previous build folders...")
    folders_to_clean = ['build', 'dist', '__pycache__']
    
    for folder in folders_to_clean:
        if os.path.exists(folder):
            shutil.rmtree(folder)
            print(f"   Removed: {folder}/")
    
    # Clean spec file
    if os.path.exists('youtube_automation.spec'):
        os.remove('youtube_automation.spec')
        print("   Removed: youtube_automation.spec")
    
    print("✅ Cleanup complete\n")

def create_icon():
    """Create a simple icon file if it doesn't exist"""
    print("📝 Checking for icon file...")
    
    # Check if icon exists
    if os.path.exists('icon.ico'):
        print("✅ Icon file found: icon.ico\n")
        return 'icon.ico'
    
    print("⚠️  No icon file found. Executable will use default icon.")
    print("   To add custom icon: Place 'icon.ico' file in this folder\n")
    return None

def build_exe():
    """Build the standalone EXE"""
    print("=" * 70)
    print("BUILDING YOUTUBE AUTOMATION SUITE - STANDALONE EXE")
    print("=" * 70)
    print()
    
    # Check PyInstaller
    if not check_pyinstaller():
        print("❌ Failed to install PyInstaller")
        return False
    
    # Clean previous builds
    clean_build_folders()
    
    # Check icon
    icon_path = create_icon()
    
    print("🔨 Building executable...")
    print("   This may take 5-10 minutes depending on your system...")
    print()
    
    # Build command
    cmd = [
        'pyinstaller',
        '--onefile',  # Single file executable
        '--windowed',  # No console window (GUI app)
        '--name=YouTube_Automation_Suite',
        '--clean',
        '--noconfirm',
    ]
    
    # Add icon if exists
    if icon_path:
        cmd.extend(['--icon', icon_path])
    
    # Add hidden imports for modules that might not be auto-detected
    hidden_imports = [
        'email_finder',
        'selenium',
        'selenium.webdriver',
        'selenium.webdriver.common.by',
        'selenium.webdriver.support',
        'selenium.webdriver.support.ui',
        'selenium.webdriver.support.expected_conditions',
        'selenium.webdriver.chrome.service',
        'selenium.webdriver.chrome.options',
        'tkinter',
        'tkinter.ttk',
        'tkinter.scrolledtext',
        'tkinter.filedialog',
        'tkinter.messagebox',
        'csv',
        'threading',
        'queue',
        'sqlite3',
        'openpyxl',
        'pandas',
        're',
        'json',
        'datetime',
        'pathlib',
        'urllib',
        'urllib.parse',
        'time',
        'random',
        'os',
        'sys',
        'subprocess',
    ]
    
    for imp in hidden_imports:
        cmd.extend(['--hidden-import', imp])
    
    # Add data files (CSV examples, etc.)
    data_files = [
        ('requirements.txt', '.'),
        ('gmail_accounts.csv.example', '.'),
    ]
    
    for src, dst in data_files:
        if os.path.exists(src):
            cmd.extend(['--add-data', f'{src}{os.pathsep}{dst}'])
    
    # Main script
    cmd.append('youtube_automation_guipro.py')
    
    print(f"📋 Build command: {' '.join(cmd)}\n")
    
    try:
        # Run PyInstaller with real-time output
        result = subprocess.run(cmd, check=True)
        
        print("\n✅ Build completed successfully!\n")
        
        # Check if EXE exists
        exe_path = os.path.join('dist', 'YouTube_Automation_Suite.exe')
        if os.path.exists(exe_path):
            size_mb = os.path.getsize(exe_path) / (1024 * 1024)
            print("=" * 70)
            print("🎉 STANDALONE EXE CREATED!")
            print("=" * 70)
            print(f"\n📦 Location: {os.path.abspath(exe_path)}")
            print(f"📊 Size: {size_mb:.1f} MB")
            print("\n📝 DISTRIBUTION INSTRUCTIONS:")
            print("   1. Copy 'YouTube_Automation_Suite.exe' to any Windows computer")
            print("   2. Copy 'gmail_accounts.csv.example' (rename to gmail_accounts.csv)")
            print("   3. Install Chrome browser on target computer")
            print("   4. Download ChromeDriver and add to PATH")
            print("   5. Double-click the EXE to launch!")
            print("\n⚠️  IMPORTANT:")
            print("   - ChromeDriver must be installed separately")
            print("   - Chrome browser must be installed")
            print("   - Internet connection required")
            print()
            
            return True
        else:
            print("❌ EXE file not found in dist/ folder")
            return False
            
    except subprocess.CalledProcessError as e:
        print(f"❌ Build failed with error:")
        print(e.stderr)
        return False
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        return False

def create_installer_package():
    """Create a complete distribution package"""
    print("\n📦 Creating distribution package...")
    
    dist_folder = 'YouTube_Automation_Suite_Package'
    
    if os.path.exists(dist_folder):
        shutil.rmtree(dist_folder)
    
    os.makedirs(dist_folder)
    
    # Copy EXE
    exe_src = os.path.join('dist', 'YouTube_Automation_Suite.exe')
    exe_dst = os.path.join(dist_folder, 'YouTube_Automation_Suite.exe')
    
    if os.path.exists(exe_src):
        shutil.copy2(exe_src, exe_dst)
        print(f"   ✅ Copied: YouTube_Automation_Suite.exe")
    
    # Copy example files
    files_to_copy = [
        'gmail_accounts.csv.example',
        'requirements.txt',
        'CHROME_WINDOWS_FIX.md',
    ]
    
    for file in files_to_copy:
        if os.path.exists(file):
            shutil.copy2(file, os.path.join(dist_folder, file))
            print(f"   ✅ Copied: {file}")
    
    # Copy Playwright browser binaries if present
    import glob
    # Try both common Playwright cache locations
    pw_cache_dirs = [
        os.path.expandvars(r'%USERPROFILE%/.cache/ms-playwright'),
        os.path.expandvars(r'%LOCALAPPDATA%/ms-playwright'),
    ]
    browser_dst = os.path.join(dist_folder, 'ms-playwright')
    copied_pw = False
    for pw_dir in pw_cache_dirs:
        if os.path.exists(pw_dir):
            shutil.copytree(pw_dir, browser_dst, dirs_exist_ok=True)
            print(f"   ✅ Copied Playwright browsers: {pw_dir} → {browser_dst}")
            copied_pw = True
            break
    if not copied_pw:
        print("   ⚠️  Playwright browser binaries not found. User must run 'playwright install' on target machine if automation fails.")

    # Create README for distribution
    readme_content = """
# YouTube Automation Suite - Standalone Application

## 🚀 QUICK START

1. **Install Chrome Browser** (if not already installed)
   - Download from: https://www.google.com/chrome/

2. **Install ChromeDriver**
   - Download from: https://chromedriver.chromium.org/
   - Extract chromedriver.exe to C:\\Windows\\System32\\ (or add to PATH)
   - Version must match your Chrome browser version!

3. **Setup Gmail Account** (Optional - for authenticated email discovery)
   - Rename 'gmail_accounts.csv.example' to 'gmail_accounts.csv'
   - Edit the file and add your Gmail credentials

4. **Launch the Application**
   - Double-click: YouTube_Automation_Suite.exe
   - First launch may take 10-15 seconds

## 📋 SYSTEM REQUIREMENTS

- Windows 10/11 (64-bit)
- 4GB RAM minimum (8GB recommended)
- Internet connection
- Chrome browser installed
- ChromeDriver installed

## 🎯 FEATURES

### 1. Video Scraping
- Search YouTube with multiple topics
- Apply advanced filters (time, quality, duration)
- Extract channel links with low views
- Parallel processing (1-100 Chrome windows)

### 2. Subscriber Count Classification
- Categorize channels by subscriber count
- Output: below_1k.csv, 1k_10k.csv, above_10k.csv

### 3. Email & Contact Finder
- Extract emails from video descriptions
- Scan About sections
- Find social media links
- Parallel processing for speed

### 4. Authenticated Email Discovery
- Login with Gmail to access hidden emails
- Handle CAPTCHA challenges
- Extract protected contact information

## 📊 OUTPUT FILES

- **save.csv** - Raw channel links from scraping
- **below_1k.csv** - Channels with <1K subscribers
- **1k_10k.csv** - Channels with 1K-10K subscribers
- **above_10k.csv** - Channels with >10K subscribers
- **founded_email.csv** - Channels with emails found
- **not_email_but_social.csv** - Social media only
- **signin_to_see_email.csv** - Requires authentication
- **non_founded_email.csv** - No contact info found

## ⚠️ TROUBLESHOOTING

### "ChromeDriver not found"
- Download ChromeDriver from: https://chromedriver.chromium.org/
- Place chromedriver.exe in C:\\Windows\\System32\\
- Or add ChromeDriver folder to Windows PATH

### "Chrome version mismatch"
- ChromeDriver version must match Chrome browser version
- Check Chrome version: chrome://version/
- Download matching ChromeDriver

### "Application won't start"
- Right-click EXE → Properties → Unblock (if from internet)
- Run as Administrator
- Check Windows Defender/Antivirus isn't blocking

### "Browser automation detected"
- Normal behavior for some YouTube videos
- Try using different Gmail accounts
- Add delays between requests

## 🔧 ADVANCED SETTINGS

### Chrome Windows
- Setting: 1-100 windows
- Note: Opens ONE window per topic
- To use 5 windows, enter 5 topics

### Views Range
- Default: 0-10000
- Recommended: 0-50000 for better results
- Higher range = more channels found

### Parallel Email Finding
- Default: 3 windows
- Increase for faster processing
- Monitor system resources

## 📞 SUPPORT

For issues or questions:
1. Check CHROME_WINDOWS_FIX.md for common issues
2. Review the log messages in the GUI
3. Check output CSV files for errors

## ⚖️ LEGAL DISCLAIMER

This tool is for educational and research purposes only.
- Respect YouTube's Terms of Service
- Don't spam or harass creators
- Use for legitimate outreach only
- Follow data protection laws (GDPR, CCPA, etc.)

---

Built with ❤️ using Python, Selenium, and Tkinter
"""
    
    readme_path = os.path.join(dist_folder, 'README.txt')
    with open(readme_path, 'w', encoding='utf-8') as f:
        f.write(readme_content)
    
    print(f"   ✅ Created: README.txt")
    
    # Create batch file for easy launch with Playwright browser path
    batch_content = """@echo off
setlocal
REM Set Playwright browser path if present
set "PW_BROWSERS=%~dp0ms-playwright"
if exist "%PW_BROWSERS%" set PLAYWRIGHT_BROWSERS_PATH=%PW_BROWSERS%
echo Starting YouTube Automation Suite...
echo.
start "" "YouTube_Automation_Suite.exe"
endlocal
"""

    batch_path = os.path.join(dist_folder, 'Launch.bat')
    with open(batch_path, 'w') as f:
        f.write(batch_content)

    print(f"   ✅ Created: Launch.bat (with Playwright browser path support)")
    
    print(f"\n✅ Distribution package created: {dist_folder}/")
    print(f"   📦 Ready to distribute to users!")
    
    return True

def main():
    """Main build function"""
    print("\n")
    # Check if we're in the right directory or try to locate the GUI script
    gui_name = 'youtube_automation_gui.py'
    if not os.path.exists(gui_name):
        print(f"⚠️  {gui_name} not found in current directory. Searching subdirectories...")
        found_path = None
        for root, dirs, files in os.walk('.'):
            if gui_name in files:
                found_path = os.path.abspath(root)
                break

        if found_path:
            print(f"ℹ️  Found {gui_name} in: {found_path}")
            try:
                os.chdir(found_path)
                print(f"ℹ️  Changed working directory to: {found_path}")
            except Exception as e:
                print(f"❌ Failed to change directory to {found_path}: {e}")
                print("   Please run this script from the project directory containing youtube_automation_gui.py")
                return
        else:
            print(f"❌ Error: {gui_name} not found!")
            print("   Please run this script from the project directory or ensure the file exists.")
            return
    
    # Build the EXE
    success = build_exe()
    
    if success:
        # Create distribution package
        create_installer_package()
        
        print("\n" + "=" * 70)
        print("🎉 BUILD COMPLETE!")
        print("=" * 70)
        print("\n📦 Your distribution package is ready:")
        print("   📁 Folder: YouTube_Automation_Suite_Package/")
        print("   📄 Contains:")
        print("      - YouTube_Automation_Suite.exe (Main application)")
        print("      - README.txt (User instructions)")
        print("      - Launch.bat (Quick launcher)")
        print("      - gmail_accounts.csv.example (Configuration template)")
        print("\n🚀 NEXT STEPS:")
        print("   1. Zip the 'YouTube_Automation_Suite_Package' folder")
        print("   2. Share the ZIP file with users")
        print("   3. Users extract and double-click 'Launch.bat' or the EXE")
        print("\n⚠️  REMEMBER:")
        print("   - Users need Chrome browser installed")
        print("   - Users need ChromeDriver installed")
        print("   - First launch may take 10-15 seconds")
        print()
    else:
        print("\n❌ Build failed. Please check the errors above.")
        print("   Common issues:")
        print("   - Missing dependencies (run: pip install -r requirements.txt)")
        print("   - Syntax errors in Python files")
        print("   - Insufficient disk space")

if __name__ == "__main__":
    main()
