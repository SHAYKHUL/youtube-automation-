"""
Test extension loading to verify it works without unzip errors
"""

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from chrome_utils import apply_extensions
import time

def test_extension_loading():
    print("\n" + "="*70)
    print("TESTING EXTENSION LOADING")
    print("="*70)
    
    try:
        print("\n📋 Configuring Chrome options...")
        chrome_options = Options()
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--disable-dev-shm-usage")
        
        print("\n🔧 Applying extensions...")
        apply_extensions(chrome_options)
        
        print("\n🚀 Starting Chrome...")
        driver = webdriver.Chrome(options=chrome_options)
        
        print("✅ Chrome started successfully!")
        
        # Navigate to extensions page to verify
        print("\n🔍 Checking extensions page...")
        driver.get('chrome://extensions')
        time.sleep(2)
        
        print("\n✅ Extension loading test PASSED!")
        print("   Extension loaded without errors")
        
        input("\nPress Enter to close Chrome...")
        driver.quit()
        
        return True
        
    except Exception as e:
        print(f"\n❌ Extension loading test FAILED!")
        print(f"   Error: {e}")
        try:
            driver.quit()
        except:
            pass
        return False

if __name__ == "__main__":
    success = test_extension_loading()
    
    if success:
        print("\n" + "="*70)
        print("✅ SUCCESS - Extension loads correctly!")
        print("="*70)
        print("\nThe extension is properly configured and will work")
        print("in your application without 'cannot unzip' errors.")
    else:
        print("\n" + "="*70)
        print("❌ FAILED - Extension has issues")
        print("="*70)
        print("\nPlease check the error messages above.")
