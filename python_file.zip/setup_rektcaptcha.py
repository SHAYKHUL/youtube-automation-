from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
import os
import time
import shutil
import json

def install_extension():
    while True:
        try:
            # Set up Chrome options
            chrome_options = Options()
            
            # Use our persistent profile
            profile_dir = os.path.join(os.getcwd(), 'chrome_profile')
            chrome_options.add_argument(f'--user-data-dir={profile_dir}')
            
            # Make sure the profile directory exists
            os.makedirs(os.path.join(profile_dir, 'Default'), exist_ok=True)
            
            # Disable automation flags
            chrome_options.add_argument('--no-sandbox')
            chrome_options.add_argument('--start-maximized')
            chrome_options.add_experimental_option('excludeSwitches', ['enable-automation'])
            chrome_options.add_experimental_option('useAutomationExtension', False)
    
    # Initialize Chrome
    driver = webdriver.Chrome(options=chrome_options)
    
    extension_id = 'bbdhfoclddncoaomddgkaaphcnddbpdh'
    extension_url = f'https://chromewebstore.google.com/detail/rektcaptcha-recaptcha-sol/{extension_id}'
    
    print("\n" + "="*70)
    print("CHROME EXTENSION SETUP")
    print("="*70)
    
    # First check if already installed
    print("\nChecking if extension is already installed...")
    driver.get('chrome://extensions')
    time.sleep(3)
    
    try:
        # Enable developer mode
        driver.execute_script("""
            const devMode = document.querySelector('extensions-manager').shadowRoot
                .querySelector('extensions-toolbar').shadowRoot
                .querySelector('#devMode');
            if (devMode && !devMode.checked) {
                devMode.click();
            }
        """)
        time.sleep(1)
        
        # Look for extension
        ext_root = driver.find_element(By.TAG_NAME, 'extensions-manager')
        if ext_root and ext_root.find_elements(By.CSS_SELECTOR, f'extensions-item[id*="{extension_id}"]'):
            print("✅ Extension is already installed!")
            driver.quit()
            return True
    except:
        pass
    
    print("\nExtension needs to be installed. Opening Chrome Web Store...")
    driver.get(extension_url)
    
    print("\nPlease follow these steps:")
    print("1. In the Chrome Web Store page:")
    print("   - Click 'Add to Chrome'")
    print("   - Click 'Add extension' in the popup")
    print("2. Wait for the extension to finish installing")
    print("3. IMPORTANT: DO NOT CLOSE CHROME!")
    print("4. After installation is complete, return here and press Enter")
    
    input("\nPress Enter after the extension is installed (but keep Chrome open)...")
    
    print("\nVerifying installation...")
    driver.get('chrome://extensions')
    time.sleep(2)
    
    try:
        ext_root = driver.find_element(By.TAG_NAME, 'extensions-manager')
        if ext_root and ext_root.find_elements(By.CSS_SELECTOR, f'extensions-item[id*="{extension_id}"]'):
            print("✅ Extension installation verified!")
            
            # Save extension info to profile
            marker = {
                'extension_id': extension_id,
                'extension_url': extension_url
            }
            marker_path = os.path.join(profile_dir, 'required_extension.json')
            with open(marker_path, 'w', encoding='utf-8') as f:
                json.dump(marker, f)
            print("✅ Extension info saved to profile")
            
            print("\nTesting extension functionality...")
            driver.get('https://www.youtube.com')
            time.sleep(5)
            
            has_extension = False
            for attempt in range(3):
                try:
                    has_scripts = bool(driver.find_elements(By.CSS_SELECTOR, f'script[src*="{extension_id}"]'))
                    has_elements = bool(driver.find_elements(By.CSS_SELECTOR, '[class*="recaptcha"],[class*="captcha"]'))
                    
                    if has_scripts or has_elements:
                        print("✅ Extension appears to be working!")
                        has_extension = True
                        break
                except:
                    pass
                
                if not has_extension and attempt < 2:
                    print(f"Waiting for extension to activate (attempt {attempt + 1}/3)...")
                    time.sleep(3)
            
            if not has_extension:
                print("\n⚠️ Extension may need configuration:")
                print("1. Click the extension icon in Chrome")
                print("2. Configure any required settings")
                print("3. Make sure the extension is enabled")
                input("\nPress Enter after configuring the extension...")
            
            print("\nClosing Chrome...")
            driver.quit()
            print("\n✅ Extension setup complete! You can now run discover_signin_emails.py")
            return True
        else:
            print("\n❌ Extension installation could not be verified.")
            print("Please try the installation process again.")
            driver.quit()
            return False
    except Exception as e:
        print(f"\n❌ Error verifying extension: {e}")
        driver.quit()
        return False

if __name__ == "__main__":
    # Kill any existing Chrome processes first
    try:
        import subprocess
        subprocess.run(['taskkill', '/F', '/IM', 'chrome.exe'], capture_output=True)
        time.sleep(2)
    except:
        pass
    
    install_extension()